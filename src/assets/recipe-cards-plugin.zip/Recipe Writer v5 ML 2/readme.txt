=== Gemini Article Generator with Replicate Images ===
Contributors: yourusername
Tags: article, gemini, replicate, AI, content generation, featured image
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.1
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
This plugin generates draft articles using the Google Gemini API for text generation and the Replicate API for creating a featured image. You can simply enter an article title, and the plugin will generate a 1.5k-word article with a structured layout, tone, and formatting based on a detailed prompt. A visually appealing featured image is also created and attached to the post.

== Installation ==
1. Upload the `gemini-article-generator` folder to your `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to the "Gemini Articles" menu in the admin dashboard and enter an article title.
4. Generate the article and review the created draft post.

== Changelog ==
= 1.1 =
* Initial release integrating Gemini API for text and Replicate API for images.

== Frequently Asked Questions ==
= How do I set my API keys? =
Edit the plugin file `gemini-article-generator.php` and replace the placeholders for `GEMINI_API_KEY` and `REPLICATE_API_TOKEN` with your actual API keys.
