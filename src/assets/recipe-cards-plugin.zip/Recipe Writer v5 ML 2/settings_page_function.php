/**
 * Render the Settings page.
 */
public function settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Insufficient permissions.' );
    }
    $disable_recipe_card = get_option('rw_disable_recipe_card', 0);
    ?>
    <div class="wrap">
        <h1>Recipe Writer Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'ga_settings_group' ); ?>
            <?php do_settings_sections( 'ga_settings_group' ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Replicate API Token</th>
                    <td>
                        <input type="text" name="ga_replicate_api_token" value="<?php echo esc_attr( get_option('ga_replicate_api_token') ); ?>" class="regular-text">
                        <p class="description">Your Replicate API token for accessing all LLM models.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">LLM Model</th>
                    <td>
                        <?php $selected_llm = get_option('rw_selected_llm', 'chatgpt'); ?>
                        <select name="rw_selected_llm" class="regular-text">
                            <option value="chatgpt" <?php selected($selected_llm, 'chatgpt'); ?>>ChatGPT (GPT-5)</option>
                            <option value="qwen" <?php selected($selected_llm, 'qwen'); ?>>Qwen3 235B</option>
                        </select>
                        <p class="description">Select which LLM model to use for generating recipe content.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">License Key</th>
                    <td>
                        <input type="text" name="rw_license_key" value="<?php echo esc_attr( get_option('rw_license_key') ); ?>" class="regular-text">
                        <p class="description">Enter your license key to unlock all features.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Recipe Card</th>
                    <td>
                        <label>
                            <input type="checkbox" name="rw_disable_recipe_card" value="1" <?php checked(1, $disable_recipe_card); ?>>
                            Disable Recipe Card and Jump to Recipe functionality
                        </label>
                        <p class="description">When checked, the recipe card and jump to recipe box will not be displayed on your posts.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
