<?php
/*
Plugin Name: Recipe Writer - Pin Lions
Description: Advanced bulk recipe writer using Replicate API with multiple LLM options (ChatGPT, DeepSeek). Generates drafts with images, plus a separate Image Generator that saves images to the media library.
Version: 3.0
Author: Pin Lions
Plugin URI: https://pinlions.com/recipe-writer
Text Domain: recipe-writer-pin-lions
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Fallback for sanitize_textarea_field (introduced in WP 4.7)
if ( ! function_exists( 'sanitize_textarea_field' ) ) {
    function sanitize_textarea_field( $str ) {
        return sanitize_text_field( $str );
    }
}

if ( ! class_exists( 'RecipeWriterPlugin' ) ) {

    class RecipeWriterPlugin {

        public function __construct() {
            // Initialize default settings if they don't exist
            $this->initialize_default_settings();
            
            // Register custom post type for the queue
            add_action( 'init', array( $this, 'register_queue_post_type' ) );

            // Register plugin settings (Replicate API, LLM selection, and License key)
            add_action( 'admin_init', array( $this, 'register_settings' ) );

            // Add admin menus (conditionally show based on license validity)
            add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );

            // AJAX actions for queue
            add_action( 'wp_ajax_ga_process_queue_item', array( $this, 'ajax_process_queue_item' ) );
            add_action( 'wp_ajax_ga_check_prediction_status', array( $this, 'ajax_check_prediction_status' ) );
            add_action( 'wp_ajax_ga_reset_processing_items', array( $this, 'ajax_reset_processing_items' ) );
            add_action( 'wp_ajax_ga_recover_single_item', array( $this, 'ajax_recover_single_item' ) );
            add_action( 'wp_ajax_gag_delete_queue_item', array( $this, 'ajax_delete_queue_item' ) );
            add_action( 'wp_ajax_gag_clear_queue', array( $this, 'ajax_clear_queue' ) );
            add_action( 'wp_ajax_gag_check_pending_items', array( $this, 'ajax_check_pending_items' ) );
            add_action( 'wp_ajax_gag_check_completion_status', array( $this, 'ajax_check_completion_status' ) );
            add_action( 'wp_ajax_gag_count_pending_items', array( $this, 'ajax_count_pending_items' ) );
            add_action( 'wp_ajax_rw_generate_recipe_pdf', array( $this, 'ajax_generate_recipe_pdf' ) );
            add_action( 'wp_ajax_nopriv_rw_generate_recipe_pdf', array( $this, 'ajax_generate_recipe_pdf' ) );
            
            // Disabled: Add meta box for PDF download button in admin
            // add_action( 'add_meta_boxes', array( $this, 'add_recipe_pdf_meta_box' ) );
            
            // Add script to admin footer
            add_action( 'admin_footer', array( $this, 'add_recipe_pdf_script' ) );
            
            // Add PDF download button to the end of post content
            add_filter( 'the_content', array( $this, 'add_pdf_button_to_content' ) );
            
            // Add Jump to Recipe box before the first H2 heading
            add_filter( 'the_content', array( $this, 'add_jump_to_recipe_box' ), 9 );
            
            // Add scripts and styles to frontend
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_scripts' ) );
        }

        /**
         * Register a custom post type for queued articles.
         */
        public function register_queue_post_type() {
            $args = array(
                'public'   => false,
                'show_ui'  => false,
                'label'    => 'Article Queue',
                'supports' => array( 'title' ),
            );
            register_post_type( 'gag_queue', $args );
        }

        /**
         * Register plugin settings.
         */
        public function register_settings() {
            register_setting( 'ga_settings_group', 'ga_replicate_api_token', 'sanitize_text_field' );
            register_setting( 'ga_settings_group', 'rw_selected_llm', 'sanitize_text_field' );
            register_setting( 'ga_settings_group', 'rw_article_length', 'sanitize_text_field' );
            register_setting( 'ga_settings_group', 'rw_article_language', 'sanitize_text_field' );
            register_setting( 'ga_settings_group', 'rw_license_key', 'sanitize_text_field' );
            register_setting( 'ga_settings_group', 'rw_smaller_vertical_images', 'intval' );
            register_setting( 'ga_settings_group', 'rw_disable_recipe_card', 'intval' );
            register_setting( 'ga_settings_group', 'rw_pdf_header_color', 'sanitize_text_field' );
            register_setting( 'ga_settings_group', 'rw_pdf_accent_color', 'sanitize_text_field' );
            register_setting( 'ga_settings_group', 'rw_enable_intext_images', 'intval' );
            register_setting( 'ga_settings_group', 'rw_intext_image_count', 'intval' );
            register_setting( 'ga_settings_group', 'rw_enable_wprm_integration', 'intval' );
            register_setting( 'ga_settings_group', 'rw_wprm_template_mode', 'sanitize_text_field' );
            register_setting( 'ga_settings_group', 'rw_wprm_placement', 'sanitize_text_field' );
            
            // Recipe Card settings
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_title', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_header_color', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_accent_color', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_text_color', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_background_color', 'sanitize_text_field' );
            // Use a proper callback for array sanitization
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_categories', array($this, 'sanitize_categories_array') );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_ingredients_title', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_instructions_title', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_footer_text', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_button_text', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_show_logo', 'intval' );
            
            // Frontend box settings
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_box_description', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_box_bg_color', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_box_text_color', 'sanitize_text_field' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_box_border_radius', 'intval' );
            register_setting( 'rw_recipe_card_group', 'rw_recipe_card_box_shadow', 'intval' );
        }

        /**
         * Sanitize an array of category IDs
         * 
         * @param array $input Array of category IDs
         * @return array Sanitized array
         */
        public function sanitize_categories_array($input) {
            // If empty or not an array, return empty array
            if (empty($input) || !is_array($input)) {
                return array();
            }
            
            // Sanitize each value to ensure they're valid integers
            $sanitized = array();
            foreach ($input as $value) {
                $sanitized[] = absint($value);
            }
            
            return $sanitized;
        }

        /**
         * Initialize default settings if they don't exist
         */
        private function initialize_default_settings() {
            // Check if settings exist, if not add defaults
            if (get_option('rw_recipe_card_header_color') === false) {
                update_option('rw_recipe_card_header_color', '#333333');
            }
            
            if (get_option('rw_recipe_card_accent_color') === false) {
                update_option('rw_recipe_card_accent_color', '#FF6B6B');
            }
            
            if (get_option('rw_recipe_card_text_color') === false) {
                update_option('rw_recipe_card_text_color', '#333333');
            }
            
            if (get_option('rw_recipe_card_background_color') === false) {
                update_option('rw_recipe_card_background_color', '#FFFFFF');
            }
            
            if (get_option('rw_recipe_card_title') === false) {
                update_option('rw_recipe_card_title', 'Printable Recipe Card');
            }
            
            if (get_option('rw_recipe_card_ingredients_title') === false) {
                update_option('rw_recipe_card_ingredients_title', 'Ingredients');
            }
            
            if (get_option('rw_recipe_card_instructions_title') === false) {
                update_option('rw_recipe_card_instructions_title', 'Instructions');
            }
            
            if (get_option('rw_recipe_card_footer_text') === false) {
                update_option('rw_recipe_card_footer_text', 'Recipe from {site_name}');
            }
            
            if (get_option('rw_recipe_card_button_text') === false) {
                update_option('rw_recipe_card_button_text', 'Download Recipe Card');
            }
            
            if (get_option('rw_recipe_card_box_description') === false) {
                update_option('rw_recipe_card_box_description', 'Want just the essential recipe details without scrolling through the article? Get our printable recipe card with just the ingredients and instructions.');
            }
            
            if (get_option('rw_recipe_card_box_bg_color') === false) {
                update_option('rw_recipe_card_box_bg_color', '#ffffff');
            }
            
            if (get_option('rw_recipe_card_box_text_color') === false) {
                update_option('rw_recipe_card_box_text_color', '#555555');
            }
            
            if (get_option('rw_recipe_card_box_border_radius') === false) {
                update_option('rw_recipe_card_box_border_radius', 12);
            }
            
            if (get_option('rw_recipe_card_box_shadow') === false) {
                update_option('rw_recipe_card_box_shadow', 1);
            }
            
            // WPRM placement default (before first H2)
            if (get_option('rw_wprm_placement') === false) {
                update_option('rw_wprm_placement', 'before_first_h2');
            }
            
            if (get_option('rw_recipe_card_show_logo') === false) {
                update_option('rw_recipe_card_show_logo', 1);
            }
            
            if (get_option('rw_enable_intext_images') === false) {
                update_option('rw_enable_intext_images', 1);
            }
            
            if (get_option('rw_intext_image_count') === false) {
                update_option('rw_intext_image_count', 3);
            }
        }

        /**
         * Verify the license key via your Google Apps Script endpoint.
         */
        private function verify_license_key( $license_key ) {
            $license_key = trim( $license_key );
            error_log( 'Verifying license key: ' . $license_key );

            if ( empty( $license_key ) ) {
                error_log( 'License key is empty.' );
                return false;
            }
            // Replace YOUR_SCRIPT_ID with your actual deployment ID.
            $api_url = 'https://script.google.com/macros/s/AKfycbw01hYVY1fxZ5WwYk42hReS3gygBfaou7oKgUIXYJtE7c7CU3uHmi460O7DCuvdKmZS/exec?key=' . urlencode( $license_key );
            error_log( 'License API URL: ' . $api_url );

            $response = wp_remote_get( $api_url );
            if ( is_wp_error( $response ) ) {
                error_log( 'License API error: ' . $response->get_error_message() );
                return false;
            }

            $body = wp_remote_retrieve_body( $response );
            error_log( 'License API response: ' . $body );
            $data = json_decode( $body, true );
            if ( isset( $data['valid'] ) && filter_var( $data['valid'], FILTER_VALIDATE_BOOLEAN ) === true ) {
                return true;
            }
            return false;
        }

        /**
         * Display an admin notice if the license is invalid.
         */
        public function license_invalid_notice() {
            // Only show this notice on the settings page
            $current_page = isset($_GET['page']) ? $_GET['page'] : '';
            if ($current_page === 'gag-settings') {
                ?>
                <div class="notice notice-error">
                    <p>
                        <strong>Recipe Writer License:</strong> This plugin is disabled because the license key is missing or invalid.
                        Please enter a valid license key below to unlock all features.
                    </p>
                </div>
                <?php
            }
        }

        /**
         * Add admin menus conditionally.
         */
        public function add_admin_menu() {
            if ( ! current_user_can( 'manage_options' ) ) {
                return;
            }

            $license_key = get_option('rw_license_key', '');
            $valid_license = $this->verify_license_key($license_key);
            
            // Check if current page is one of our plugin pages but not settings
            $current_page = isset($_GET['page']) ? $_GET['page'] : '';
            $plugin_pages = array('gag-bulk-generate', 'gag-queue-status', 'gag-recipe-card', 'gag-image-generator');
            
            // If license is invalid and trying to access a plugin page other than settings, redirect to settings
            if (!$valid_license && in_array($current_page, $plugin_pages)) {
                wp_redirect(admin_url('admin.php?page=gag-settings'));
                exit;
            }
            
            if ($valid_license) {
                // Set Recipe Writer as the main menu item
                add_menu_page(
                    'Recipe Writer',
                    'Recipe Writer',
                    'manage_options',
                    'gag-bulk-generate',
                    array($this, 'bulk_generate_page'),
                    'dashicons-food',
                    30
                );
                
                // Add Recipes (already added as main page, but needs to be first in submenu too)
                add_submenu_page(
                    'gag-bulk-generate',
                    'Add Recipes',
                    'Add Recipes',
                    'manage_options',
                    'gag-bulk-generate'
                );
                
                // Recipe List
                add_submenu_page(
                    'gag-bulk-generate',
                    'Recipe List',
                    'Recipe List',
                    'manage_options',
                    'gag-queue-status',
                    array($this, 'queue_status_page')
                );
                
                // Recipe Card
                add_submenu_page(
                    'gag-bulk-generate',
                    'Recipe Card',
                    'Recipe Card',
                    'manage_options',
                    'gag-recipe-card',
                    array($this, 'recipe_card_page')
                );
                
                // Image Generator
                add_submenu_page(
                    'gag-bulk-generate',
                    'Image Generator',
                    'Image Generator',
                    'manage_options',
                    'gag-image-generator',
                    array($this, 'image_generator_page')
                );
                
                // Settings
                add_submenu_page(
                    'gag-bulk-generate',
                    'Settings',
                    'Settings',
                    'manage_options',
                    'gag-settings',
                    array($this, 'settings_page')
                );
            } else {
                // For invalid license, only show Settings page as the main menu
                add_menu_page(
                    'Recipe Writer Settings',
                    'Recipe Writer',
                    'manage_options',
                    'gag-settings',
                    array($this, 'settings_page'),
                    'dashicons-food',
                    30
                );
                
                // Show license invalid notice
                add_action('admin_notices', array($this, 'license_invalid_notice'));
            }
        }

        /**
         * Render the Settings page.
         */
        public function settings_page() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( 'Insufficient permissions.' );
            }
            $disable_recipe_card = get_option('rw_disable_recipe_card', 0);
            ?>
            <div class="wrap">
                <h1>Recipe Writer Settings</h1>
                <form method="post" action="options.php">
                    <?php settings_fields( 'ga_settings_group' ); ?>
                    <?php do_settings_sections( 'ga_settings_group' ); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row">Replicate API Token</th>
                            <td>
                                <input type="text" name="ga_replicate_api_token" value="<?php echo esc_attr( get_option('ga_replicate_api_token') ); ?>" class="regular-text">
                                <p class="description">Your Replicate API token for accessing all LLM models.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">LLM Model</th>
                            <td>
                                <?php $selected_llm = get_option('rw_selected_llm', 'chatgpt'); ?>
                                <select name="rw_selected_llm" class="regular-text">
                                    <option value="chatgpt" <?php selected($selected_llm, 'chatgpt'); ?>>ChatGPT (GPT-5)</option>
                                </select>
                                <p class="description">Select which LLM model to use for generating recipe content.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Article Length</th>
                            <td>
                                <?php $selected_length = get_option('rw_article_length', '900-1200'); ?>
                                <select name="rw_article_length" class="regular-text">
                                    <option value="600-900" <?php selected($selected_length, '600-900'); ?>>Short (600-900 words)</option>
                                    <option value="900-1200" <?php selected($selected_length, '900-1200'); ?>>Long (900-1200 words)</option>
                                </select>
                                <p class="description">Choose the target length for generated recipe articles.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Article Language</th>
                            <td>
                                <?php $selected_language = get_option('rw_article_language', 'english'); ?>
                                <select name="rw_article_language" class="regular-text">
                                    <option value="english" <?php selected($selected_language, 'english'); ?>>English</option>
                                    <option value="spanish" <?php selected($selected_language, 'spanish'); ?>>Spanish</option>
                                    <option value="french" <?php selected($selected_language, 'french'); ?>>French</option>
                                    <option value="german" <?php selected($selected_language, 'german'); ?>>German</option>
                                    <option value="polish" <?php selected($selected_language, 'polish'); ?>>Polish</option>
                                </select>
                                <p class="description">Select the language for generated recipe articles. The content will be written for native speakers of that language.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">License Key</th>
                            <td>
                                <input type="text" name="rw_license_key" value="<?php echo esc_attr( get_option('rw_license_key') ); ?>" class="regular-text">
                                <p class="description">Enter your license key to unlock all features.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Recipe Card</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="rw_disable_recipe_card" value="1" <?php checked(1, $disable_recipe_card); ?>>
                                    Disable Recipe Card and Jump to Recipe functionality
                                </label>
                                <p class="description">When checked, the recipe card and jump to recipe box will not be displayed on your posts.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">In-Text Images</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="rw_enable_intext_images" value="1" <?php checked(1, get_option('rw_enable_intext_images', 1)); ?>>
                                    Generate additional in-text images using Seedream
                                </label>
                                <p class="description">When enabled, the plugin will generate 3 additional images and place them throughout the article content.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Number of In-Text Images</th>
                            <td>
                                <select name="rw_intext_image_count" class="regular-text">
                                    <option value="2" <?php selected(get_option('rw_intext_image_count', 3), 2); ?>>2 Images</option>
                                    <option value="3" <?php selected(get_option('rw_intext_image_count', 3), 3); ?>>3 Images</option>
                                    <option value="4" <?php selected(get_option('rw_intext_image_count', 3), 4); ?>>4 Images</option>
                                </select>
                                <p class="description">Choose how many in-text images to generate for each recipe article.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">WP Recipe Maker Integration</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="rw_enable_wprm_integration" value="1" <?php checked(get_option('rw_enable_wprm_integration', 0), 1); ?>>
                                    Create WP Recipe Maker recipe cards automatically
                                </label>
                                <p class="description">When enabled, the plugin will automatically create a WP Recipe Maker recipe card and insert it into the article. <strong>Only works for English language articles. Requires WP Recipe Maker plugin to be installed and active.</strong></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">WPRM Template Mode</th>
                            <td>
                                <?php $selected_template = get_option('rw_wprm_template_mode', 'default'); ?>
                                <select name="rw_wprm_template_mode" class="regular-text">
                                    <option value="default" <?php selected($selected_template, 'default'); ?>>Default Template</option>
                                    <option value="basic" <?php selected($selected_template, 'basic'); ?>>Basic</option>
                                    <option value="blend-in" <?php selected($selected_template, 'blend-in'); ?>>Blend In</option>
                                    <option value="chic" <?php selected($selected_template, 'chic'); ?>>Chic</option>
                                    <option value="classic" <?php selected($selected_template, 'classic'); ?>>Classic</option>
                                    <option value="compact" <?php selected($selected_template, 'compact'); ?>>Compact</option>
                                    <option value="compact-howto" <?php selected($selected_template, 'compact-howto'); ?>>Compact Howto</option>
                                    <option value="excerpt" <?php selected($selected_template, 'excerpt'); ?>>Excerpt</option>
                                </select>
                                <p class="description">Select the template style for WP Recipe Maker recipe cards. Matches the templates available in WPRM settings.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">WPRM Card Placement</th>
                            <td>
                                <?php $selected_placement = get_option('rw_wprm_placement', 'before_first_h2'); ?>
                                <select name="rw_wprm_placement" class="regular-text">
                                    <option value="before_first_h2" <?php selected($selected_placement, 'before_first_h2'); ?>>Before First H2 Heading</option>
                                    <option value="after_first_h2" <?php selected($selected_placement, 'after_first_h2'); ?>>After First H2 Heading</option>
                                    <option value="end_of_content" <?php selected($selected_placement, 'end_of_content'); ?>>End of Content</option>
                                </select>
                                <p class="description">Choose where to insert the WP Recipe Maker card in the article. <strong>Only applies to English language articles.</strong></p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button(); ?>
                </form>
            </div>
            <?php
        }

        /**
         * Render the "Add Recipes" page.
         */
        public function bulk_generate_page() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( 'Insufficient permissions.' );
            }
            ?>
            <div class="wrap">
                <h1>Add Recipes</h1>
                <?php
                if ( isset( $_POST['gag_bulk_generate'] ) ) {
                    if ( ! isset( $_POST['gag_bulk_nonce'] ) || ! wp_verify_nonce( $_POST['gag_bulk_nonce'], 'gag_bulk_generate_action' ) ) {
                        echo '<div class="error"><p>Security check failed.</p></div>';
                    } else {
                        $titles = explode( "\n", sanitize_textarea_field( $_POST['bulk_titles'] ) );
                        $count  = 0;
                        foreach ( $titles as $title ) {
                            $title = trim( $title );
                            if ( ! empty( $title ) ) {
                                $queue_item = array(
                                    'post_title'  => $title,
                                    'post_status' => 'publish',
                                    'post_type'   => 'gag_queue'
                                );
                                $queue_id = wp_insert_post( $queue_item );
                                if ( ! is_wp_error( $queue_id ) ) {
                                    update_post_meta( $queue_id, '_ga_status', 'pending' );
                                    $count++;
                                }
                            }
                        }
                        echo '<div class="updated"><p>' . esc_html( $count ) . ' articles added to the queue.</p></div>';
                    }
                }
                ?>
                <form method="post">
                    <?php wp_nonce_field( 'gag_bulk_generate_action', 'gag_bulk_nonce' ); ?>
                    <p>Enter one recipe title per line:</p>
                    <textarea name="bulk_titles" rows="10" cols="50" class="large-text code"></textarea>
                    <?php submit_button( 'Add to Queue', 'primary', 'gag_bulk_generate' ); ?>
                </form>
            </div>
            <?php
        }

        /**
         * Render the "Recipe List" page.
         */
        public function queue_status_page() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( 'Insufficient permissions.' );
            }
            ?>
            <div class="wrap">
                <style>
                .rw-recipe-list {
                    background: #fff;
                    border: 1px solid #e1e5e9;
                    border-radius: 4px;
                    overflow: hidden;
                    margin-top: 20px;
                }
                .rw-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 20px;
                    border-bottom: 1px solid #e1e5e9;
                    background: #f9f9f9;
                    color: #23282d;
                }
                .rw-header h1 {
                    margin: 0;
                    font-size: 24px;
                    font-weight: 600;
                }
                .rw-actions {
                    display: flex;
                    gap: 12px;
                }
                .rw-btn {
                    padding: 10px 20px;
                    border: none;
                    border-radius: 6px;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                    text-decoration: none;
                    display: inline-block;
                }
                .rw-btn-primary {
                    background: #0073aa;
                    color: white;
                }
                .rw-btn-primary:hover {
                    background: #005a87;
                    color: white;
                }
                .rw-btn-secondary {
                    background: #f7f7f7;
                    color: #555;
                    border: 1px solid #ccc;
                }
                .rw-btn-secondary:hover {
                    background: #fafafa;
                    color: #23282d;
                }
                .rw-table {
                    width: 100%;
                    border-collapse: collapse;
                }
                .rw-table th {
                    background: #f9f9f9;
                    padding: 12px 16px;
                    text-align: left;
                    font-weight: 600;
                    color: #23282d;
                    border-bottom: 1px solid #e1e5e9;
                }
                .rw-table td {
                    padding: 12px 16px;
                    border-bottom: 1px solid #f1f1f1;
                    vertical-align: middle;
                }
                .rw-table tr:hover {
                    background: #f9f9f9;
                }
                .rw-status {
                    padding: 4px 12px;
                    border-radius: 20px;
                    font-size: 12px;
                    font-weight: 500;
                    text-transform: uppercase;
                }
                .rw-status.completed {
                    background: #d1fae5;
                    color: #065f46;
                }
                .rw-status.error {
                    background: #fee2e2;
                    color: #991b1b;
                }
                .rw-status.processing {
                    background: #fef3c7;
                    color: #92400e;
                }
                .rw-status.pending {
                    background: #e0e7ff;
                    color: #3730a3;
                }
                .rw-link {
                    color: #3b82f6;
                    text-decoration: none;
                    font-weight: 500;
                }
                .rw-link:hover {
                    color: #1d4ed8;
                }
                .rw-btn-delete {
                    background: #ef4444;
                    color: white;
                    padding: 6px 12px;
                    border: none;
                    border-radius: 4px;
                    font-size: 12px;
                    cursor: pointer;
                }
                .rw-btn-delete:hover {
                    background: #dc2626;
                }
                .rw-response {
                    margin: 20px 24px;
                    padding: 12px;
                    border-radius: 6px;
                    background: #f0f9ff;
                    border: 1px solid #0ea5e9;
                    display: none;
                }
                .rw-loading {
                    display: inline-flex;
                    align-items: center;
                    gap: 8px;
                }
                .rw-spinner {
                    width: 16px;
                    height: 16px;
                    border: 2px solid #f3f3f3;
                    border-top: 2px solid #0073aa;
                    border-radius: 50%;
                    animation: spin 1s linear infinite;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                .rw-btn:disabled {
                    opacity: 0.6;
                    cursor: not-allowed;
                }
                .rw-empty {
                    text-align: center;
                    padding: 40px;
                    color: #6b7280;
                }
                </style>
                <div class="rw-recipe-list">
                    <div class="rw-header">
                        <h1>Recipe List</h1>
                        <div class="rw-actions">
                            <button id="gag-process-next" class="rw-btn rw-btn-primary">Create Next Article</button>
                            <button id="gag-process-all" class="rw-btn rw-btn-secondary">Create All Articles</button>
                            <button id="gag-clear-queue" class="rw-btn rw-btn-secondary">Clear List</button>
                        </div>
                    </div>
                    <div id="gag-queue-response" class="rw-response"></div>
                    <table class="rw-table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Status</th>
                                <th>Draft Post</th>
                                <th>Error Message</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                    <tbody>
                        <?php
                        $args = array(
                            'post_type'      => 'gag_queue',
                            'post_status'    => 'any',
                            'posts_per_page' => -1,
                            'orderby'        => 'date',
                            'order'          => 'DESC'
                        );
                        $queue_items = get_posts( $args );
                        if ( $queue_items ) {
                            foreach ( $queue_items as $item ) {
                                $status     = get_post_meta( $item->ID, '_ga_status', true );
                                $draft_post = get_post_meta( $item->ID, '_ga_generated_post_id', true );
                                $error      = get_post_meta( $item->ID, '_ga_error_message', true );
                                ?>
                                <tr id="queue-item-<?php echo esc_attr( $item->ID ); ?>">
                                    <td><strong><?php echo esc_html( $item->post_title ); ?></strong></td>
                                    <td><span class="rw-status <?php echo esc_attr( $status ); ?>"><?php echo esc_html( $status ); ?></span></td>
                                    <td>
                                        <?php
                                        if ( $draft_post ) {
                                            $link = get_edit_post_link( $draft_post );
                                            echo '<a href="' . esc_url( $link ) . '" target="_blank" class="rw-link">View Draft</a>';
                                        } else {
                                            echo '<span style="color: #9ca3af;">N/A</span>';
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo $error ? '<span style="color: #ef4444; font-size: 12px;">' . esc_html( $error ) . '</span>' : '<span style="color: #9ca3af;">—</span>'; ?></td>
                                    <td>
                                        <button class="gag-delete-queue-item rw-btn-delete" data-queue-id="<?php echo esc_attr( $item->ID ); ?>">Delete</button>
                                        <?php if ( $status === 'processing' ): ?>
                                            <button class="button rw-recover-btn" data-id="<?php echo esc_attr( $item->ID ); ?>">Recover</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo '<tr><td colspan="5" class="rw-empty">No recipes in queue. Add some recipes to get started!</td></tr>';
                        }
                        ?>
                    </tbody>
                    </table>
                </div>
                
                <div style="margin-top: 20px;">
                    <button id="rw-reset-processing" class="button button-secondary">Reset Processing Items</button>
                    <p class="description">Reset items stuck in processing status for more than 10 minutes.</p>
                </div>
            </div>
            <script>
            // Global error handler to catch unhandled exceptions
            window.addEventListener('error', function(e) {
                console.error('Global JavaScript error:', e.error, e.message, e.filename, e.lineno);
                
                // If bulk generation modal exists, show error in it
                if (jQuery('#bulk-generation-modal').length) {
                    jQuery('#bulk-generation-modal').html('<div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.3); max-width: 500px; width: 90%; position: relative;">' +
                        '<div style="text-align: center;">' +
                        '<h2 style="color: #dc3232; margin: 10px 0;">JavaScript Error</h2>' +
                        '<p>A JavaScript error occurred: ' + e.message + '</p>' +
                        '<p>Check the browser console for more details.</p>' +
                        '<button onclick="jQuery(\'#bulk-generation-modal\').remove(); window.location.reload();" style="padding: 10px 20px; background: #0073aa; color: white; border: none; border-radius: 3px; cursor: pointer;">Close & Refresh</button>' +
                        '</div>' +
                        '</div>');
                }
            });
            
            jQuery(document).ready(function($) {
                function processQueueItem(callback) {
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            action: 'ga_process_queue_item',
                            nonce: '<?php echo wp_create_nonce("gag_process_queue_nonce"); ?>'
                        },
                        success: function(response) {
                            // Debug: log the full response to console
                            console.log('AJAX Response:', response);
                            callback(response);
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            console.error('AJAX Error:', textStatus, errorThrown);
                            callback({ success: false, message: errorThrown });
                        },
                        complete: function() {
                            console.log('AJAX request completed');
                        },
                        // Set a longer timeout to ensure the request has enough time to complete
                        timeout: 120000 // 2 minutes timeout
                    });
                }
                $('#gag-process-next').on('click', function(e) {
                    e.preventDefault();
                    var $responseDiv = $('#gag-queue-response');
                    var $button = $(this);
                    
                    // Show loading state
                    $responseDiv.html('<div style="padding: 15px; background-color: #f0f9ff; border-left: 4px solid #0073aa; display: block;">' +
                        '<div class="rw-loading">' +
                        '<div class="rw-spinner"></div>' +
                        '<strong>Generating recipe article...</strong>' +
                        '</div>' +
                        '<div style="margin-top: 8px; font-size: 14px; color: #666;">This usually takes 30-60 seconds. Please wait.</div>' +
                        '</div>');
                    
                    // Update button text and disable
                    $button.prop('disabled', true).html('<div class="rw-loading"><div class="rw-spinner"></div>Generating...</div>');
                    
                    processQueueItem(function(response) {
                        // Reset button to original state
                        $button.prop('disabled', false).html('Create Next Article');
                        
                        if(response && response.success) {
                            // Show success message with link to edit the post
                            var editUrl = response.data.edit_url || ("<?php echo admin_url('post.php?post='); ?>" + response.data.post_id + "&action=edit");
                            var postTitle = response.data.post_title || "Recipe";
                            
                            $responseDiv.html('<div style="padding: 15px; background-color: #ecf8f0; border-left: 4px solid #46b450; display: block;">' + 
                                '<div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">' +
                                '<span style="color: #059669; font-size: 18px;">✓</span>' +
                                '<strong>Recipe Generated Successfully!</strong>' +
                                '</div>' +
                                '<div>Recipe "' + postTitle + '" has been created and saved as a draft.</div>' +
                                '<a href="' + editUrl + '" target="_blank" class="button button-primary" style="margin-top: 10px;">View Draft</a>' +
                                '</div>');
                            
                            // Auto-refresh the table immediately
                            refreshTable();
                        } else {
                            // Show error state
                            $responseDiv.html('<div style="padding: 15px; background-color: #fef2f2; border-left: 4px solid #ef4444; display: block;">' +
                                '<div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">' +
                                '<span style="color: #ef4444; font-size: 18px;">⚠</span>' +
                                '<strong>Generation In Progress</strong>' +
                                '</div>' +
                                '<div>Article is being created in the background. Please check back in 1-2 minutes.</div>' +
                                '<button onclick="refreshTable()" class="button" style="margin-top: 10px;">Check Status</button>' +
                                '</div>');
                        }
                    });
                });
                $('#gag-process-all').on('click', function(e) {
                    e.preventDefault();
                    var $responseDiv = $('#gag-queue-response');
                    var $button = $(this);
                    var processedCount = 0;
                    var totalCount = 0;
                    
                    // IMMEDIATELY disable button and show loading state
                    $button.prop('disabled', true).html('<div class="rw-loading"><div class="rw-spinner"></div>Starting...</div>');
                    $('#gag-process-next').prop('disabled', true).css('opacity', '0.5');
                    $('#gag-clear-queue').prop('disabled', true).css('opacity', '0.5');
                    
                    // Create modal-style overlay popup
                    $('body').append('<div id="bulk-generation-modal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 999999; display: flex; align-items: center; justify-content: center;">' +
                        '<div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.3); max-width: 500px; width: 90%; position: relative;">' +
                        '<div style="text-align: center;">' +
                        '<div class="rw-loading" style="margin-bottom: 20px;">' +
                        '<div class="rw-spinner" style="width: 40px; height: 40px; margin: 0 auto 15px;"></div>' +
                        '<strong style="font-size: 18px; color: #0073aa;">Preparing Bulk Generation...</strong>' +
                        '</div>' +
                        '<div style="font-size: 14px; color: #666; margin-bottom: 15px;">Counting pending articles...</div>' +
                        '<div style="font-size: 13px; color: #888; font-weight: 500; background: #fff3cd; padding: 10px; border-radius: 6px; border-left: 4px solid #ffc107;">⚠️ Do not close this page or navigate away</div>' +
                        '</div>' +
                        '</div>' +
                        '</div>');
                    
                    // Also update the response div for backup
                    $responseDiv.html('<div style="padding: 15px; background-color: #f0f9ff; border-left: 4px solid #0073aa; display: block;">' +
                        '<strong>Bulk generation in progress...</strong> See the popup for detailed progress.' +
                        '</div>');
                    
                    // Count total pending items first
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            action: 'gag_count_pending_items',
                            nonce: '<?php echo wp_create_nonce("gag_process_queue_nonce"); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                totalCount = response.data.count;
                                if (totalCount === 0) {
                                    // Remove modal and reset buttons if no items found
                                    $('#bulk-generation-modal').remove();
                                    $button.prop('disabled', false).html('Create All Articles');
                                    $('#gag-process-next').prop('disabled', false).css('opacity', '1');
                                    $('#gag-clear-queue').prop('disabled', false).css('opacity', '1');
                                    
                                    $responseDiv.html('<div style="padding: 15px; background-color: #f7fcfe; border-left: 4px solid #2271b1; display: block;">' +
                                        '<strong>No pending articles found.</strong> Add some recipes first.</div>');
                                    return;
                                }
                                
                                // Update modal with actual count and progress bar
                                console.log('Updating modal with totalCount:', totalCount);
                                $('#bulk-generation-modal').html('<div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.3); max-width: 500px; width: 90%; position: relative;">' +
                                    '<div style="text-align: center;">' +
                                    '<div class="rw-loading" style="margin-bottom: 20px;">' +
                                    '<div class="rw-spinner" style="width: 40px; height: 40px; margin: 0 auto 15px;"></div>' +
                                    '<strong style="font-size: 18px; color: #0073aa;">Generating Articles</strong>' +
                                    '</div>' +
                                    '<div style="margin-bottom: 20px;">' +
                                    '<div style="display: flex; justify-content: space-between; margin-bottom: 8px;">' +
                                    '<span style="font-size: 16px; color: #666;">Progress:</span>' +
                                    '<span id="modal-progress-counter" style="font-size: 16px; font-weight: bold; color: #0073aa;">0/' + totalCount + '</span>' +
                                    '</div>' +
                                    '<div style="width: 100%; background-color: #e0e0e0; border-radius: 12px; height: 24px; overflow: hidden; box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);">' +
                                    '<div id="modal-progress-bar" style="width: 0%; background: linear-gradient(90deg, #0073aa, #005a87); height: 100%; border-radius: 12px; transition: width 0.5s ease; position: relative;">' +
                                    '<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-weight: bold; font-size: 12px;" id="progress-percentage">0%</div>' +
                                    '</div>' +
                                    '</div>' +
                                    '</div>' +
                                    '<div id="modal-current-recipe" style="font-size: 14px; color: #059669; font-style: italic; margin-bottom: 15px; min-height: 20px;">Starting generation of ' + totalCount + ' articles...</div>' +
                                    '<div style="font-size: 13px; color: #888; font-weight: 500; background: #fff3cd; padding: 12px; border-radius: 8px; border-left: 4px solid #ffc107;">⚠️ Do not close this page or navigate away<br><small>This process may take several minutes</small></div>' +
                                    '</div>' +
                                    '</div>');
                                
                                // Double-check that the counter is set correctly
                                setTimeout(function() {
                                    $('#modal-progress-counter').text('0/' + totalCount);
                                    console.log('Double-checked progress counter set to: 0/' + totalCount);
                                }, 100);
                                
                                // Update button text with count - KEEP IT DISABLED
                                $button.html('<div class="rw-loading"><div class="rw-spinner"></div>Processing ' + totalCount + ' Articles...</div>');
                                
                                checkForPendingItems();
                            } else {
                                // Remove modal and reset buttons on error
                                $('#bulk-generation-modal').remove();
                                $button.prop('disabled', false).html('Create All Articles');
                                $('#gag-process-next').prop('disabled', false).css('opacity', '1');
                                $('#gag-clear-queue').prop('disabled', false).css('opacity', '1');
                                
                                $responseDiv.html('<div style="padding: 15px; background-color: #fef2f2; border-left: 4px solid #ef4444; display: block;">' +
                                    '<strong>Error:</strong> Could not count pending articles. Please try again.</div>');
                            }
                        },
                        error: function(jqXHR, textStatus, errorThrown) {
                            console.log('Count pending items error:', textStatus, errorThrown, jqXHR.responseText);
                            // Remove modal and reset buttons on error
                            $('#bulk-generation-modal').remove();
                            $button.prop('disabled', false).html('Create All Articles');
                            $('#gag-process-next').prop('disabled', false).css('opacity', '1');
                            $('#gag-clear-queue').prop('disabled', false).css('opacity', '1');
                            
                            $responseDiv.html('<div style="padding: 15px; background-color: #fef2f2; border-left: 4px solid #ef4444; display: block;">' +
                                '<strong>Error:</strong> Network error (' + textStatus + '). Please check your connection and try again.<br>' +
                                '<small>Check browser console for details.</small></div>');
                        }
                    });
                    
                    // Check if there are pending items before starting
                    function checkForPendingItems() {
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            dataType: 'json',
                            data: {
                                action: 'gag_check_pending_items',
                                nonce: '<?php echo wp_create_nonce("gag_process_queue_nonce"); ?>'
                            },
                            success: function(response) {
                                if (response.success && response.data.has_pending) {
                                    processAll();
                                } else {
                                    // No more pending items - show completion
                                    if (processedCount > 0) {
                                        // Ensure processedCount matches totalCount for final display
                                        var finalCount = Math.max(processedCount, totalCount);
                                        
                                        // Update modal progress bar to 100% and show completion
                                        $('#modal-progress-counter').text(finalCount + '/' + totalCount);
                                        $('#modal-progress-bar').css('width', '100%');
                                        $('#progress-percentage').text('100%');
                                        $('#modal-current-recipe').html('🎉 All recipes completed successfully!');
                                        
                                        // Show completion modal for 3 seconds
                                        setTimeout(function() {
                                            $('#bulk-generation-modal').html('<div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.3); max-width: 500px; width: 90%; position: relative;">' +
                                                '<div style="text-align: center;">' +
                                                '<div style="margin-bottom: 20px;">' +
                                                '<span style="color: #059669; font-size: 48px;">✓</span>' +
                                                '<h2 style="color: #059669; margin: 10px 0;">All Articles Generated!</h2>' +
                                                '</div>' +
                                                '<div style="margin-bottom: 20px;">' +
                                                '<div style="display: flex; justify-content: space-between; margin-bottom: 8px;">' +
                                                '<span style="font-size: 16px; color: #666;">Final Progress:</span>' +
                                                '<span style="font-size: 16px; font-weight: bold; color: #059669;">' + finalCount + '/' + totalCount + ' Complete</span>' +
                                                '</div>' +
                                                '<div style="width: 100%; background-color: #e0e0e0; border-radius: 12px; height: 24px; overflow: hidden; box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);">' +
                                                '<div style="width: 100%; background: linear-gradient(90deg, #46b450, #059669); height: 100%; border-radius: 12px; position: relative;">' +
                                                '<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-weight: bold; font-size: 12px;">100%</div>' +
                                                '</div>' +
                                                '</div>' +
                                                '</div>' +
                                                '<div style="font-size: 14px; color: #666; margin-bottom: 20px;">All ' + finalCount + ' articles have been created and saved as drafts.</div>' +
                                                '<div style="background: #ecf8f0; padding: 12px; border-radius: 8px; border-left: 4px solid #46b450; font-size: 13px; color: #059669;">You can now edit and publish your recipes!</div>' +
                                                '</div>' +
                                                '</div>');
                                            
                                            // Close modal and reset buttons after 4 seconds
                                            setTimeout(function() {
                                                $('#bulk-generation-modal').fadeOut(500, function() {
                                                    $(this).remove();
                                                });
                                                
                                                // Reset ALL buttons
                                                $button.prop('disabled', false).html('Create All Articles');
                                                $('#gag-process-next').prop('disabled', false).css('opacity', '1');
                                                $('#gag-clear-queue').prop('disabled', false).css('opacity', '1');
                                                
                                                // Update response div with countdown - this persists even if modal disappears
                                                $responseDiv.html('<div id="completion-message" style="padding: 15px; background-color: #ecf8f0; border-left: 4px solid #46b450; display: block;">' +
                                                    '<strong>✓ Bulk generation completed!</strong> ' + finalCount + ' articles created successfully.<br>' +
                                                    '<span id="refresh-countdown">Page will auto-refresh in <strong>5</strong> seconds...</span><br>' +
                                                    '<button onclick="window.location.reload()" style="margin-top: 10px; padding: 5px 10px; background: #0073aa; color: white; border: none; border-radius: 3px; cursor: pointer;">Refresh Now</button>' +
                                                    '</div>');
                                                
                                                // Start countdown timer
                                                var timeLeft = 5; // 5 seconds
                                                var countdownInterval = setInterval(function() {
                                                    timeLeft--;
                                                    $('#refresh-countdown').html('Page will auto-refresh in <strong>' + timeLeft + '</strong> seconds...');
                                                    
                                                    if (timeLeft <= 0) {
                                                        clearInterval(countdownInterval);
                                                        $('#refresh-countdown').html('Refreshing now...');
                                                    }
                                                }, 1000);
                                                
                                                // Auto-refresh after 5 seconds since all items are confirmed completed
                                                var refreshTimeout = setTimeout(function() {
                                                    console.log('Auto-refreshing page after completion - all items confirmed completed');
                                                    clearInterval(countdownInterval);
                                                    window.location.reload();
                                                }, 5000); // 5 seconds
                                                
                                                // Store timeout ID globally so it can't be lost
                                                window.bulkGenerationRefreshTimeout = refreshTimeout;
                                                console.log('Set refresh timeout ID:', refreshTimeout);
                                                
                                                // Also set a backup refresh in case the modal gets removed
                                                window.bulkGenerationBackupRefresh = setTimeout(function() {
                                                    console.log('Backup refresh triggered - ensuring page refreshes even if UI disappeared');
                                                    window.location.reload();
                                                }, 7000); // 7 seconds as backup
                                            }, 4000);
                                        }, 1500);
                                    } else {
                                        // No items processed - remove modal and reset
                                        $('#bulk-generation-modal').remove();
                                        $button.prop('disabled', false).html('Create All Articles');
                                        $('#gag-process-next').prop('disabled', false).css('opacity', '1');
                                        $('#gag-clear-queue').prop('disabled', false).css('opacity', '1');
                                        
                                        $responseDiv.html('<div style="padding: 15px; background-color: #f7fcfe; border-left: 4px solid #2271b1; display: block;">' +
                                            '<strong>No pending articles found.</strong> Add some recipes first.</div>');
                                    }
                                }
                            },
                            error: function(jqXHR, textStatus, errorThrown) {
                                console.log('Completion check error:', textStatus, errorThrown);
                                // On error, show warning and stop processing to avoid infinite loops
                                $('#bulk-generation-modal').remove();
                                $button.prop('disabled', false).html('Create All Articles');
                                $('#gag-process-next').prop('disabled', false).css('opacity', '1');
                                $('#gag-clear-queue').prop('disabled', false).css('opacity', '1');
                                
                                $responseDiv.html('<div style="padding: 15px; background-color: #fef2f2; border-left: 4px solid #ef4444; display: block;">' +
                                    '<strong>Error:</strong> Could not check completion status (' + textStatus + '). Please check items manually and use "Reset Processing Items" if needed.</div>');
                            }
                        });
                    }
                    
                    function processAll() {
                        console.log('processAll called, totalCount:', totalCount, 'processedCount:', processedCount);
                        
                        // Add safety check to prevent UI disappearing
                        if (!$('#bulk-generation-modal').length) {
                            console.error('Modal disappeared unexpectedly! Stopping processing.');
                            $responseDiv.html('<div style="padding: 15px; background-color: #fef2f2; border-left: 4px solid #ef4444; display: block;">' +
                                '<strong>Error:</strong> Processing interface disappeared unexpectedly. Please try again.</div>');
                            return;
                        }
                        
                        try {
                            processQueueItem(function(response) {
                                console.log('processQueueItem callback, response:', response);
                                
                                // Safety check - ensure modal still exists
                                if (!$('#bulk-generation-modal').length) {
                                    console.error('Modal disappeared during processing callback!');
                                    $responseDiv.html('<div style="padding: 15px; background-color: #fef2f2; border-left: 4px solid #ef4444; display: block;">' +
                                        '<strong>Error:</strong> Processing interface was removed unexpectedly. Please refresh and try again.</div>');
                                    return;
                                }
                                
                                if(response && response.success) {
                                processedCount++;
                                console.log('Incremented processedCount to:', processedCount, 'out of totalCount:', totalCount);
                                var editUrl = response.data.edit_url || ("<?php echo admin_url('post.php?post='); ?>" + response.data.post_id + "&action=edit");
                                var postTitle = response.data.post_title || "Recipe " + response.data.post_id;
                                
                                // Calculate progress percentage
                                var progressPercent = Math.round((processedCount / totalCount) * 100);
                                
                                // Update modal progress counter and bar
                                $('#modal-progress-counter').text(processedCount + '/' + totalCount);
                                $('#modal-progress-bar').css('width', progressPercent + '%');
                                $('#progress-percentage').text(progressPercent + '%');
                                $('#modal-current-recipe').html('✓ Just completed: <strong>"' + postTitle + '"</strong>');
                                
                                // Update the main progress display without replacing the entire HTML
                                var remainingCount = totalCount - processedCount;
                                if (remainingCount > 0) {
                                    // Show that we're continuing to next item
                                    setTimeout(function() {
                                        $('#modal-current-recipe').html('🔄 Preparing next recipe... (' + remainingCount + ' remaining)');
                                    }, 1500);
                                }
                                
                                // Add a 4-second delay: 3 seconds for API rate limiting + 1 second for DB commit
                                setTimeout(function() {
                                    checkForPendingItems();
                                }, 4000);
                            } else {
                                // Even if there's an error, try to continue with the next item
                                console.log('Error processing item, continuing with next...', response);
                                
                                // Update current recipe status to show error but continuing
                                $('#modal-current-recipe').html('⚠️ Error with current item, continuing to next...');
                                
                                // Add a longer delay for errors to prevent cascading failures + DB commit time
                                setTimeout(function() {
                                    checkForPendingItems();
                                }, 6000);
                            }
                        });
                        } catch (error) {
                            console.error('Exception in processAll:', error);
                            // Restore UI if it disappeared due to exception
                            if (!$('#bulk-generation-modal').length) {
                                $('body').append('<div id="bulk-generation-modal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 999999; display: flex; align-items: center; justify-content: center;">' +
                                    '<div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.3); max-width: 500px; width: 90%; position: relative;">' +
                                    '<div style="text-align: center;">' +
                                    '<h2 style="color: #dc3232; margin: 10px 0;">Processing Error</h2>' +
                                    '<p>An unexpected error occurred during processing. The interface will close in 5 seconds.</p>' +
                                    '<button onclick="$(\'#bulk-generation-modal\').remove(); window.location.reload();" style="padding: 10px 20px; background: #0073aa; color: white; border: none; border-radius: 3px; cursor: pointer;">Close & Refresh</button>' +
                                    '</div>' +
                                    '</div>' +
                                    '</div>');
                                
                                setTimeout(function() {
                                    $('#bulk-generation-modal').remove();
                                    window.location.reload();
                                }, 5000);
                            }
                            
                            // Reset buttons
                            $button.prop('disabled', false).html('Create All Articles');
                            $('#gag-process-next').prop('disabled', false).css('opacity', '1');
                            $('#gag-clear-queue').prop('disabled', false).css('opacity', '1');
                            
                            $responseDiv.html('<div style="padding: 15px; background-color: #fef2f2; border-left: 4px solid #ef4444; display: block;">' +
                                '<strong>Error:</strong> An exception occurred during processing. Check console for details.</div>');
                        }
                    }
                    
                    processAll();
                });
                $('#gag-start-processing').on('click', function(e) {
                    e.preventDefault();
                    autoProcessQueue();
                });
                
                function autoProcessQueue() {
                    processQueueItem(function(success) {
                        if (success) {
                            setTimeout(autoProcessQueue, 2000); // Process next item after 2 seconds
                        }
                    });
                }
                
                $('.gag-delete-queue-item').on('click', function(e) {
                    e.preventDefault();
                    var queueId = $(this).data('queue-id');
                    if (confirm('Are you sure you want to delete this item?')) {
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'gag_delete_queue_item',
                                queue_id: queueId,
                                nonce: '<?php echo wp_create_nonce('gag_delete_queue_nonce'); ?>'
                            },
                            success: function(response) {
                                if (response.success) {
                                    $('#queue-item-' + queueId).remove();
                                } else {
                                    alert('Error: ' + response.data.message);
                                }
                            }
                        });
                    }
                });
                
                $('#gag-clear-queue').on('click', function(e) {
                    e.preventDefault();
                    if (confirm('Are you sure you want to clear the entire queue?')) {
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'gag_clear_queue',
                                nonce: '<?php echo wp_create_nonce('gag_clear_queue_nonce'); ?>'
                            },
                            success: function(response) {
                                if (response.success) {
                                    location.reload();
                                } else {
                                    alert('Error: ' + response.data.message);
                                }
                            }
                        });
                    }
                });
                
                $('#rw-reset-processing').on('click', function(e) {
                    e.preventDefault();
                    if (confirm('Reset stuck processing items? This will reset items that have been processing for more than 10 minutes.')) {
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            dataType: 'json',
                            data: {
                                action: 'ga_reset_processing_items',
                                nonce: '<?php echo wp_create_nonce("gag_process_queue_nonce"); ?>'
                            },
                            success: function(response) {
                                if(response.success) {
                                    alert(response.data.message);
                                    location.reload();
                                } else {
                                    alert('Error: ' + response.data.message);
                                }
                            },
                            error: function() {
                                $('#gag-queue-response').html('<div style="padding: 10px; background-color: #ffebe8; border-left: 4px solid #dc3232;">Error clearing queue.</div>');
                            }
                        });
                    }
                });
                
                // Handle individual Recover buttons
                $('.rw-recover-btn').on('click', function(e) {
                    e.preventDefault();
                    var itemId = $(this).data('id');
                    if (confirm('Recover this stuck item? This will reset it to pending status.')) {
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            dataType: 'json',
                            data: {
                                action: 'ga_recover_single_item',
                                item_id: itemId,
                                nonce: '<?php echo wp_create_nonce("gag_process_queue_nonce"); ?>'
                            },
                            success: function(response) {
                                if(response.success) {
                                    alert(response.data.message);
                                    location.reload();
                                } else {
                                    alert('Error: ' + response.data.message);
                                }
                            },
                            error: function() {
                                alert('Error recovering item. Please try again.');
                            }
                        });
                    }
                });
                
                // Function to refresh the table without page reload
                function refreshTable() {
                    $.ajax({
                        url: window.location.href,
                        type: 'GET',
                        success: function(data) {
                            var newTableContent = $(data).find('.rw-table tbody').html();
                            $('.rw-table tbody').html(newTableContent);
                            
                            // Re-bind delete button events
                            $('.gag-delete-queue-item').off('click').on('click', function(e) {
                                e.preventDefault();
                                var queueId = $(this).data('queue-id');
                                var $row = $('#queue-item-' + queueId);
                                
                                if(confirm('Are you sure you want to delete this item?')) {
                                    $.ajax({
                                        url: ajaxurl,
                                        type: 'POST',
                                        dataType: 'json',
                                        data: {
                                            action: 'gag_delete_queue_item',
                                            queue_id: queueId,
                                            nonce: '<?php echo wp_create_nonce("gag_delete_queue_nonce"); ?>'
                                        },
                                        success: function(response) {
                                            if(response.success) {
                                                $row.fadeOut(300, function() {
                                                    $(this).remove();
                                                });
                                            }
                                        }
                                    });
                                }
                            });
                        }
                    });
                }
            });
            </script>
            <?php
        }

        /**
         * Render the "Recipe Card customization" page.
         */
        public function recipe_card_page() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( 'Insufficient permissions.' );
            }
            
            // Force set default values if they're empty or not set
            $header_color = get_option('rw_recipe_card_header_color');
            if (empty($header_color)) {
                $header_color = '#333333';
                update_option('rw_recipe_card_header_color', $header_color);
            }
            
            $accent_color = get_option('rw_recipe_card_accent_color');
            if (empty($accent_color)) {
                $accent_color = '#FF6B6B';
                update_option('rw_recipe_card_accent_color', $accent_color);
            }
            
            $text_color = get_option('rw_recipe_card_text_color');
            if (empty($text_color)) {
                $text_color = '#333333';
                update_option('rw_recipe_card_text_color', $text_color);
            }
            
            $background_color = get_option('rw_recipe_card_background_color');
            if (empty($background_color)) {
                $background_color = '#FFFFFF';
                update_option('rw_recipe_card_background_color', $background_color);
            }
            
            $card_title = get_option('rw_recipe_card_title');
            if (empty($card_title)) {
                $card_title = 'Printable Recipe Card';
                update_option('rw_recipe_card_title', $card_title);
            }
            
            $ingredients_title = get_option('rw_recipe_card_ingredients_title');
            if (empty($ingredients_title)) {
                $ingredients_title = 'Ingredients';
                update_option('rw_recipe_card_ingredients_title', $ingredients_title);
            }
            
            $instructions_title = get_option('rw_recipe_card_instructions_title');
            if (empty($instructions_title)) {
                $instructions_title = 'Instructions';
                update_option('rw_recipe_card_instructions_title', $instructions_title);
            }
            
            $footer_text = get_option('rw_recipe_card_footer_text');
            if (empty($footer_text)) {
                $footer_text = 'Recipe from {site_name}';
                update_option('rw_recipe_card_footer_text', $footer_text);
            }
            
            $button_text = get_option('rw_recipe_card_button_text');
            if (empty($button_text)) {
                $button_text = 'Download Recipe Card';
                update_option('rw_recipe_card_button_text', $button_text);
            }
            
            $show_logo = get_option('rw_recipe_card_show_logo');
            if ($show_logo === false) {
                $show_logo = 1;
                update_option('rw_recipe_card_show_logo', $show_logo);
            }
            
            // Check if we're on a specific tab
            $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'pdf_settings';
            
            // Set frontend box settings if they're empty
            $box_description = get_option('rw_recipe_card_box_description');
            if (empty($box_description)) {
                $box_description = 'Want just the essential recipe details without scrolling through the article? Get our printable recipe card with just the ingredients and instructions.';
                update_option('rw_recipe_card_box_description', $box_description);
            }
            
            // Force set box background color to white
            $box_bg_color = '#ffffff';
            update_option('rw_recipe_card_box_bg_color', $box_bg_color);
            
            $box_text_color = get_option('rw_recipe_card_box_text_color');
            if (empty($box_text_color)) {
                $box_text_color = '#555555';
                update_option('rw_recipe_card_box_text_color', $box_text_color);
            }
            
            $box_border_radius = get_option('rw_recipe_card_box_border_radius');
            if ($box_border_radius === false) {
                $box_border_radius = 12;
                update_option('rw_recipe_card_box_border_radius', $box_border_radius);
            }
            
            $box_shadow = get_option('rw_recipe_card_box_shadow');
            if ($box_shadow === false) {
                $box_shadow = 1;
                update_option('rw_recipe_card_box_shadow', $box_shadow);
            }
            
            // Preview data
            $preview_title = 'Delicious Chocolate Chip Cookies';
            $preview_ingredients = '<ul><li>2 1/4 cups all-purpose flour</li><li>1 teaspoon baking soda</li><li>1 teaspoon salt</li><li>1 cup butter, softened</li><li>3/4 cup granulated sugar</li><li>3/4 cup packed brown sugar</li><li>2 large eggs</li><li>2 teaspoons vanilla extract</li><li>2 cups chocolate chips</li></ul>';
            $preview_instructions = '<ol><li>Preheat oven to 375°F (190°C).</li><li>Combine flour, baking soda, and salt in small bowl.</li><li>Beat butter, granulated sugar, and brown sugar in large mixer bowl.</li><li>Add eggs one at a time, beating well after each addition.</li><li>Stir in vanilla extract.</li><li>Gradually beat in flour mixture.</li><li>Stir in chocolate chips.</li><li>Drop by rounded tablespoon onto ungreased baking sheets.</li><li>Bake for 9 to 11 minutes or until golden brown.</li><li>Cool on baking sheets for 2 minutes; remove to wire racks to cool completely.</li></ol>';
            
            ?>
            <div class="wrap">
                <h1>Recipe Card Customization</h1>
                
                <!-- Tabs navigation -->
                <h2 class="nav-tab-wrapper">
                    <a href="?page=gag-recipe-card&tab=pdf_settings" class="nav-tab <?php echo $active_tab == 'pdf_settings' ? 'nav-tab-active' : ''; ?>">PDF Recipe Card</a>
                    <a href="?page=gag-recipe-card&tab=frontend_box" class="nav-tab <?php echo $active_tab == 'frontend_box' ? 'nav-tab-active' : ''; ?>">Recipe Box</a>
                </h2>
                
                <div style="margin-top: 20px;">
                    <!-- Settings Form -->
                    <form method="post" action="options.php" style="max-width: 100%;">
                            <?php settings_fields('rw_recipe_card_group'); ?>
                            <?php do_settings_sections('rw_recipe_card_group'); ?>
                            
                            <?php if ($active_tab == 'pdf_settings'): ?>
                            <div class="postbox">
                                <h2 class="hndle"><span>PDF Card Content</span></h2>
                                <div class="inside">
                                <table class="form-table">
                                    <tr>
                                        <th scope="row">Card Title</th>
                                        <td>
                                            <input type="text" name="rw_recipe_card_title" value="<?php echo esc_attr($card_title); ?>" class="regular-text">
                                            <p class="description">The title shown at the top of the recipe card section.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Ingredients Title</th>
                                        <td>
                                            <input type="text" name="rw_recipe_card_ingredients_title" value="<?php echo esc_attr($ingredients_title); ?>" class="regular-text">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Instructions Title</th>
                                        <td>
                                            <input type="text" name="rw_recipe_card_instructions_title" value="<?php echo esc_attr($instructions_title); ?>" class="regular-text">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Footer Text</th>
                                        <td>
                                            <input type="text" name="rw_recipe_card_footer_text" value="<?php echo esc_attr($footer_text); ?>" class="regular-text">
                                            <p class="description">Use {site_name} to include your site name.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Button Text</th>
                                        <td>
                                            <input type="text" name="rw_recipe_card_button_text" value="<?php echo esc_attr($button_text); ?>" class="regular-text">
                                            <p class="description">Text shown on the download button.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Show Site Logo</th>
                                        <td>
                                            <label>
                                                <input type="checkbox" name="rw_recipe_card_show_logo" value="1" <?php checked(1, $show_logo); ?>>
                                                Include your site logo on the PDF
                                            </label>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            </div>
                            <div class="postbox" style="margin-top: 20px;">
                                <h2 class="hndle"><span>PDF Appearance</span></h2>
                                <div class="inside">
                                <table class="form-table">
                                    <tr>
                                        <th scope="row">Header Color</th>
                                        <td>
                                            <input type="color" name="rw_recipe_card_header_color" id="rw_recipe_card_header_color" value="<?php echo esc_attr($header_color); ?>">
                                            <p class="description">Color for the recipe title.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Accent Color</th>
                                        <td>
                                            <input type="color" name="rw_recipe_card_accent_color" id="rw_recipe_card_accent_color" value="<?php echo esc_attr($accent_color); ?>">
                                            <p class="description">Color for headings and decorative elements.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Text Color</th>
                                        <td>
                                            <input type="color" name="rw_recipe_card_text_color" id="rw_recipe_card_text_color" value="<?php echo esc_attr($text_color); ?>">
                                            <p class="description">Color for the main text content.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Background Color</th>
                                        <td>
                                            <input type="color" name="rw_recipe_card_background_color" id="rw_recipe_card_background_color" value="<?php echo esc_attr($background_color); ?>">
                                            <p class="description">Background color of the PDF.</p>
                                        </td>
                                    </tr>
                                </table>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if ($active_tab == 'frontend_box'): ?>
                            <div class="postbox">
                                <h2 class="hndle"><span>Recipe Box Content</span></h2>
                                <div class="inside">
                                <table class="form-table">
                                    <tr>
                                        <th scope="row">Box Description</th>
                                        <td>
                                            <textarea name="rw_recipe_card_box_description" rows="3" class="large-text"><?php echo esc_textarea(get_option('rw_recipe_card_box_description', 'Want just the essential recipe details without scrolling through the article? Get our printable recipe card with just the ingredients and instructions.')); ?></textarea>
                                            <p class="description">The text shown in the download box on your website.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Box Background Color</th>
                                        <td>
                                            <input type="color" name="rw_recipe_card_box_bg_color" id="rw_recipe_card_box_bg_color" value="<?php echo esc_attr(get_option('rw_recipe_card_box_bg_color', '#ffffff')); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Box Text Color</th>
                                        <td>
                                            <input type="color" name="rw_recipe_card_box_text_color" id="rw_recipe_card_box_text_color" value="<?php echo esc_attr(get_option('rw_recipe_card_box_text_color', '#555555')); ?>">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Box Border Radius</th>
                                        <td>
                                            <input type="range" name="rw_recipe_card_box_border_radius" min="0" max="20" value="<?php echo esc_attr(get_option('rw_recipe_card_box_border_radius', '12')); ?>" class="widefat" oninput="this.nextElementSibling.value = this.value + 'px'">
                                             <output><?php echo esc_attr(get_option('rw_recipe_card_box_border_radius', '12')); ?>px</output>
                                            <p class="description">Controls the roundness of the box corners.</p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Box Shadow</th>
                                        <td>
                                            <label>
                                                <input type="checkbox" name="rw_recipe_card_box_shadow" value="1" <?php checked(1, get_option('rw_recipe_card_box_shadow', 1)); ?>>
                                                Enable box shadow effect
                                            </label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Show Recipe Cards In</th>
                                        <td>
                                            <?php
                                            // Get all categories
                                            $categories = get_categories(array('hide_empty' => false));
                                            $selected_categories = get_option('rw_recipe_card_categories', array());
                                            
                                            if (!empty($categories)) :
                                            ?>
                                            <fieldset>
                                                <legend class="screen-reader-text">Select categories where recipe cards should appear</legend>
                                                <p class="description">Select categories where recipe cards should appear. If none are selected, cards will appear in all posts that contain recipe content.</p>
                                                <div style="max-height: 200px; overflow-y: auto; padding: 10px; border: 1px solid #ddd; margin-top: 10px;">
                                                <?php foreach ($categories as $category) : ?>
                                                    <label style="display: block; margin-bottom: 8px;">
                                                        <input type="checkbox" name="rw_recipe_card_categories[]" value="<?php echo esc_attr($category->term_id); ?>" <?php checked(in_array($category->term_id, $selected_categories)); ?>>
                                                        <?php echo esc_html($category->name); ?>
                                                    </label>
                                                <?php endforeach; ?>
                                                </div>
                                            </fieldset>
                                            <?php else : ?>
                                            <p>No categories found.</p>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </table>
                                </div>
                            </div>
                            <?php endif; ?>
                            <!-- Live Preview -->
                            <div style="margin-top: 20px; max-width: 100%;">
                            <?php if ($active_tab == 'pdf_settings'): ?>
                            <div class="postbox">
                                <h2 class="hndle"><span>PDF Preview</span></h2>
                                <div class="inside">
                                    <div class="preview-container" style="border: 1px solid #ddd; padding: 20px; border-radius: 8px; background-color: <?php echo esc_attr($background_color); ?>; color: <?php echo esc_attr($text_color); ?>; max-width: 500px; margin: 0 auto;">
                                        <!-- Recipe Title -->
                                        <h1 style="color: <?php echo esc_attr($header_color); ?>; text-align: center; font-size: 24px; margin-bottom: 15px;"><?php echo esc_html($preview_title); ?></h1>
                                        
                                        <!-- Divider -->
                                        <div style="height: 2px; background-color: <?php echo esc_attr($accent_color); ?>; margin: 15px 0;"></div>
                                        
                                        <!-- Ingredients -->
                                        <h3 style="color: <?php echo esc_attr($accent_color); ?>; font-size: 18px; margin: 15px 0 10px;"><?php echo esc_html($ingredients_title); ?></h3>
                                        <div style="color: <?php echo esc_attr($text_color); ?>;">
                                            <?php echo $preview_ingredients; ?>
                                        </div>
                                        
                                        <!-- Instructions -->
                                        <h3 style="color: <?php echo esc_attr($accent_color); ?>; font-size: 18px; margin: 15px 0 10px;"><?php echo esc_html($instructions_title); ?></h3>
                                        <div style="color: <?php echo esc_attr($text_color); ?>;">
                                            <?php echo $preview_instructions; ?>
                                        </div>
                                        
                                        <!-- Footer -->
                                        <div style="margin-top: 20px; text-align: center; font-style: italic; font-size: 12px; color: #777;">
                                            <?php echo str_replace('{site_name}', get_bloginfo('name'), esc_html($footer_text)); ?>
                                        </div>
                                    </div>
                                    <p class="description" style="text-align: center; margin-top: 15px;">This is a simplified preview. The actual PDF may look slightly different.</p>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if ($active_tab == 'frontend_box'): ?>
                            <div class="postbox">
                                <h2 class="hndle"><span>Recipe Box Preview</span></h2>
                                <div class="inside">
                                    <div class="preview-container" style="border: 1px solid #ddd; padding: 20px; background-color: #ffffff; border-radius: <?php echo esc_attr(get_option('rw_recipe_card_box_border_radius', '12')); ?>px; <?php echo get_option('rw_recipe_card_box_shadow', 1) ? 'box-shadow: 0 5px 20px rgba(0,0,0,0.08);' : ''; ?>">
                                        <!-- Box Header -->
                                        <div style="display: flex; align-items: center; margin-bottom: 15px;">
                                            <span class="dashicons dashicons-media-document" style="font-size: 28px; color: <?php echo esc_attr($accent_color); ?>; margin-right: 12px;"></span>
                                            <h3 style="margin: 0; font-size: 22px; color: <?php echo esc_attr(get_option('rw_recipe_card_box_text_color', '#555555')); ?>; font-weight: 600;"><?php echo esc_html($card_title); ?></h3>
                                        </div>
                                        
                                        <!-- Divider -->
                                        <div style="height: 3px; width: 60px; background-color: <?php echo esc_attr($accent_color); ?>; margin-bottom: 20px;"></div>
                                        
                                        <!-- Description -->
                                        <p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5; color: <?php echo esc_attr(get_option('rw_recipe_card_box_text_color', '#555555')); ?>;"><?php echo esc_html(get_option('rw_recipe_card_box_description', 'Want just the essential recipe details without scrolling through the article? Get our printable recipe card with just the ingredients and instructions.')); ?></p>
                                        
                                        <!-- Button -->
                                        <button type="button" style="background-color: <?php echo esc_attr($accent_color); ?>; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 16px; display: inline-flex; align-items: center;">
                                            <span class="dashicons dashicons-pdf" style="margin-right: 8px; font-size: 20px;"></span> <?php echo esc_html($button_text); ?>
                                        </button>
                                    </div>
                                    <p class="description" style="text-align: center; margin-top: 15px;">This is how the download box will appear on your posts.</p>
                                </div>
                            </div>
                            <?php endif; ?>
                            </div>
                            
                            <?php submit_button('Save Changes'); ?>
                        </form>
                    </div>
                </div>
                
                <script type="text/javascript">
                jQuery(document).ready(function($) {
                    <?php if ($active_tab == 'pdf_settings'): ?>
                    // PDF preview updates
                    $('input[name="rw_recipe_card_header_color"]').on('input', function() {
                        $('.preview-container h1').css('color', $(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_accent_color"]').on('input', function() {
                        $('.preview-container h3').css('color', $(this).val());
                        $('.preview-container div[style*="height: 2px"]').css('background-color', $(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_text_color"]').on('input', function() {
                        $('.preview-container').css('color', $(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_background_color"]').on('input', function() {
                        $('.preview-container').css('background-color', $(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_ingredients_title"]').on('input', function() {
                        $('.preview-container h3').first().text($(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_instructions_title"]').on('input', function() {
                        $('.preview-container h3').last().text($(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_footer_text"]').on('input', function() {
                        var footerText = $(this).val().replace('{site_name}', '<?php echo get_bloginfo("name"); ?>');
                        $('.preview-container div[style*="margin-top: 20px"]').text(footerText);
                    });
                    <?php endif; ?>
                    
                    <?php if ($active_tab == 'frontend_box'): ?>
                    // Frontend box preview updates
                    $('input[name="rw_recipe_card_box_bg_color"]').on('input', function() {
                        $('.preview-container').css('background-color', $(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_box_text_color"]').on('input', function() {
                        $('.preview-container h3, .preview-container p').css('color', $(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_box_border_radius"]').on('input', function() {
                        $('.preview-container').css('border-radius', $(this).val() + 'px');
                    });
                    
                    $('input[name="rw_recipe_card_box_shadow"]').on('change', function() {
                        if($(this).is(':checked')) {
                            $('.preview-container').css('box-shadow', '0 5px 20px rgba(0,0,0,0.08)');
                        } else {
                            $('.preview-container').css('box-shadow', 'none');
                        }
                    });
                    
                    $('textarea[name="rw_recipe_card_box_description"]').on('input', function() {
                        $('.preview-container p').text($(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_title"]').on('input', function() {
                        $('.preview-container h3').text($(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_button_text"]').on('input', function() {
                        $('.preview-container button').contents().filter(function() {
                            return this.nodeType === 3; // Text nodes only
                        }).replaceWith(' ' + $(this).val());
                    });
                    
                    $('input[name="rw_recipe_card_accent_color"]').on('input', function() {
                        $('.preview-container .dashicons').css('color', $(this).val());
                        $('.preview-container div[style*="height: 3px"]').css('background-color', $(this).val());
                        $('.preview-container button').css('background-color', $(this).val());
                    });
                    <?php endif; ?>
                });
                </script>
            </div>
            <?php
        }
        
        /**
 * Render the "Image Generator" page.
 */
public function image_generator_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Insufficient permissions.' );
    }

    // We'll store the final media URL here if generation succeeds
    $attachment_url = '';

    // Check if the form was submitted
    if ( isset( $_POST['generate_image'] ) ) {
        // Security check
        check_admin_referer( 'rw_image_generator_nonce', 'rw_image_generator_nonce' );

        // Get form inputs
        $custom_prompt = sanitize_text_field( $_POST['custom_prompt'] );
        $aspect_ratio  = sanitize_text_field( $_POST['aspect_ratio'] );

        // Generate image URL via Replicate
        $generated_url = $this->generate_custom_image( $custom_prompt, $aspect_ratio );
        if ( is_wp_error( $generated_url ) ) {
            // Show error if generation fails
            echo '<div class="error"><p><strong>Error generating image:</strong> ' . esc_html( $generated_url->get_error_message() ) . '</p></div>';
        } else {
            // Sideload the generated image into the media library
            $attachment_result = $this->sideload_and_get_url( $generated_url );
            if ( is_wp_error( $attachment_result ) ) {
                echo '<div class="error"><p><strong>Error sideloading image:</strong> ' . esc_html( $attachment_result->get_error_message() ) . '</p></div>';
            } else {
                // Success! We'll display this in the page
                $attachment_url = $attachment_result;
            }
        }
    }
    ?>

    <div class="wrap">
        <h1>Image Generator</h1>
        <p>Here you can generate images using the Flux API. Customize your prompt and generate an image.</p>

        <form method="post" action="">
            <?php wp_nonce_field( 'rw_image_generator_nonce', 'rw_image_generator_nonce' ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="custom_prompt">Custom Prompt</label></th>
                    <td>
                        <input name="custom_prompt" type="text" id="custom_prompt" value="" class="regular-text" />
                        <p class="description">Enter your custom prompt for the image generation.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="aspect_ratio">Aspect Ratio</label></th>
                    <td>
                        <select name="aspect_ratio" id="aspect_ratio">
                            <option value="2:3">2:3</option>
                            <option value="3:2">3:2</option>
                            <option value="16:9">16:9</option>
                            <option value="9:16">9:16</option>
                        </select>
                        <p class="description">Select the desired aspect ratio.</p>
                    </td>
                </tr>
            </table>

            <?php submit_button( 'Generate Image', 'primary', 'generate_image' ); ?>
        </form>

        <?php if ( $attachment_url ) : ?>
            <hr />
            <h2>Generated Image</h2>
            <img src="<?php echo esc_url( $attachment_url ); ?>" alt="Generated Image" style="max-width: 400px; height: auto;">
            <p>
                <button
                    id="downloadImageBtn"
                    class="button button-secondary"
                    data-image-url="<?php echo esc_url( $attachment_url ); ?>">
                    Download Image
                </button>
            </p>

            <script>
            (function($){
                $('#downloadImageBtn').on('click', function(e) {
                    e.preventDefault();
                    var url = $(this).data('image-url');

                    // Force download using fetch -> blob -> object URL
                    fetch(url)
                        .then(response => response.blob())
                        .then(blob => {
                            var link = document.createElement('a');
                                    link.href = window.URL.createObjectURL(blob);
                                    link.download = 'generated-image.jpg';
                                    document.body.appendChild(link);
                                    link.click();
                                    document.body.removeChild(link);
{{ ... }}
                                })
                                .catch(err => {
                                    console.error('Download error:', err);
                                });
                        });
                    });
                    </script>
                <?php endif; ?>
            </div>
            <?php
        }
        

        /**
         * Generate image prompts based on recipe article content
         */
        private function generate_recipe_image_prompts($article_content, $title) {
            $api_token = get_option('ga_replicate_api_token');
            
            if (empty($api_token)) {
                throw new Exception('Replicate API token is not configured.');
            }

            $image_count = get_option('rw_intext_image_count', 3);

            $prompt = "Based on this recipe article, create {$image_count} diverse and specific food photography prompts for in-text images. Focus on different aspects of the recipe to create visual variety.

Article Title: {$title}

Article Content:
{$article_content}

DIVERSITY REQUIREMENTS:
- Focus on close-up details, final dish presentations, and tasty top-view shots
- NO RAW INGREDIENT SHOTS - focus on cooked/prepared food only
- Vary the focus: some images should be cooking process, others final presentation shots
- Create appetizing perspectives: overhead shots, close-up details, final plated dishes
- Show different stages: cooking process, plated dishes, or final presentation

SHOT TYPE EXAMPLES:
- Close-up detail: \"Close-up of [specific cooked element] with [texture/color details], shallow depth of field, food styling\"
- Final dish: \"Beautifully plated [dish name] with [garnish/presentation details] on [plate type], restaurant quality presentation\"
- Tasty top view: \"Overhead shot of [dish name] showing [specific details], appetizing top-down view, food styling\"
- Cooking process: \"[Dish name] being prepared, showing [cooking technique] in action, professional kitchen photography\"

CONTENT REQUIREMENTS:
- Extract specific ingredients, colors, and textures from the recipe
- Focus on the cooking methods and techniques mentioned
- Include any garnishes, seasonings, or presentation details
- Make the food look absolutely delicious and appetizing
- Professional food photography quality
- No people in scenes, focus purely on the food
- Use natural lighting and clean compositions

Create {$image_count} varied prompts that would work well as in-text images throughout a recipe article.

Format as a numbered list:
1. [Food photography prompt]
2. [Food photography prompt]
etc.";

            $data = array(
                'stream' => false,
                'input' => array(
                    'prompt' => $prompt
                )
            );

            // Validate data before encoding
            if ( empty( $data ) || ! is_array( $data ) ) {
                throw new Exception('Invalid data structure for API request.');
            }
            
            $encoded_body = wp_json_encode( $data );
            if ( $encoded_body === false ) {
                throw new Exception('Failed to encode request data as JSON.');
            }
            
            $response = wp_remote_post('https://api.replicate.com/v1/models/openai/gpt-5/predictions', array(
                'headers' => array(
                    'Authorization' => 'Token ' . $api_token,
                    'Content-Type' => 'application/json',
                ),
                'body' => $encoded_body,
                'timeout' => 60,
            ));

            if (is_wp_error($response)) {
                throw new Exception('Image prompt generation failed: ' . $response->get_error_message());
            }

            $body = wp_remote_retrieve_body($response);
            $result = json_decode($body, true);

            if (!isset($result['id'])) {
                throw new Exception('Failed to start image prompt generation: ' . $body);
            }

            // Poll for completion
            $prediction_id = $result['id'];
            $max_attempts = 20;
            $attempt = 0;

            while ($attempt < $max_attempts) {
                sleep(2);
                
                $status_response = wp_remote_get('https://api.replicate.com/v1/predictions/' . $prediction_id, array(
                    'headers' => array(
                        'Authorization' => 'Token ' . $api_token,
                    ),
                    'timeout' => 30,
                ));

                if (is_wp_error($status_response)) {
                    $attempt++;
                    continue;
                }

                $status_body = wp_remote_retrieve_body($status_response);
                $status_result = json_decode($status_body, true);

                if ($status_result['status'] === 'succeeded') {
                    $output = is_array($status_result['output']) ? implode('', $status_result['output']) : $status_result['output'];
                    
                    // Parse the numbered list into an array
                    $prompts = array();
                    preg_match_all('/\d+\.\s*(.+?)(?=\d+\.|$)/s', $output, $matches);
                    
                    if (!empty($matches[1])) {
                        foreach ($matches[1] as $prompt) {
                            $prompts[] = trim($prompt);
                        }
                    }
                    
                    return $prompts;
                } elseif ($status_result['status'] === 'failed') {
                    throw new Exception('Image prompt generation failed: ' . json_encode($status_result['error']));
                }

                $attempt++;
            }

            throw new Exception('Image prompt generation timed out');
        }

        /**
         * Generate images using Seedream-3 API
         */
        private function generate_intext_images($prompts) {
            $api_token = get_option('ga_replicate_api_token');
            
            if (empty($api_token)) {
                throw new Exception('Replicate API token is not configured.');
            }

            $generated_images = array();

            foreach ($prompts as $index => $prompt) {
                try {
                    $enhanced_prompt = "Food photography, " . $prompt . ", professional food photography, high quality, appetizing, restaurant quality, clean composition, food styling";
                    
                    $data = array(
                        'input' => array(
                            'prompt' => $enhanced_prompt,
                            'width' => 576,
                            'height' => 1024,
                            'aspect_ratio' => '9:16',
                            'guidance_scale' => 2.5
                        )
                    );

                    $response = wp_remote_post('https://api.replicate.com/v1/models/bytedance/seedream-3/predictions', array(
                        'headers' => array(
                            'Authorization' => 'Token ' . $api_token,
                            'Content-Type' => 'application/json',
                        ),
                        'body' => json_encode($data),
                        'timeout' => 60,
                    ));

                    if (is_wp_error($response)) {
                        error_log('Image generation request failed for prompt ' . ($index + 1) . ': ' . $response->get_error_message());
                        continue;
                    }

                    $body = wp_remote_retrieve_body($response);
                    $result = json_decode($body, true);

                    if (!isset($result['id'])) {
                        error_log('Failed to start image generation for prompt ' . ($index + 1) . ': ' . $body);
                        continue;
                    }

                    // Poll for completion
                    $prediction_id = $result['id'];
                    $max_attempts = 30;
                    $attempt = 0;

                    while ($attempt < $max_attempts) {
                        sleep(3);
                        
                        $status_response = wp_remote_get('https://api.replicate.com/v1/predictions/' . $prediction_id, array(
                            'headers' => array(
                                'Authorization' => 'Token ' . $api_token,
                            ),
                            'timeout' => 30,
                        ));

                        if (is_wp_error($status_response)) {
                            $attempt++;
                            continue;
                        }

                        $status_body = wp_remote_retrieve_body($status_response);
                        $status_result = json_decode($status_body, true);

                        if ($status_result['status'] === 'succeeded' && !empty($status_result['output'])) {
                            $image_url = is_array($status_result['output']) ? $status_result['output'][0] : $status_result['output'];
                            
                            // Download and save to media library with descriptive alt text
                            $alt_text = $this->generate_alt_text_from_prompt($prompts[$index]);
                            $saved_image = $this->save_image_to_media_library($image_url, $alt_text, $index);
                            
                            if ($saved_image && !is_wp_error($saved_image)) {
                                $saved_image['original_index'] = $index; // Preserve original prompt order
                                $saved_image['alt'] = $alt_text; // Override with descriptive alt text
                                $generated_images[] = $saved_image;
                            }
                            break;
                        } elseif ($status_result['status'] === 'failed') {
                            error_log('Image generation failed for prompt ' . ($index + 1) . ': ' . json_encode($status_result['error']));
                            break;
                        }

                        $attempt++;
                    }
                } catch (Exception $e) {
                    error_log('Exception during image generation for prompt ' . ($index + 1) . ': ' . $e->getMessage());
                    continue;
                }
            }

            return $generated_images;
        }

        /**
         * Generate descriptive alt text from image prompt
         */
        private function generate_alt_text_from_prompt($prompt) {
            // Clean up the prompt to create simple alt text
            $alt_text = $prompt;
            
            // Remove common photography terms
            $alt_text = preg_replace('/food photography,?\s*/i', '', $alt_text);
            $alt_text = preg_replace('/professional food photography,?\s*/i', '', $alt_text);
            $alt_text = preg_replace('/high quality,?\s*/i', '', $alt_text);
            $alt_text = preg_replace('/appetizing,?\s*/i', '', $alt_text);
            $alt_text = preg_replace('/restaurant quality,?\s*/i', '', $alt_text);
            $alt_text = preg_replace('/clean composition,?\s*/i', '', $alt_text);
            $alt_text = preg_replace('/food styling,?\s*/i', '', $alt_text);
            $alt_text = preg_replace('/shallow depth of field,?\s*/i', '', $alt_text);
            $alt_text = preg_replace('/natural lighting,?\s*/i', '', $alt_text);
            $alt_text = preg_replace('/top-down view,?\s*/i', '', $alt_text);
            
            // Clean up extra commas and spaces
            $alt_text = preg_replace('/,\s*,/', ',', $alt_text);
            $alt_text = preg_replace('/^,\s*/', '', $alt_text);
            $alt_text = preg_replace('/,\s*$/', '', $alt_text);
            $alt_text = trim($alt_text);
            
            // Limit length and capitalize first letter
            $alt_text = substr($alt_text, 0, 100);
            $alt_text = ucfirst($alt_text);
            
            return $alt_text;
        }

        /**
         * Insert images into recipe content with specific placement:
         * - Under first heading (not H1)
         * - Under third heading 
         * - Before fifth heading (any level)
         */
        private function insert_images_into_recipe_content($content, $images) {
            if (empty($images)) {
                return $content;
            }

            // Find all headings (H2, H3, H4, H5, H6 - excluding H1)
            preg_match_all('/<h([2-6])[^>]*>.*?<\/h[2-6]>/is', $content, $heading_matches, PREG_OFFSET_CAPTURE);
            
            if (empty($heading_matches[0])) {
                // No headings found, append images at the end
                foreach ($images as $image) {
                    $image_html = $this->create_image_html($image);
                    $content .= $image_html;
                }
                return $content;
            }

            $headings = $heading_matches[0];
            $final_content = $content;
            $image_index = 0;
            
            // Insert images at specific positions (reverse order to maintain offsets)
            $insertions = array();
            
            // 1. Under first heading (not H1)
            if (isset($headings[0]) && $image_index < count($images)) {
                $position = $headings[0][1] + strlen($headings[0][0]);
                $insertions[] = array('position' => $position, 'image' => $images[$image_index]);
                $image_index++;
            }
            
            // 2. Under third heading
            if (isset($headings[2]) && $image_index < count($images)) {
                $position = $headings[2][1] + strlen($headings[2][0]);
                $insertions[] = array('position' => $position, 'image' => $images[$image_index]);
                $image_index++;
            }
            
            // 3. Before fifth heading (any level)
            if ($image_index < count($images) && isset($headings[4])) {
                $insertions[] = array('position' => $headings[4][1], 'image' => $images[$image_index]);
                $image_index++;
            }
            
            // Sort insertions by position (descending to maintain offsets)
            usort($insertions, function($a, $b) {
                return $b['position'] - $a['position'];
            });
            
            // Apply insertions
            foreach ($insertions as $insertion) {
                $image_html = $this->create_image_html($insertion['image']);
                $final_content = substr_replace($final_content, $image_html, $insertion['position'], 0);
            }
            
            // If we have remaining images, append them at the end
            while ($image_index < count($images)) {
                $image_html = $this->create_image_html($images[$image_index]);
                $final_content .= $image_html;
                $image_index++;
            }

            return $final_content;
        }

        /**
         * Create HTML for an image with styling
         */
        private function create_image_html($image) {
            $image_html = '<div style="margin: 20px 0; text-align: center;">';
            $image_html .= '<img src="' . esc_url($image['url']) . '" alt="' . esc_attr($image['alt']) . '" style="max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1);" />';
            $image_html .= '</div>';
            return $image_html;
        }

        /**
         * AJAX handler: Process the next queue item (generate article + images).
         */
        public function ajax_process_queue_item() {
            if ( ! current_user_can( 'manage_options' ) ) {
                error_log( 'Recipe Writer: AJAX process queue item - insufficient permissions for user: ' . get_current_user_id() );
                wp_send_json_error( array( 'message' => 'Insufficient permissions.' ) );
            }
            
            // Enhanced nonce verification with better error logging
            if ( ! check_ajax_referer( 'gag_process_queue_nonce', 'nonce', false ) ) {
                error_log( 'Recipe Writer: AJAX process queue item - nonce verification failed' );
                wp_send_json_error( array( 'message' => 'Security check failed. Please refresh the page and try again.' ) );
            }
            $args = array(
                'post_type'      => 'gag_queue',
                'post_status'    => 'any',
                'meta_query'     => array(
                    array(
                        'key'   => '_ga_status',
                        'value' => 'pending',
                    )
                ),
                'posts_per_page' => 1,
                'orderby'        => 'date',
                'order'          => 'ASC'
            );
            $queue_items = get_posts( $args );
            if ( empty( $queue_items ) ) {
                wp_send_json_error( array( 'message' => 'No pending queue items found.' ) );
            }
            $queue_item = $queue_items[0];
            $title = $queue_item->post_title;
            update_post_meta( $queue_item->ID, '_ga_status', 'processing' );
            update_post_meta( $queue_item->ID, '_ga_processing_started', current_time('timestamp') );

            try {
                $article_content = $this->generate_article( $title );
                if ( is_wp_error( $article_content ) ) {
                    update_post_meta( $queue_item->ID, '_ga_status', 'error' );
                    update_post_meta( $queue_item->ID, '_ga_error_message', $article_content->get_error_message() );
                    wp_send_json_error( array( 'message' => 'Error generating article: ' . $article_content->get_error_message() ) );
                }
            } catch ( Exception $e ) {
                update_post_meta( $queue_item->ID, '_ga_status', 'error' );
                update_post_meta( $queue_item->ID, '_ga_error_message', 'Exception: ' . $e->getMessage() );
                error_log( 'Recipe Writer: Exception in article generation: ' . $e->getMessage() );
                wp_send_json_error( array( 'message' => 'Exception during article generation: ' . $e->getMessage() ) );
            }
            
            // Store prediction ID for recovery (if available from generate_article)
            $prediction_id = get_post_meta( $queue_item->ID, '_ga_article_prediction_id', true );
            if ( empty( $prediction_id ) && method_exists( $this, 'get_last_prediction_id' ) ) {
                $prediction_id = $this->get_last_prediction_id();
                if ( $prediction_id ) {
                    update_post_meta( $queue_item->ID, '_ga_article_prediction_id', $prediction_id );
                }
            }
            
            // Extract AI-generated title from H1 tag and use it as post title
            $new_post_title = $title; // fallback to original
            if (preg_match('/<h1[^>]*>(.*?)<\/h1>/is', $article_content, $matches)) {
                $ai_title = strip_tags(trim($matches[1]));
                if (!empty($ai_title)) {
                    $new_post_title = $ai_title;
                }
            }
            
            // Debug: Log what we found for troubleshooting
            error_log("=== TITLE EXTRACTION DEBUG ===");
            error_log("Original title: " . $title);
            error_log("AI generated title: " . $new_post_title);
            error_log("Article content preview: " . substr($article_content, 0, 800));
            error_log("H1 regex match result: " . (preg_match('/<h1[^>]*>(.*?)<\/h1>/is', $article_content, $debug_matches) ? "FOUND: " . $debug_matches[1] : "NOT FOUND"));
            error_log("=== END DEBUG ===");
            
            // Remove the H1 tag from content since we're using it as the post title
            $article_content = preg_replace('/<h1[^>]*>.*?<\/h1>/is', '', $article_content, 1);
            
            // Remove any h1 or h2 tag that contains 'Introduction' to clean up the content
            $article_content = preg_replace('/<(h1|h2)[^>]*>\s*Introduction\s*<\/(h1|h2)>/is', '', $article_content);
            
            // Remove duplicate title only if it appears as a standalone line at the beginning
            // This prevents cutting off content that starts with similar words to the title
            $article_content = preg_replace('/^' . preg_quote($title, '/') . '\s*\n/i', '', trim($article_content));
            $article_content = preg_replace('/^' . preg_quote($title, '/') . '\s*<\/p>/i', '', $article_content);
            $article_content = preg_replace('/^<p>\s*' . preg_quote($title, '/') . '\s*<\/p>/i', '', $article_content);
            
            // Remove DeepSeek markdown artifacts (```html at start and ``` at end)
            $article_content = preg_replace('/^```html\s*/i', '', $article_content);
            $article_content = preg_replace('/\s*```\s*$/i', '', $article_content);
            
            // Remove any remaining markdown code block indicators
            $article_content = preg_replace('/^```[a-zA-Z]*\s*/i', '', $article_content);
            $article_content = trim($article_content);
            
            $post_data = array(
                'post_title'   => $new_post_title,
                'post_content' => $article_content,
                'post_status'  => 'draft',
                'post_author'  => get_current_user_id(),
                'post_type'    => 'post'
            );
            $post_id = wp_insert_post( $post_data );
            if ( is_wp_error( $post_id ) ) {
                update_post_meta( $queue_item->ID, '_ga_status', 'error' );
                update_post_meta( $queue_item->ID, '_ga_error_message', $post_id->get_error_message() );
                wp_send_json_error( array( 'message' => 'Error creating post: ' . $post_id->get_error_message() ) );
            }

            // Generate & attach featured image (don't stop process if it fails)
            $featured_image = $this->generate_featured_image( $title );
            if ( is_wp_error( $featured_image ) ) {
                error_log('Featured image generation failed, continuing with in-text images: ' . $featured_image->get_error_message());
                update_post_meta($queue_item->ID, '_ga_featured_image_error', $featured_image->get_error_message());
            } else {
                $attach_result = $this->attach_featured_image( $featured_image, $post_id );
                if ( is_wp_error( $attach_result ) ) {
                    error_log('Featured image attachment failed: ' . $attach_result->get_error_message());
                    update_post_meta($queue_item->ID, '_ga_featured_image_error', $attach_result->get_error_message());
                }
            }

            // Generate and insert in-text images if enabled
            $final_content = $article_content;
            if (get_option('rw_enable_intext_images', 1)) {
                error_log('Starting in-text image generation for post: ' . $new_post_title);
                try {
                    // Generate image prompts based on the article content
                    error_log('Generating image prompts...');
                    $image_prompts = $this->generate_recipe_image_prompts($article_content, $new_post_title);
                    error_log('Generated prompts: ' . print_r($image_prompts, true));
                    
                    if (!empty($image_prompts)) {
                        // Generate images using Seedream-3
                        error_log('Starting Seedream-3 image generation for ' . count($image_prompts) . ' prompts');
                        $intext_images = $this->generate_intext_images($image_prompts);
                        error_log('Generated images: ' . print_r($intext_images, true));
                        
                        if (!empty($intext_images)) {
                            // Insert images into content with varied placement
                            error_log('Inserting ' . count($intext_images) . ' images into content');
                            $final_content = $this->insert_images_into_recipe_content($article_content, $intext_images);
                            error_log('Successfully generated and inserted ' . count($intext_images) . ' in-text images');
                        } else {
                            error_log('No in-text images were generated - generate_intext_images returned empty array');
                        }
                    } else {
                        error_log('No image prompts were generated - generate_recipe_image_prompts returned empty');
                    }
                } catch (Exception $e) {
                    // If in-text image generation fails, continue with article only
                    error_log('In-text image generation failed, continuing with text-only article: ' . $e->getMessage());
                    update_post_meta($queue_item->ID, '_ga_intext_image_error', $e->getMessage());
                }
            } else {
                error_log('In-text images are disabled in settings');
            }

            // Create WP Recipe Maker recipe if enabled (English only)
            $article_language = get_option('rw_article_language', 'english');
            if (get_option('rw_enable_wprm_integration', 0)) {
                if ($article_language === 'english') {
                    error_log('WP Recipe Maker integration is enabled for English article, attempting to create recipe...');
                    try {
                        $featured_image_id = get_post_thumbnail_id($post_id);
                        $wprm_recipe_id = $this->create_wprm_recipe($new_post_title, $final_content, $featured_image_id);
                        
                        if ($wprm_recipe_id) {
                            error_log('Successfully created WP Recipe Maker recipe with ID: ' . $wprm_recipe_id);
                            // Insert shortcode into content
                            $final_content = $this->insert_wprm_shortcode($final_content, $wprm_recipe_id);
                            error_log('Inserted WPRM shortcode into post content');
                        } else {
                            error_log('Failed to create WP Recipe Maker recipe - check if WPRM is installed and content has ingredients/instructions');
                        }
                    } catch (Exception $e) {
                        error_log('WP Recipe Maker integration failed: ' . $e->getMessage());
                        update_post_meta($queue_item->ID, '_ga_wprm_error', $e->getMessage());
                    }
                } else {
                    error_log('WP Recipe Maker integration skipped - only available for English language (current: ' . $article_language . ')');
                }
            } else {
                error_log('WP Recipe Maker integration is disabled in settings');
            }

            // Update post with final content (with or without images and WPRM)
            wp_update_post( array(
                'ID' => $post_id,
                'post_content' => $final_content,
                'post_status' => 'draft'
            ));

            // Update queue item metadata
            update_post_meta( $queue_item->ID, '_ga_status', 'completed' );
            update_post_meta( $queue_item->ID, '_ga_generated_post_id', $post_id );
            
            // Send a clear success response with all necessary data
            wp_send_json_success( array( 
                'message' => 'Recipe generated successfully', 
                'post_id' => $post_id,
                'post_title' => get_the_title($post_id),
                'edit_url' => get_edit_post_link($post_id, 'raw')
            ));
            // No need for wp_die() as wp_send_json_success() already calls it
        }

        /**
         * AJAX handler to delete a queue item.
         */
        public function ajax_delete_queue_item() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_send_json_error( array( 'message' => 'Insufficient permissions.' ) );
            }
            check_ajax_referer( 'gag_delete_queue_nonce', 'nonce' );
            $queue_id = isset( $_POST['queue_id'] ) ? intval( $_POST['queue_id'] ) : 0;
            if ( $queue_id <= 0 ) {
                wp_send_json_error( array( 'message' => 'Invalid queue item ID.' ) );
            }
            $deleted = wp_delete_post( $queue_id, true );
            if ( $deleted ) {
                wp_send_json_success( array( 'message' => 'Queue item deleted successfully.' ) );
            } else {
                wp_send_json_error( array( 'message' => 'Failed to delete queue item.' ) );
            }
            wp_die();
        }

        /**
         * AJAX handler to clear the entire queue.
         */
        public function ajax_clear_queue() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_send_json_error( array( 'message' => 'Insufficient permissions.' ) );
            }
            check_ajax_referer( 'gag_clear_queue_nonce', 'nonce' );
            $args = array(
                'post_type'      => 'gag_queue',
                'post_status'    => 'any',
                'posts_per_page' => -1,
            );
            $queue_items = get_posts( $args );
            $deleted_count = 0;
            if ( $queue_items ) {
                foreach ( $queue_items as $item ) {
                    if ( wp_delete_post( $item->ID, true ) ) {
                        $deleted_count++;
                    }
                }
            }
            wp_send_json_success( array( 'message' => 'Cleared ' . $deleted_count . ' queue items.' ) );
            wp_die();
        }
        
        /**
         * AJAX handler to check if there are pending items in the queue.
         */
        public function ajax_check_pending_items() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_send_json_error( array( 'message' => 'Insufficient permissions.' ) );
            }
            check_ajax_referer( 'gag_process_queue_nonce', 'nonce' );
            
            $args = array(
                'post_type'      => 'gag_queue',
                'post_status'    => 'any',
                'meta_query'     => array(
                    array(
                        'key'   => '_ga_status',
                        'value' => 'pending',
                    )
                ),
                'posts_per_page' => 1,
            );
            $queue_items = get_posts( $args );
            
            wp_send_json_success( array( 
                'has_pending' => !empty($queue_items),
                'count' => count($queue_items)
            ));
        }

        /**
         * AJAX handler to check completion status of all items in the queue.
         */
        public function ajax_check_completion_status() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_send_json_error( array( 'message' => 'Insufficient permissions.' ) );
            }
            check_ajax_referer( 'gag_process_queue_nonce', 'nonce' );
            
            // Get all queue items
            $args = array(
                'post_type'      => 'gag_queue',
                'post_status'    => 'any',
                'posts_per_page' => -1,
            );
            $all_items = get_posts( $args );
            
            $pending_count = 0;
            $completed_count = 0;
            $processing_count = 0;
            $error_count = 0;
            
            foreach ( $all_items as $item ) {
                $status = get_post_meta( $item->ID, '_ga_status', true );
                switch ( $status ) {
                    case 'pending':
                        $pending_count++;
                        break;
                    case 'completed':
                        $completed_count++;
                        break;
                    case 'processing':
                        $processing_count++;
                        break;
                    case 'error':
                        $error_count++;
                        break;
                }
            }
            
            $total_items = count( $all_items );
            $has_pending = $pending_count > 0;
            $all_completed = ( $completed_count === $total_items && $total_items > 0 );
            
            // Debug logging
            error_log( 'Recipe Writer: Completion status check - Total: ' . $total_items . ', Completed: ' . $completed_count . ', Pending: ' . $pending_count . ', Processing: ' . $processing_count . ', Error: ' . $error_count );
            
            wp_send_json_success( array( 
                'has_pending' => $has_pending,
                'all_completed' => $all_completed,
                'total_items' => $total_items,
                'completed_count' => $completed_count,
                'pending_count' => $pending_count,
                'stuck_count' => $processing_count,
                'error_count' => $error_count
            ));
        }

        /**
         * AJAX handler to count pending items in the queue.
         */
        public function ajax_count_pending_items() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_send_json_error( array( 'message' => 'Insufficient permissions.' ) );
            }
            check_ajax_referer( 'gag_process_queue_nonce', 'nonce' );
            
            $args = array(
                'post_type'      => 'gag_queue',
                'post_status'    => 'any',
                'meta_query'     => array(
                    array(
                        'key'   => '_ga_status',
                        'value' => 'pending',
                    )
                ),
                'posts_per_page' => -1,
            );
            $queue_items = get_posts( $args );
            
            // Debug logging
            error_log( 'Recipe Writer: Count pending items - Found ' . count($queue_items) . ' items' );
            error_log( 'Recipe Writer: Query args: ' . print_r($args, true) );
            
            // Also check ALL items to see what's happening
            $all_args = array(
                'post_type'      => 'gag_queue',
                'post_status'    => 'any',
                'posts_per_page' => -1,
            );
            $all_items = get_posts( $all_args );
            error_log( 'Recipe Writer: Total queue items found: ' . count($all_items) );
            
            if ( !empty($all_items) ) {
                foreach( $all_items as $item ) {
                    $status = get_post_meta( $item->ID, '_ga_status', true );
                    error_log( 'Recipe Writer: Item "' . $item->post_title . '" (ID: ' . $item->ID . ') has status: "' . $status . '"' );
                }
            }
            
            if ( !empty($queue_items) ) {
                foreach( $queue_items as $item ) {
                    $status = get_post_meta( $item->ID, '_ga_status', true );
                    error_log( 'Recipe Writer: PENDING Item "' . $item->post_title . '" has status: ' . $status );
                }
            }
            
            // Fix any items that don't have _ga_status set
            $fixed_count = 0;
            foreach( $all_items as $item ) {
                $status = get_post_meta( $item->ID, '_ga_status', true );
                if ( empty($status) ) {
                    // Set default status to pending for items without status
                    update_post_meta( $item->ID, '_ga_status', 'pending' );
                    $fixed_count++;
                    error_log( 'Recipe Writer: Fixed missing status for item: ' . $item->post_title );
                }
            }
            
            // If we fixed any items, re-query to get the correct count
            if ( $fixed_count > 0 ) {
                $queue_items = get_posts( $args );
                error_log( 'Recipe Writer: Fixed ' . $fixed_count . ' items, new pending count: ' . count($queue_items) );
            }
            
            wp_send_json_success( array( 
                'count' => count($queue_items),
                'debug_info' => array(
                    'found_items' => count($queue_items),
                    'total_items' => count($all_items),
                    'fixed_items' => $fixed_count,
                    'query_args' => $args
                )
            ));
        }

        /**
         * AJAX handler to reset processing items that are stuck.
         */
        public function ajax_reset_processing_items() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_send_json_error( array( 'message' => 'Insufficient permissions.' ) );
            }
            check_ajax_referer( 'gag_process_queue_nonce', 'nonce' );
            
            // Find items that have been processing for more than 10 minutes
            $ten_minutes_ago = current_time('timestamp') - (10 * 60);
            
            $args = array(
                'post_type'      => 'gag_queue',
                'post_status'    => 'any',
                'meta_query'     => array(
                    'relation' => 'AND',
                    array(
                        'key'   => '_ga_status',
                        'value' => 'processing',
                    ),
                    array(
                        'key'   => '_ga_processing_started',
                        'value' => $ten_minutes_ago,
                        'compare' => '<',
                        'type' => 'NUMERIC'
                    )
                ),
                'posts_per_page' => -1,
            );
            
            $stuck_items = get_posts( $args );
            $reset_count = 0;
            
            foreach ( $stuck_items as $item ) {
                update_post_meta( $item->ID, '_ga_status', 'pending' );
                delete_post_meta( $item->ID, '_ga_processing_started' );
                delete_post_meta( $item->ID, '_ga_error_message' );
                $reset_count++;
                error_log( 'Recipe Writer: Reset stuck item: ' . $item->post_title );
            }
            
            wp_send_json_success( array( 
                'message' => 'Reset ' . $reset_count . ' stuck processing items.',
                'count' => $reset_count
            ));
        }

        /**
         * AJAX handler to recover a single stuck processing item.
         */
        public function ajax_recover_single_item() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_send_json_error( array( 'message' => 'Insufficient permissions.' ) );
            }
            check_ajax_referer( 'gag_process_queue_nonce', 'nonce' );
            
            $item_id = isset( $_POST['item_id'] ) ? intval( $_POST['item_id'] ) : 0;
            if ( $item_id <= 0 ) {
                wp_send_json_error( array( 'message' => 'Invalid item ID.' ) );
            }
            
            // Check if the item exists and is in processing status
            $item = get_post( $item_id );
            if ( ! $item || $item->post_type !== 'gag_queue' ) {
                wp_send_json_error( array( 'message' => 'Item not found.' ) );
            }
            
            $status = get_post_meta( $item_id, '_ga_status', true );
            if ( $status !== 'processing' ) {
                wp_send_json_error( array( 'message' => 'Item is not in processing status.' ) );
            }
            
            // Reset the item to pending
            update_post_meta( $item_id, '_ga_status', 'pending' );
            delete_post_meta( $item_id, '_ga_processing_started' );
            delete_post_meta( $item_id, '_ga_error_message' );
            
            error_log( 'Recipe Writer: Manually recovered item: ' . $item->post_title );
            
            wp_send_json_success( array( 
                'message' => 'Item "' . $item->post_title . '" has been recovered and reset to pending status.'
            ));
        }

        /**
         * Helper: Insert a string AFTER the nth complete <tag> block.
         */
        private function insert_after_nth_tag( $text, $tag, $n, $insert ) {
            $pattern = '/(<' . $tag . '[^>]*>.*?<\/' . $tag . '>)/is';
            $i = 0;
            return preg_replace_callback($pattern, function($matches) use ($n, $insert, &$i) {
                $i++;
                if ($i === $n) {
                    return $matches[1] . "\n" . $insert;
                }
                return $matches[1];
            }, $text);
        }

        /**
         * Helper: Add paragraph breaks after every X sentences.
         */
        private function add_paragraph_breaks( $text, $group_size = 3 ) {
            $text = preg_replace('/\s+/', ' ', $text);
            $sentences = preg_split('/(?<=[.?!])\s+(?=[A-Z])/', $text);
            $groups = array();
            $group = array();
            foreach ($sentences as $sentence) {
                $trimmed = trim($sentence);
                if (!empty($trimmed)) {
                    $group[] = $trimmed;
                    if (count($group) >= $group_size) {
                        $groups[] = implode(' ', $group);
                        $group = array();
                    }
                }
            }
            if (!empty($group)) {
                $groups[] = implode(' ', $group);
            }
            return implode("\n\n", $groups);
        }

        /**
         * Generate article content using the Replicate API with selected LLM.
         */
        public function generate_article( $title ) {
            $replicate_key = get_option( 'ga_replicate_api_token' );
            if ( empty( $replicate_key ) ) {
                return new WP_Error( 'missing_api_key', 'Replicate API token is missing.' );
            }
            
            $selected_llm = get_option( 'rw_selected_llm', 'chatgpt' );
            $model_config = $this->get_llm_model_config( $selected_llm );
            
            if ( is_wp_error( $model_config ) ) {
                return $model_config;
            }
            // Get article length setting with DeepSeek-specific enforcement
            $article_length = get_option('rw_article_length', '900-1200');
            $length_instruction = ($article_length === '600-900') ? 
                'The article should be approximately 600-900 words.' : 
                'The article should be approximately 900-1200 words.';
            
            // Get language setting and create language instruction
            $article_language = get_option('rw_article_language', 'english');
            $language_names = array(
                'english' => 'English',
                'spanish' => 'Spanish',
                'french' => 'French',
                'german' => 'German',
                'polish' => 'Polish'
            );
            $language_name = isset($language_names[$article_language]) ? $language_names[$article_language] : 'English';
            $language_instruction = "IMPORTANT: Write this entire article in {$language_name}. The article is for an audience that speaks {$language_name}, so use language patterns and expressions that are typical and natural for {$language_name} speakers. Make it sound authentic and native to that language. Use simple, clear, natural language - avoid overly complex or trying-too-hard writing.";
            
            // Generate random heading variations for each language
            $headings_by_language = array(
                'english' => array(
                    'what_makes_good' => array("What Makes This Recipe So Good", "Why This Recipe Works", "What Makes This Special"),
                    'ingredients' => array("Ingredients", "What You'll Need", "Shopping List"),
                    'instructions' => array("Instructions", "Step-by-Step Instructions", "How to Make It"),
                    'storage' => array("Storage Instructions", "How to Store", "Keeping It Fresh"),
                    'benefits' => array("Benefits of This Recipe", "Why This is Good for You", "Health Benefits"),
                    'mistakes' => array("Common Mistakes to Avoid", "What Not to Do", "Pitfalls to Watch Out For"),
                    'alternatives' => array("Alternatives", "Variations You Can Try", "Recipe Variations"),
                    'final_thoughts' => array("Final Thoughts", "Wrapping Up", "In Conclusion")
                ),
                'spanish' => array(
                    'what_makes_good' => array("Por Qué Esta Receta Es Tan Buena", "Lo Que Hace Especial Esta Receta", "Por Qué Funciona Esta Receta"),
                    'ingredients' => array("Ingredientes", "Lo Que Necesitas", "Lista de Ingredientes"),
                    'instructions' => array("Instrucciones", "Paso a Paso", "Cómo Prepararlo"),
                    'storage' => array("Cómo Conservar", "Almacenamiento", "Mantenerlo Fresco"),
                    'benefits' => array("Beneficios de Esta Receta", "Por Qué Es Bueno Para Ti", "Ventajas Nutricionales"),
                    'mistakes' => array("Errores Comunes a Evitar", "Qué No Hacer", "Errores Típicos"),
                    'alternatives' => array("Alternativas", "Variaciones", "Otras Formas de Prepararlo"),
                    'final_thoughts' => array("Reflexiones Finales", "Para Concluir", "En Resumen")
                ),
                'french' => array(
                    'what_makes_good' => array("Pourquoi Cette Recette Est Si Bonne", "Ce Qui Rend Cette Recette Spéciale", "Pourquoi Cette Recette Fonctionne"),
                    'ingredients' => array("Ingrédients", "Ce Dont Vous Aurez Besoin", "Liste des Ingrédients"),
                    'instructions' => array("Instructions", "Étapes de Préparation", "Comment Préparer"),
                    'storage' => array("Comment Conserver", "Conservation", "Garder au Frais"),
                    'benefits' => array("Avantages de Cette Recette", "Pourquoi C'est Bon Pour Vous", "Bienfaits Nutritionnels"),
                    'mistakes' => array("Erreurs Courantes à Éviter", "Ce Qu'il Ne Faut Pas Faire", "Pièges à Éviter"),
                    'alternatives' => array("Alternatives", "Variations Possibles", "Autres Façons de Préparer"),
                    'final_thoughts' => array("Réflexions Finales", "Pour Conclure", "En Résumé")
                ),
                'german' => array(
                    'what_makes_good' => array("Warum Dieses Rezept So Gut Ist", "Was Dieses Rezept Besonders Macht", "Warum Dieses Rezept Funktioniert"),
                    'ingredients' => array("Zutaten", "Was Du Brauchst", "Zutatenliste"),
                    'instructions' => array("Anleitung", "Schritt für Schritt", "Zubereitung"),
                    'storage' => array("Aufbewahrung", "So Lagerst Du Es", "Frisch Halten"),
                    'benefits' => array("Vorteile Dieses Rezepts", "Warum Das Gut Für Dich Ist", "Gesundheitliche Vorteile"),
                    'mistakes' => array("Häufige Fehler Vermeiden", "Was Du Nicht Tun Solltest", "Typische Fehler"),
                    'alternatives' => array("Alternativen", "Variationen", "Andere Zubereitungsarten"),
                    'final_thoughts' => array("Abschließende Gedanken", "Zusammenfassung", "Fazit")
                ),
                'polish' => array(
                    'what_makes_good' => array("Dlaczego Ten Przepis Jest Taki Dobry", "Co Czyni Ten Przepis Wyjątkowym", "Dlaczego Ten Przepis Działa"),
                    'ingredients' => array("Składniki", "Czego Potrzebujesz", "Lista Składników"),
                    'instructions' => array("Instrukcje", "Krok Po Kroku", "Jak Przygotować"),
                    'storage' => array("Jak Przechowywać", "Przechowywanie", "Utrzymanie Świeżości"),
                    'benefits' => array("Zalety Tego Przepisu", "Dlaczego To Jest Dobre Dla Ciebie", "Korzyści Zdrowotne"),
                    'mistakes' => array("Typowe Błędy do Uniknięcia", "Czego Nie Robić", "Częste Pułapki"),
                    'alternatives' => array("Alternatywy", "Warianty", "Inne Sposoby Przygotowania"),
                    'final_thoughts' => array("Podsumowanie", "Na Zakończenie", "Wnioski")
                )
            );
            
            // Get headings for selected language
            $headings = isset($headings_by_language[$article_language]) ? $headings_by_language[$article_language] : $headings_by_language['english'];
            
            $what_makes_good = $headings['what_makes_good'];
            $ingredients_titles = $headings['ingredients'];
            $instructions_titles = $headings['instructions'];
            $storage_titles = $headings['storage'];
            $benefits_titles = $headings['benefits'];
            $mistakes_titles = $headings['mistakes'];
            $alternatives_titles = $headings['alternatives'];
            $final_thoughts_titles = $headings['final_thoughts'];
            
            $prompt = "{$language_instruction}

Write an article about \"$title\". 
$length_instruction
The article must follow this structure:
1. Start with a simple, clear H1 title wrapped in <h1> tags that includes the recipe name \"$title\". Keep the title natural and straightforward - something like \"[Recipe Name] - [simple descriptive phrase]\". Don't make it overly complex or clever. IMPORTANT: Use title case (capitalize the first letter of each major word in the title). IMPORTANT: The H1 title must be wrapped in proper HTML <h1></h1> tags.
2. Start with a brief, engaging introduction that hooks the reader (4-6 sentences). Make it conversational and natural. No filler phrases like 'dive into'. Start directly with the paragraph text after the H1 title.
3. A section with the heading '" . $what_makes_good[array_rand($what_makes_good)] . "'.
4. A section titled '" . $ingredients_titles[array_rand($ingredients_titles)] . "' listing all ingredients.
5. A section titled '" . $instructions_titles[array_rand($instructions_titles)] . "' presented in a listicle format.
6. A section with the heading '" . $storage_titles[array_rand($storage_titles)] . "'.
7. A section with the heading '" . $benefits_titles[array_rand($benefits_titles)] . "'.
8. A section with the heading '" . $mistakes_titles[array_rand($mistakes_titles)] . "'.
9. A section with the heading '" . $alternatives_titles[array_rand($alternatives_titles)] . "'.
10. A FAQ section where each question is formatted as an <h3> tag and each answer is in its own paragraph.
11. A section with the heading '" . $final_thoughts_titles[array_rand($final_thoughts_titles)] . "'.

Use clear HTML subheadings: use <h2> for main sections and <h3> for any necessary subsections.
For bullet points and listicles, use proper HTML lists (<ul> with <li> for unordered lists and <ol> with <li> for ordered lists).
Use bold key information with <strong> tags. Don't use bold key information in the introduction.
Keep paragraphs short (3–4 sentences max) and write in a friendly, conversational tone. Keep it natural and easy to read.
Do not include any extraneous preamble.
Also, avoid passive voice, overly dense blocks of text, and any Markdown formatting, code fences, or extra backticks.";
            
            $api_url = 'https://api.replicate.com/v1/models/' . $model_config['model'] . '/predictions';
            $body = array(
                'input' => array(
                    'prompt' => $prompt
                )
            );
            
            // Add model-specific parameters
            if ( isset( $model_config['extra_params'] ) ) {
                $body['input'] = array_merge( $body['input'], $model_config['extra_params'] );
            }
            
            $args = array(
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $replicate_key,
                    'Prefer'        => 'wait'
                ),
                'body'    => wp_json_encode( $body ),
                'timeout' => 120,
            );
            
            // Validate that body is properly formatted
            if ( empty( $args['body'] ) || $args['body'] === false ) {
                return new WP_Error( 'invalid_body', 'Failed to encode request body as JSON.' );
            }
            
            $response = wp_remote_post( $api_url, $args );
            if ( is_wp_error( $response ) ) {
                return $response;
            }
            $code = wp_remote_retrieve_response_code( $response );
            if ( $code !== 200 && $code !== 201 && $code !== 202 ) {
                return new WP_Error( 'api_error', 'Replicate API returned code: ' . $code );
            }
            $response_body = wp_remote_retrieve_body( $response );
            $data = json_decode( $response_body, true );
            if ( ! is_array( $data ) ) {
                return new WP_Error( 'invalid_response', 'Replicate API did not return valid JSON: ' . $response_body );
            }
            
            // Handle Replicate API response format
            $article_text = '';
            
            // Check if we have immediate output
            if ( isset( $data['output'] ) && !empty($data['output']) ) {
                if ( is_array( $data['output'] ) ) {
                    $article_text = implode( '', $data['output'] );
                } else {
                    $article_text = $data['output'];
                }
            } elseif ( isset( $data['prediction']['output'] ) && !empty($data['prediction']['output']) ) {
                if ( is_array( $data['prediction']['output'] ) ) {
                    $article_text = implode( '', $data['prediction']['output'] );
                } else {
                    $article_text = $data['prediction']['output'];
                }
            } elseif ( isset( $data['id'] ) || isset( $data['prediction']['id'] ) ) {
                // No output yet, but we have a prediction ID - need to poll
                $prediction_id = isset( $data['id'] ) ? $data['id'] : $data['prediction']['id'];
                
                $max_attempts = 60; // Increased from 30 to 60 (3 minutes total)
                $attempt = 0;
                
                while ($attempt < $max_attempts) {
                    sleep(3);
                    
                    $status_response = wp_remote_get('https://api.replicate.com/v1/predictions/' . $prediction_id, array(
                        'headers' => array(
                            'Authorization' => 'Bearer ' . $api_token,
                            'Content-Type'  => 'application/json',
                        ),
                        'timeout' => 60
                    ));
                    
                    if (!is_wp_error($status_response)) {
                        $status_data = json_decode(wp_remote_retrieve_body($status_response), true);
                        
                        if (isset($status_data['status']) && $status_data['status'] === 'succeeded') {
                            if (isset($status_data['output'])) {
                                if (is_array($status_data['output'])) {
                                    $article_text = implode('', $status_data['output']);
                                } else {
                                    $article_text = $status_data['output'];
                                }
                                break;
                            }
                        } elseif (isset($status_data['status']) && ($status_data['status'] === 'failed' || $status_data['status'] === 'canceled')) {
                            $error_msg = isset($status_data['error']) ? $status_data['error'] : 'Generation failed';
                            return new WP_Error('generation_failed', 'Article generation failed: ' . $error_msg);
                        }
                    }
                    
                    $attempt++;
                }
                
                if (empty($article_text)) {
                    return new WP_Error('timeout', 'Article generation timed out after polling.');
                }
            } else {
                return new WP_Error( 'no_output', 'No output found in API response.' );
            }
            
            // Clean up the text but DON'T remove H1 tags - we need them for title extraction
            $article_text = preg_replace("/\n{2,}/", "\n", $article_text);
            // REMOVED: $article_text = preg_replace('/<h1[^>]*>.*?<\/h1>/i', '', $article_text);

            // Remove word count displays that DeepSeek sometimes adds
            $article_text = preg_replace('/\(Word count:\s*\d+\)/i', '', $article_text);
            $article_text = preg_replace('/Word count:\s*\d+/i', '', $article_text);
            $article_text = preg_replace('/```\s*\(Word count:\s*\d+\)/i', '', $article_text);
            
            // Remove triple backticks and everything after them (DeepSeek sometimes adds meta comments)
            $article_text = preg_replace('/```.*$/s', '', $article_text);
            
            // Also remove common DeepSeek meta comments
            $article_text = preg_replace('/\(within the \d+-\d+ range as requested\)\.?/i', '', $article_text);
            $article_text = preg_replace('/\(as requested\)\.?/i', '', $article_text);

            // Replace markdown bold with <strong>
            $article_text = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $article_text);
            $article_text = preg_replace('/(?<!^)\*(\S(.*?\S)?)\*/m', '<strong>$1</strong>', $article_text);
            
            // Convert bullet-style lines into lists.
            $lines = explode("\n", $article_text);
            $in_list = false;
            $output_lines = array();
            foreach ($lines as $line) {
                if (preg_match('/^\*\s+(.*)/', $line, $matches)) {
                    if (!$in_list) {
                        $in_list = true;
                        $output_lines[] = '<ul>';
                    }
                    $output_lines[] = '<li>' . $matches[1] . '</li>';
                } else {
                    if ($in_list) {
                        $output_lines[] = '</ul>';
                        $in_list = false;
                    }
                    $output_lines[] = $line;
                }
            }
            if ($in_list) {
                $output_lines[] = '</ul>';
            }
            $article_text = implode("\n", $output_lines);

            // Insert paragraph breaks after every 3 sentences.
            $article_text = $this->add_paragraph_breaks( $article_text, 3 );

            return trim( $article_text );
        }
        
        /**
         * Get LLM model configuration for Replicate API
         */
        private function get_llm_model_config( $llm_type ) {
            $models = array(
                'chatgpt' => array(
                    'model' => 'openai/gpt-5',
                    'extra_params' => array(
                        'max_tokens' => 3000
                    )
                )
            );
            
            if ( ! isset( $models[ $llm_type ] ) ) {
                return new WP_Error( 'invalid_llm', 'Invalid LLM type selected: ' . $llm_type );
            }
            
            return $models[ $llm_type ];
        }

        /**
         * Generate a featured image using Seedream-3 API (3:2 aspect ratio for featured images)
         */
        public function generate_featured_image( $title ) {
            $api_token = get_option( 'ga_replicate_api_token' );
            if ( empty( $api_token ) ) {
                return new WP_Error( 'missing_api_key', 'Replicate API token is missing.' );
            }
            
            $filtered_title = preg_replace('/\b(dog|dogs|cat|cats)\b/i', '', $title);
            $filtered_title = trim(preg_replace('/\s+/', ' ', $filtered_title));
            
            $image_prompt = "Food photography, tasty view of " . $filtered_title . " suitable for recipe photo, professional food photography, high quality, appetizing, restaurant quality, clean composition, food styling";
            
            $data = array(
                'input' => array(
                    'prompt' => $image_prompt,
                    'width' => 864,
                    'height' => 576,
                    'aspect_ratio' => '3:2',
                    'guidance_scale' => 2.5
                )
            );

            // Validate data before encoding
            if ( empty( $data ) || ! is_array( $data ) ) {
                return new WP_Error( 'invalid_data', 'Invalid data structure for featured image API request.' );
            }
            
            $encoded_body = wp_json_encode( $data );
            if ( $encoded_body === false ) {
                return new WP_Error( 'encoding_error', 'Failed to encode featured image request data as JSON.' );
            }
            
            $response = wp_remote_post('https://api.replicate.com/v1/models/bytedance/seedream-3/predictions', array(
                'headers' => array(
                    'Authorization' => 'Token ' . $api_token,
                    'Content-Type' => 'application/json',
                ),
                'body' => $encoded_body,
                'timeout' => 60,
            ));

            if (is_wp_error($response)) {
                return $response;
            }

            $body = wp_remote_retrieve_body($response);
            $result = json_decode($body, true);

            if (!isset($result['id'])) {
                return new WP_Error('api_error', 'Failed to start featured image generation: ' . $body);
            }

            // Poll for completion
            $prediction_id = $result['id'];
            $max_attempts = 30;
            $attempt = 0;

            while ($attempt < $max_attempts) {
                sleep(3);
                
                $status_response = wp_remote_get('https://api.replicate.com/v1/predictions/' . $prediction_id, array(
                    'headers' => array(
                        'Authorization' => 'Token ' . $api_token,
                    ),
                    'timeout' => 30,
                ));

                if (is_wp_error($status_response)) {
                    $attempt++;
                    continue;
                }

                $status_body = wp_remote_retrieve_body($status_response);
                $status_result = json_decode($status_body, true);

                if ($status_result['status'] === 'succeeded' && !empty($status_result['output'])) {
                    $image_url = is_array($status_result['output']) ? $status_result['output'][0] : $status_result['output'];
                    return esc_url_raw($image_url);
                } elseif ($status_result['status'] === 'failed') {
                    return new WP_Error('generation_failed', 'Featured image generation failed: ' . json_encode($status_result['error']));
                }

                $attempt++;
            }

            return new WP_Error('timeout', 'Featured image generation timed out');
        }

        /**
         * Helper: Generate a custom image from a user prompt with a given aspect ratio using Ideogram v2.
         */
        private function generate_custom_image( $prompt, $aspect_ratio ) {
            $replicate_key = get_option( 'ga_replicate_api_token' );
            if ( empty( $replicate_key ) ) {
                return new WP_Error( 'missing_api_key', 'Replicate API token is missing.' );
            }

            $api_url = 'https://api.replicate.com/v1/models/ideogram-ai/ideogram-v2/predictions';
            $body = array(
                'input' => array(
                    'prompt'              => $prompt,
                    'aspect_ratio'        => $aspect_ratio,
                    'style_type'          => "None",
                    'resolution'          => "None",
                    'magic_prompt_option' => "Auto"
                )
            );
            // Validate data before encoding
            if ( empty( $body ) || ! is_array( $body ) ) {
                return new WP_Error( 'invalid_data', 'Invalid data structure for custom image API request.' );
            }
            
            $encoded_body = wp_json_encode( $body );
            if ( $encoded_body === false ) {
                return new WP_Error( 'encoding_error', 'Failed to encode custom image request data as JSON.' );
            }
            
            $args = array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $replicate_key,
                    'Content-Type'  => 'application/json',
                    'Prefer'        => 'wait'
                ),
                'body'    => $encoded_body,
                'timeout' => 120,
            );
            $response = wp_remote_post( $api_url, $args );
            if ( is_wp_error( $response ) ) {
                return $response;
            }
            $code = wp_remote_retrieve_response_code( $response );
            if ( $code !== 200 && $code !== 201 && $code !== 202 ) {
                return new WP_Error( 'api_error', 'Replicate API returned code: ' . $code );
            }
            $response_body = wp_remote_retrieve_body( $response );
            $data = json_decode( $response_body, true );
            if ( isset( $data['output'] ) ) {
                $output = $data['output'];
                $image_url = is_array( $output ) ? $output[0] : $output;
                return esc_url_raw( $image_url );
            } else {
                return new WP_Error( 'invalid_response', 'Invalid response from Replicate API.' );
            }
        }

        /**
         * Helper: Save an image from URL to the WordPress media library.
         */
        private function save_image_to_media_library( $image_url, $title, $index = 0 ) {
            try {
                $response = wp_remote_get( $image_url, array( 'timeout' => 60 ) );
                if ( is_wp_error( $response ) ) {
                    error_log('Failed to download image: ' . $response->get_error_message());
                    return false;
                }
                
                $image_data = wp_remote_retrieve_body( $response );
                $filename = 'recipe-image-' . sanitize_title(substr($title, 0, 50)) . '-' . $index . '.jpg';
                $upload = wp_upload_bits( $filename, null, $image_data );
                
                if ( $upload['error'] ) {
                    error_log('Failed to upload image: ' . $upload['error']);
                    return false;
                }
                
                $attachment = array(
                    'post_mime_type' => 'image/jpeg',
                    'post_title'     => sanitize_text_field( $title ),
                    'post_content'   => '',
                    'post_status'    => 'inherit'
                );
                
                $attachment_id = wp_insert_attachment( $attachment, $upload['file'] );
                
                if ( is_wp_error( $attachment_id ) ) {
                    error_log('Failed to create attachment: ' . $attachment_id->get_error_message());
                    return false;
                }
                
                require_once( ABSPATH . 'wp-admin/includes/image.php' );
                $attachment_data = wp_generate_attachment_metadata( $attachment_id, $upload['file'] );
                wp_update_attachment_metadata( $attachment_id, $attachment_data );
                
                // Set alt text in WordPress attachment metadata
                update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field($title) );
                
                return array(
                    'id' => $attachment_id,
                    'url' => $upload['url'],
                    'alt' => sanitize_text_field($title)
                );
                
            } catch (Exception $e) {
                error_log('Exception saving image to media library: ' . $e->getMessage());
                return false;
            }
        }

        /**
         * Attach a featured image to a post.
         */
        public function attach_featured_image( $image_url, $post_id ) {
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
            require_once( ABSPATH . 'wp-admin/includes/image.php' );
            require_once( ABSPATH . 'wp-admin/includes/media.php' );
            $tmp = download_url( $image_url );
            if ( is_wp_error( $tmp ) ) {
                return $tmp;
            }
            $file_array = array(
                'name'     => basename( $image_url ),
                'tmp_name' => $tmp,
            );
            $attachment_id = media_handle_sideload( $file_array, $post_id );
            if ( is_wp_error( $attachment_id ) ) {
                @unlink( $file_array['tmp_name'] );
                return $attachment_id;
            }
            set_post_thumbnail( $post_id, $attachment_id );
            return $attachment_id;
        }
        
        /**
         * Add meta box for PDF recipe card download
         */
        public function add_recipe_pdf_meta_box() {
            // Get all public post types
            $post_types = get_post_types(array('public' => true));
            
            // Add meta box to all public post types
            foreach ($post_types as $post_type) {
                add_meta_box(
                    'recipe_pdf_meta_box',
                    'Recipe PDF Card',
                    array($this, 'render_recipe_pdf_meta_box'),
                    $post_type,
                    'side',
                    'high'
                );
            }
            
            // Add admin notice to make it more visible
            add_action('admin_notices', array($this, 'recipe_pdf_admin_notice'));
        }
        
        /**
         * Render meta box content
         */
        public function render_recipe_pdf_meta_box($post) {
            // Add nonce for security
            wp_nonce_field('recipe_pdf_meta_box', 'recipe_pdf_meta_box_nonce');
            
            echo '<p>Generate a printable recipe card with ingredients and instructions.</p>';
            echo '<button type="button" id="generate-recipe-pdf" class="button button-primary" data-post-id="' . esc_attr($post->ID) . '">Generate Recipe PDF</button>';
            echo '<div id="recipe-pdf-result" style="margin-top: 10px;"></div>';
        }
        
        /**
         * Add JavaScript for PDF generation
         */
        /**
         * Display admin notice about the PDF feature
         */
        public function recipe_pdf_admin_notice() {
            $screen = get_current_screen();
            if (!$screen || $screen->base !== 'post') {
                return;
            }
            
            // Disabled: Recipe PDF Card notification
            // echo '<div class="notice notice-info is-dismissible">';
            // echo '<p><strong>Recipe PDF Card Feature:</strong> Look for the "Recipe PDF Card" meta box in the sidebar to generate a printable recipe card with ingredients and instructions.</p>';
            // echo '</div>';
        }
        
        public function add_recipe_pdf_script() {
            $screen = get_current_screen();
            if (!$screen || !in_array($screen->base, array('post'))) {
                return;
            }
            ?>
            <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('#generate-recipe-pdf').on('click', function() {
                    var postId = $(this).data('post-id');
                    $('#recipe-pdf-result').html('<p>Generating PDF...</p>');
                    
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'rw_generate_recipe_pdf',
                            post_id: postId,
                            nonce: $('#recipe_pdf_meta_box_nonce').val()
                        },
                        success: function(response) {
                            if (response.success) {
                                $('#recipe-pdf-result').html('<p>PDF generated successfully!</p><p><a href="' + response.data.pdf_url + '" class="button" target="_blank">Download PDF</a></p>');
                            } else {
                                $('#recipe-pdf-result').html('<p class="error">Error: ' + response.data.message + '</p>');
                            }
                        },
                        error: function() {
                            $('#recipe-pdf-result').html('<p class="error">Error generating PDF.</p>');
                        }
                    });
                });
            });
            </script>
            <?php
        }
        
        /**
         * AJAX handler for PDF generation
         */
        public function ajax_generate_recipe_pdf() {
            // Check if license is active before generating PDF
            $license_key = get_option('rw_license_key', '');
            if (!$this->verify_license_key($license_key)) {
                wp_send_json_error(array('message' => 'License is inactive or invalid. Please activate your license to use this feature.'));
                return;
            }
            
            // Different security checks for admin vs frontend
            $is_admin_request = isset($_POST['nonce']);
            
            // For admin requests, verify the nonce
            if ($is_admin_request && !wp_verify_nonce($_POST['nonce'], 'recipe_pdf_meta_box_nonce')) {
                wp_send_json_error(array('message' => 'Security check failed.'));
                return;
            }
            
            // Check if post ID is provided
            if (!isset($_POST['post_id']) || empty($_POST['post_id'])) {
                wp_send_json_error(array('message' => 'No post ID provided.'));
                return;
            }
            
            // For frontend requests, add additional checks
            if (!$is_admin_request) {
                // Verify the post exists and is published
                $post_status = get_post_status($_POST['post_id']);
                if (!$post_status || $post_status !== 'publish') {
                    wp_send_json_error(array('message' => 'This post is not available for PDF generation.'));
                    return;
                }
            }
            
            $post_id = intval($_POST['post_id']);
            $post = get_post($post_id);
            
            if (!$post) {
                wp_send_json_error(array('message' => 'Post not found.'));
                return;
            }
            
            // Extract all recipes from the post content
            $content = $post->post_content;
            $title = $post->post_title;
            
            // Extract all recipe sections
            $recipes = $this->extract_all_recipes($content);
            
            // Add debug logging
            error_log('Recipe extraction debug - Post ID: ' . $post_id);
            error_log('Content length: ' . strlen($content));
            error_log('Recipes found: ' . count($recipes));
            if (!empty($recipes)) {
                foreach ($recipes as $i => $recipe) {
                    error_log("Recipe $i: " . json_encode(array(
                        'title' => $recipe['title'],
                        'ingredients_length' => strlen($recipe['ingredients']),
                        'instructions_length' => strlen($recipe['instructions'])
                    )));
                }
            }
            
            if (empty($recipes)) {
                wp_send_json_error(array('message' => 'Could not find any complete recipes (ingredients + instructions) in the post. Check that your post has H2 headings with "Ingredients" and "Instructions".'));
                return;
            }
            
            // Generate PDF with multiple recipes support
            $pdf_url = $this->generate_multi_recipe_pdf($title, $recipes, $post_id);
            
            if (is_wp_error($pdf_url)) {
                wp_send_json_error(array('message' => $pdf_url->get_error_message()));
                return;
            }
            
            wp_send_json_success(array('pdf_url' => $pdf_url, 'recipe_count' => count($recipes)));
        }
        
        /**
         * Extract all recipes from the post content
         */
        private function extract_all_recipes($content) {
            $recipes = array();
            
            // Define search terms for ingredients and instructions
            $ingredient_terms = array('ingredients', 'ingredient list', 'what you need', 'what you\'ll need');
            $instruction_terms = array('instructions', 'directions', 'steps', 'method', 'how to', 'preparation');
            
            // Terms that should NOT be considered as recipe instructions
            $excluded_instruction_terms = array('storage instructions', 'storage', 'storing', 'nutrition instructions', 'serving instructions');
            
            // Find all H2 and H3 headings and their content
            $pattern = '/<h[23][^>]*>(.*?)<\/h[23]>(.*?)(?=<h[23]|$)/is';
            preg_match_all($pattern, $content, $matches, PREG_SET_ORDER);
            
            $sections = array();
            foreach ($matches as $match) {
                $heading = strip_tags(trim($match[1]));
                $content_section = trim($match[2]);
                $sections[] = array(
                    'heading' => $heading,
                    'content' => $content_section
                );
            }
            
            // Group sections into recipes
            $current_recipe = array();
            $potential_title = '';
            
            for ($i = 0; $i < count($sections); $i++) {
                $section = $sections[$i];
                $heading_lower = strtolower($section['heading']);
                
                // Check if this is an ingredients section
                $is_ingredients = false;
                foreach ($ingredient_terms as $term) {
                    if (strpos($heading_lower, strtolower($term)) !== false) {
                        $is_ingredients = true;
                        break;
                    }
                }
                
                // Check if this is an instructions section (but not excluded ones)
                $is_instructions = false;
                $is_excluded = false;
                
                // First check if it's an excluded instruction type
                foreach ($excluded_instruction_terms as $excluded_term) {
                    if (strpos($heading_lower, strtolower($excluded_term)) !== false) {
                        $is_excluded = true;
                        break;
                    }
                }
                
                // Only check for instructions if it's not excluded
                if (!$is_excluded) {
                    foreach ($instruction_terms as $term) {
                        if (strpos($heading_lower, strtolower($term)) !== false) {
                            $is_instructions = true;
                            break;
                        }
                    }
                }
                
                if ($is_ingredients) {
                    // If we have a complete recipe, save it
                    if (!empty($current_recipe['ingredients']) && !empty($current_recipe['instructions'])) {
                        $recipes[] = $current_recipe;
                    }
                    
                    // Look backwards for a potential recipe title
                    $recipe_title = '';
                    if (!empty($potential_title)) {
                        $recipe_title = $potential_title;
                    } else {
                        // Look at previous section if it's not ingredients/instructions
                        if ($i > 0) {
                            $prev_section = $sections[$i - 1];
                            $prev_heading_lower = strtolower($prev_section['heading']);
                            
                            // Check if previous heading is NOT ingredients or instructions
                            $prev_is_ingredient_or_instruction = false;
                            foreach (array_merge($ingredient_terms, $instruction_terms) as $term) {
                                if (strpos($prev_heading_lower, strtolower($term)) !== false) {
                                    $prev_is_ingredient_or_instruction = true;
                                    break;
                                }
                            }
                            
                            if (!$prev_is_ingredient_or_instruction) {
                                $recipe_title = $prev_section['heading'];
                            }
                        }
                    }
                    
                    // Start new recipe
                    $current_recipe = array(
                        'title' => $recipe_title ?: 'Recipe ' . (count($recipes) + 1),
                        'ingredients' => $section['content'],
                        'instructions' => ''
                    );
                    $potential_title = ''; // Reset potential title
                } elseif ($is_instructions) {
                    // Only use this instructions section if we don't already have instructions for this recipe
                    // This ensures we get the FIRST instructions section after ingredients
                    if (!empty($current_recipe) && empty($current_recipe['instructions'])) {
                        $current_recipe['instructions'] = $section['content'];
                    } elseif (empty($current_recipe)) {
                        // Instructions without ingredients - start new recipe
                        $current_recipe = array(
                            'title' => $potential_title ?: 'Recipe ' . (count($recipes) + 1),
                            'ingredients' => '',
                            'instructions' => $section['content']
                        );
                        $potential_title = '';
                    }
                } else {
                    // This might be a recipe title - store it as potential
                    if (empty($current_recipe) || (!empty($current_recipe['ingredients']) && !empty($current_recipe['instructions']))) {
                        $potential_title = $section['heading'];
                    }
                }
            }
            
            // Don't forget the last recipe
            if (!empty($current_recipe['ingredients']) && !empty($current_recipe['instructions'])) {
                $recipes[] = $current_recipe;
            }
            
            return $recipes;
        }
        
        /**
         * Extract a section from the post content (legacy method for backward compatibility)
         */
        private function extract_section($content, $section_name) {
            $recipes = $this->extract_all_recipes($content);
            if (!empty($recipes)) {
                $first_recipe = $recipes[0];
                return $section_name === 'ingredients' ? $first_recipe['ingredients'] : $first_recipe['instructions'];
            }
            return '';
        }
        
        /**
         * Generate PDF with multiple recipes support
         */
        private function generate_multi_recipe_pdf($title, $recipes, $post_id) {
            // Add debug logging
            error_log('PDF generation started - Post ID: ' . $post_id . ', Recipe count: ' . count($recipes));
            
            // Load TCPDF
            if (!class_exists('TCPDF')) {
                error_log('TCPDF not loaded, attempting to load...');
                if (function_exists('rw_load_tcpdf')) {
                    rw_load_tcpdf();
                }
                
                if (!class_exists('TCPDF')) {
                    error_log('TCPDF library could not be loaded');
                    return new WP_Error('tcpdf_missing', 'TCPDF library is not available. Please install TCPDF or contact support.');
                }
                error_log('TCPDF loaded successfully');
            }
            
            // Create upload directory if it doesn't exist
            $upload_dir = wp_upload_dir();
            $pdf_dir = $upload_dir['basedir'] . '/recipe-pdfs';
            if (!file_exists($pdf_dir)) {
                wp_mkdir_p($pdf_dir);
            }
            
            // Create index.php file to prevent directory listing
            if (!file_exists($pdf_dir . '/index.php')) {
                file_put_contents($pdf_dir . '/index.php', '<?php // Silence is golden');
            }
            
            // Create .htaccess file for additional security
            if (!file_exists($pdf_dir . '/.htaccess')) {
                file_put_contents($pdf_dir . '/.htaccess', "<IfModule mod_rewrite.c>\nRewriteEngine On\nRewriteCond %{REQUEST_FILENAME} -f\nRewriteRule ^.*\\.pdf$ - [L]\nRewriteRule . - [R=404,L]\n</IfModule>");
            }
            
            // Get customization settings from Recipe Card page
            $header_color = get_option('rw_recipe_card_header_color', '#333333');
            $accent_color = get_option('rw_recipe_card_accent_color', '#FF6B6B');
            $text_color = get_option('rw_recipe_card_text_color', '#333333');
            $background_color = get_option('rw_recipe_card_background_color', '#FFFFFF');
            $ingredients_title = get_option('rw_recipe_card_ingredients_title', 'Ingredients');
            $instructions_title = get_option('rw_recipe_card_instructions_title', 'Instructions');
            $footer_text = get_option('rw_recipe_card_footer_text', 'Recipe from {site_name}');
            $show_logo = get_option('rw_recipe_card_show_logo', 1);
            
            // Replace placeholders in footer text
            $footer_text = str_replace('{site_name}', get_bloginfo('name'), $footer_text);
            
            // Convert hex to RGB
            $header_rgb = $this->hex2rgb($header_color);
            $accent_rgb = $this->hex2rgb($accent_color);
            $text_rgb = $this->hex2rgb($text_color);
            $bg_rgb = $this->hex2rgb($background_color);
            
            // Create new PDF document
            try {
                $pdf = new TCPDF('P', 'mm', 'A4', true, 'UTF-8', false);
                
                // Set document information
                $pdf->SetCreator(get_bloginfo('name'));
                $pdf->SetAuthor(get_bloginfo('name'));
                $pdf->SetTitle($title . ' - Recipe Card');
                $pdf->SetSubject('Recipe Card');
                
                error_log('TCPDF document created successfully');
            } catch (Exception $e) {
                error_log('Error creating TCPDF document: ' . $e->getMessage());
                return new WP_Error('pdf_creation_failed', 'Failed to create PDF document: ' . $e->getMessage());
            }
            
            // Remove header and footer
            $pdf->setPrintHeader(false);
            $pdf->setPrintFooter(false);
            
            // Set margins
            $pdf->SetMargins(15, 15, 15);
            
            // Set auto page breaks
            $pdf->SetAutoPageBreak(true, 15);
            
            // Generate a page for each recipe
            foreach ($recipes as $index => $recipe) {
                // Add a page
                $pdf->AddPage();
                
                // Set page background color
                $pdf->SetFillColor($bg_rgb[0], $bg_rgb[1], $bg_rgb[2]);
                $pdf->Rect(0, 0, $pdf->getPageWidth(), $pdf->getPageHeight(), 'F');
                
                // Set font
                $pdf->SetFont('helvetica', '', 12);
                
                // Add site logo if enabled (only on first page)
                if ($show_logo && $index === 0) {
                    $logo_id = get_theme_mod('custom_logo');
                    if ($logo_id) {
                        $logo_url = wp_get_attachment_image_url($logo_id, 'medium');
                        if ($logo_url) {
                            // Calculate logo dimensions to fit within 40mm height
                            $logo_info = getimagesize($logo_url);
                            if ($logo_info) {
                                $logo_width = $logo_info[0];
                                $logo_height = $logo_info[1];
                                $max_height = 20; // mm
                                $ratio = $logo_width / $logo_height;
                                $new_height = min($max_height, $logo_height);
                                $new_width = $new_height * $ratio;
                                
                                // Center the logo
                                $x = (210 - $new_width) / 2;
                                $pdf->Image($logo_url, $x, 15, $new_width, $new_height, '', '', '', false, 300);
                                $pdf->Ln($new_height + 5);
                            }
                        }
                    }
                }
                
                // Recipe title logic based on number of recipes
                if (count($recipes) > 1) {
                    // Multiple recipes: show H1 title first, then H2 recipe name
                    $pdf->SetFont('helvetica', 'B', 16);
                    $pdf->SetTextColor($header_rgb[0], $header_rgb[1], $header_rgb[2]);
                    $pdf->Write(0, $title, '', 0, 'C', true, 0, false, false, 0);
                    $pdf->Ln(3);
                    
                    $pdf->SetFont('helvetica', 'B', 18);
                    $recipe_title = $recipe['title'] . ' (Recipe ' . ($index + 1) . ' of ' . count($recipes) . ')';
                    $pdf->Write(0, $recipe_title, '', 0, 'C', true, 0, false, false, 0);
                    $pdf->Ln(5);
                } else {
                    // Single recipe: use main article title
                    $pdf->SetFont('helvetica', 'B', 18);
                    $pdf->SetTextColor($header_rgb[0], $header_rgb[1], $header_rgb[2]);
                    $pdf->Write(0, $title, '', 0, 'C', true, 0, false, false, 0);
                    $pdf->Ln(5);
                }
                
                // Add a line under the title
                $pdf->SetDrawColor($accent_rgb[0], $accent_rgb[1], $accent_rgb[2]);
                $pdf->SetLineWidth(0.5);
                $pdf->Line(15, $pdf->GetY(), 195, $pdf->GetY());
                $pdf->Ln(5);
                
                // Ingredients heading
                if (!empty($recipe['ingredients'])) {
                    $pdf->SetFont('helvetica', 'B', 14);
                    $pdf->SetTextColor($accent_rgb[0], $accent_rgb[1], $accent_rgb[2]);
                    $pdf->Write(0, $ingredients_title, '', 0, 'L', true, 0, false, false, 0);
                    $pdf->Ln(2);
                    
                    // Ingredients content
                    $pdf->SetFont('helvetica', '', 12);
                    $pdf->SetTextColor($text_rgb[0], $text_rgb[1], $text_rgb[2]);
                    
                    // Clean up HTML and convert to plain text for ingredients
                    $ingredients_text = strip_tags($recipe['ingredients'], '<ul><li><ol>');
                    $pdf->writeHTML($ingredients_text, true, false, true, false, '');
                    $pdf->Ln(5);
                }
                
                // Instructions heading
                if (!empty($recipe['instructions'])) {
                    $pdf->SetFont('helvetica', 'B', 14);
                    $pdf->SetTextColor($accent_rgb[0], $accent_rgb[1], $accent_rgb[2]);
                    $pdf->Write(0, $instructions_title, '', 0, 'L', true, 0, false, false, 0);
                    $pdf->Ln(2);
                    
                    // Instructions content
                    $pdf->SetFont('helvetica', '', 12);
                    $pdf->SetTextColor($text_rgb[0], $text_rgb[1], $text_rgb[2]);
                    
                    // Clean up HTML and convert to plain text for instructions
                    $instructions_text = strip_tags($recipe['instructions'], '<ul><li><ol>');
                    $pdf->writeHTML($instructions_text, true, false, true, false, '');
                }
                
                // Calculate remaining space on the page
                $currentY = $pdf->GetY();
                $pageHeight = $pdf->getPageHeight();
                $footerHeight = 10; // Height needed for footer
                $margin = 15; // Bottom margin
                
                // Add footer only if there's enough space, otherwise it will create a new page
                if ($pageHeight - $currentY > ($footerHeight + $margin + 5)) {
                    // Add some space before footer
                    $pdf->Ln(5);
                    
                    // Footer with site info - place it at the current position, not at absolute bottom
                    $pdf->SetFont('helvetica', 'I', 8);
                    $pdf->SetTextColor(128, 128, 128);
                    $pdf->Cell(0, 10, $footer_text, 0, false, 'C');
                }
            }
            
            // Generate file name
            $recipe_count_suffix = count($recipes) > 1 ? '-' . count($recipes) . '-recipes' : '';
            $file_name = sanitize_title($title) . '-recipe-card' . $recipe_count_suffix . '-' . $post_id . '.pdf';
            $file_path = $pdf_dir . '/' . $file_name;
            
            // Save PDF
            try {
                $pdf->Output($file_path, 'F');
                error_log('PDF saved successfully: ' . $file_path);
                
                // Verify file was created
                if (!file_exists($file_path)) {
                    error_log('PDF file was not created: ' . $file_path);
                    return new WP_Error('pdf_save_failed', 'PDF file could not be saved.');
                }
                
                // Return URL to the PDF
                return $upload_dir['baseurl'] . '/recipe-pdfs/' . $file_name;
            } catch (Exception $e) {
                error_log('Error saving PDF: ' . $e->getMessage());
                return new WP_Error('pdf_save_failed', 'Failed to save PDF: ' . $e->getMessage());
            }
        }
        
        /**
         * Generate the PDF recipe card (legacy method for backward compatibility)
         */
        private function generate_recipe_pdf($title, $ingredients, $instructions, $post_id) {
            // Convert to new format and use multi-recipe method
            $recipes = array(array(
                'title' => $title,
                'ingredients' => $ingredients,
                'instructions' => $instructions
            ));
            
            return $this->generate_multi_recipe_pdf($title, $recipes, $post_id);
        }
        
        /**
         * Convert hex color to RGB
         */
        private function hex2rgb($hex) {
            $hex = str_replace('#', '', $hex);
            
            if (strlen($hex) == 3) {
                $r = hexdec(substr($hex, 0, 1) . substr($hex, 0, 1));
                $g = hexdec(substr($hex, 1, 1) . substr($hex, 1, 1));
                $b = hexdec(substr($hex, 2, 1) . substr($hex, 2, 1));
            } else {
                $r = hexdec(substr($hex, 0, 2));
                $g = hexdec(substr($hex, 2, 2));
                $b = hexdec(substr($hex, 4, 2));
            }
            
            return array($r, $g, $b);
        }
        
        /**
         * Add Jump to Recipe box before the first H2 heading
         */
        public function add_jump_to_recipe_box($content) {
            // Only add to singular posts
            if (!is_singular()) {
                return $content;
            }
            
            global $post;
            
            // Only show on published posts and exclude Pages
            if ($post->post_status !== 'publish' || $post->post_type === 'page') {
                return $content;
            }
            
            // Always show recipe box regardless of license status
            // $license_key = get_option('rw_license_key', '');
            // if (!$this->verify_license_key($license_key)) {
            //     return $content;
            // }
            
            // Check if recipe card functionality is disabled
            $disable_recipe_card = get_option('rw_disable_recipe_card', 0);
            if ($disable_recipe_card) {
                return $content;
            }
            
            // Check if category filtering is enabled and if the post is in an allowed category
            $allowed_categories = get_option('rw_recipe_card_categories', array());
            if (!empty($allowed_categories)) {
                $post_categories = wp_get_post_categories($post->ID);
                $category_match = false;
                
                foreach ($post_categories as $category_id) {
                    if (in_array($category_id, $allowed_categories)) {
                        $category_match = true;
                        break;
                    }
                }
                
                // If category filtering is enabled and this post doesn't match any selected categories, don't show the box
                if (!$category_match) {
                    return $content;
                }
            }
            
            // Check if this post has ingredients and instructions
            $has_ingredients = (strpos($post->post_content, 'ingredients') !== false || 
                               strpos($post->post_content, 'Ingredients') !== false);
            $has_instructions = (strpos($post->post_content, 'instructions') !== false || 
                               strpos($post->post_content, 'Instructions') !== false || 
                               strpos($post->post_content, 'Directions') !== false || 
                               strpos($post->post_content, 'Steps') !== false);
            
            // Only add the box if it looks like a recipe
            if (!$has_ingredients || !$has_instructions) {
                return $content;
            }
            
            // Get customization settings
            $accent_color = get_option('rw_recipe_card_accent_color', '#FF6B6B');
            $box_bg_color = get_option('rw_recipe_card_box_bg_color', '#ffffff');
            $box_text_color = get_option('rw_recipe_card_box_text_color', '#555555');
            $box_border_radius = get_option('rw_recipe_card_box_border_radius', '12');
            $box_shadow = get_option('rw_recipe_card_box_shadow', '1');
            
            // Create the jump box HTML with matching styling to recipe card
            $shadow_style = $box_shadow ? 'box-shadow: 0 5px 20px rgba(0,0,0,0.08);' : '';
            $jump_box = '<div class="jump-to-recipe-box" style="margin: 20px 0; padding: 20px; background: ' . esc_attr($box_bg_color) . '; border-radius: ' . esc_attr($box_border_radius) . 'px; ' . $shadow_style . ' border: 1px solid #eaeaea;">';
            $jump_box .= '<a href="#recipe-pdf-download-container" style="display: flex; align-items: center; text-decoration: none; color: ' . esc_attr($accent_color) . '; font-weight: 600; font-size: 16px;">';
            $jump_box .= '<span class="dashicons dashicons-arrow-down-alt" style="margin-right: 8px; font-size: 20px;"></span>';
            $jump_box .= 'Jump to Recipe Card';
            $jump_box .= '</a>';
            $jump_box .= '</div>';
            
            // Add smooth scrolling script with slower animation (1200ms instead of 500ms)
            $jump_box .= '<script>
            jQuery(document).ready(function($) {
                $(".jump-to-recipe-box a").on("click", function(e) {
                    e.preventDefault();
                    var target = $(this).attr("href");
                    $("html, body").animate({
                        scrollTop: $(target).offset().top - 50
                    }, 2000, "swing");
                });
            });
            </script>';
            
            // Find the first H2 tag
            if (preg_match('/<h2[^>]*>/i', $content, $matches, PREG_OFFSET_CAPTURE)) {
                $h2_pos = $matches[0][1];
                // Insert the jump box before the first H2
                $content = substr_replace($content, $jump_box, $h2_pos, 0);
            } else {
                // If no H2 found, add it at the beginning of the content
                $content = $jump_box . $content;
            }
            
            return $content;
        }
        
        /**
         * Add PDF download button to the end of post content
         */
        public function add_pdf_button_to_content($content) {
            // Only add to singular posts
            if (!is_singular()) {
                return $content;
            }
            
            global $post;
            
            // Only show on published posts and exclude Pages
            if ($post->post_status !== 'publish' || $post->post_type === 'page') {
                return $content;
            }
            
            // Always show PDF button regardless of license status
            // $license_key = get_option('rw_license_key', '');
            // if (!$this->verify_license_key($license_key)) {
            //     return $content;
            // }
            
            // Check if recipe card functionality is disabled
            $disable_recipe_card = get_option('rw_disable_recipe_card', 0);
            if ($disable_recipe_card) {
                return $content;
            }
            
            // Check if category filtering is enabled and if the post is in an allowed category
            $allowed_categories = get_option('rw_recipe_card_categories', array());
            if (!empty($allowed_categories)) {
                $post_categories = wp_get_post_categories($post->ID);
                $category_match = false;
                
                foreach ($post_categories as $category_id) {
                    if (in_array($category_id, $allowed_categories)) {
                        $category_match = true;
                        break;
                    }
                }
                
                // If category filtering is enabled and this post doesn't match any selected categories, don't show the recipe card
                if (!$category_match) {
                    return $content;
                }
            }
            
            // Check if this post has ingredients and instructions
            $has_ingredients = (strpos($post->post_content, 'ingredients') !== false || 
                               strpos($post->post_content, 'Ingredients') !== false);
            $has_instructions = (strpos($post->post_content, 'instructions') !== false || 
                               strpos($post->post_content, 'Instructions') !== false || 
                               strpos($post->post_content, 'Directions') !== false || 
                               strpos($post->post_content, 'Steps') !== false);
            
            // Only add the button if it looks like a recipe
            if (!$has_ingredients || !$has_instructions) {
                return $content;
            }
            
            // Get customization settings
            $accent_color = get_option('rw_recipe_card_accent_color', '#FF6B6B');
            $card_title = get_option('rw_recipe_card_title', 'Printable Recipe Card');
            $button_text = get_option('rw_recipe_card_button_text', 'Download Recipe Card');
            $box_description = get_option('rw_recipe_card_box_description', 'Want just the essential recipe details without scrolling through the article? Get our printable recipe card with just the ingredients and instructions.');
            $box_bg_color = get_option('rw_recipe_card_box_bg_color', '#ffffff');
            $box_text_color = get_option('rw_recipe_card_box_text_color', '#555555');
            $box_border_radius = get_option('rw_recipe_card_box_border_radius', '12');
            $box_shadow = get_option('rw_recipe_card_box_shadow', '1');
            
            // Create the button HTML with modern UI and custom styling
            $shadow_style = $box_shadow ? 'box-shadow: 0 5px 20px rgba(0,0,0,0.08);' : '';
            $button_html = '<div id="recipe-pdf-download-container" class="recipe-pdf-download-container" style="margin: 40px 0; padding: 30px; border-radius: ' . esc_attr($box_border_radius) . 'px; ' . $shadow_style . ' background: ' . esc_attr($box_bg_color) . '; border: 1px solid #eaeaea;">';
            
            // Icon and heading in a flex container
            $button_html .= '<div style="display: flex; align-items: center; margin-bottom: 15px;">';
            $button_html .= '<span class="dashicons dashicons-media-document" style="font-size: 28px; color: ' . esc_attr($accent_color) . '; margin-right: 12px;"></span>';
            $button_html .= '<h3 style="margin: 0; font-size: 22px; color: ' . esc_attr($box_text_color) . '; font-weight: 600;">' . esc_html($card_title) . '</h3>';
            $button_html .= '</div>';
            
            // Divider with accent color
            $button_html .= '<div style="height: 3px; width: 60px; background-color: ' . esc_attr($accent_color) . '; margin-bottom: 20px;"></div>';
            
            // Description text
            $button_html .= '<p style="margin-bottom: 20px; font-size: 16px; line-height: 1.5; color: ' . esc_attr($box_text_color) . ';">' . esc_html($box_description) . '</p>';
            
            // Button with hover effect via class
            $button_html .= '<button type="button" class="recipe-pdf-download-button" data-post-id="' . esc_attr($post->ID) . '" style="background-color: ' . esc_attr($accent_color) . '; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 16px; transition: all 0.2s ease; display: inline-flex; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">';
            $button_html .= '<span class="dashicons dashicons-pdf" style="margin-right: 8px; font-size: 20px;"></span> ' . esc_html($button_text);
            $button_html .= '</button>';
            
            // Result container with styling
            $button_html .= '<div id="recipe-pdf-download-result" style="margin-top: 15px; font-size: 15px; min-height: 24px;"></div>';
            $button_html .= '</div>';
            
            // Append the button to the content
            return $content . $button_html;
        }
        
        /**
         * Enqueue scripts and styles for the frontend
         */
        public function enqueue_frontend_scripts() {
            // Only enqueue on singular posts
            if (!is_singular()) {
                return;
            }
            
            // Enqueue dashicons for the PDF icon
            wp_enqueue_style('dashicons');
            
            // Enqueue the script
            wp_enqueue_script('jquery');
            
            // Add custom CSS for hover effects and layout fixes
            wp_add_inline_style('dashicons', '
                .recipe-pdf-download-button:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 4px 8px rgba(0,0,0,0.15) !important;
                }
                .recipe-pdf-download-button:active {
                    transform: translateY(0);
                    box-shadow: 0 2px 3px rgba(0,0,0,0.1) !important;
                }
                .recipe-pdf-download-link {
                    display: inline-flex;
                    align-items: center;
                    padding: 8px 16px;
                    background-color: #f8f8f8;
                    color: #333;
                    border: 1px solid #ddd;
                    border-radius: 6px;
                    text-decoration: none;
                    font-weight: 500;
                    transition: all 0.2s ease;
                    margin-top: 10px;
                }
                .recipe-pdf-download-link:hover {
                    background-color: #f0f0f0;
                    border-color: #ccc;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
                }
                @keyframes pulse {
                    0% { opacity: 0.6; }
                    50% { opacity: 1; }
                    100% { opacity: 0.6; }
                }
                .pdf-generating {
                    display: flex;
                    align-items: center;
                    color: #666;
                    animation: pulse 1.5s infinite;
                }
                .pdf-success {
                    color: #4CAF50;
                    display: flex;
                    align-items: center;
                }
                .pdf-error {
                    color: #F44336;
                }
                /* Fix for layout issues that cause reduced/zoomed-out view */
                .jump-to-recipe-box {
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                    overflow: hidden !important;
                }
                .jump-to-recipe-box * {
                    max-width: 100% !important;
                    box-sizing: border-box !important;
                }
                /* Prevent viewport scaling issues */
                body.single-post {
                    min-width: auto !important;
                    overflow-x: hidden !important;
                }
                /* Fix for potential CSS conflicts that cause layout shrinking */
                .entry-content, .post-content, .content {
                    max-width: 100% !important;
                    overflow-x: hidden !important;
                }
            ');
            
            // Add inline script with improved UX
            wp_add_inline_script('jquery', '
                jQuery(document).ready(function($) {
                    $(".recipe-pdf-download-button").on("click", function() {
                        var postId = $(this).data("post-id");
                        var resultDiv = $("#recipe-pdf-download-result");
                        var button = $(this);
                        
                        // Disable button and show loading state
                        button.prop("disabled", true);
                        button.css("opacity", "0.7");
                        resultDiv.html("<p class=\'pdf-generating\'><span class=\'dashicons dashicons-update spin\' style=\'margin-right:8px; animation: spin 2s linear infinite;\'></span> Generating your recipe card...</p>");
                        
                        // Add spin animation
                        $("<style>@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }</style>").appendTo("head");
                        
                        $.ajax({
                            url: "' . admin_url('admin-ajax.php') . '",
                            type: "POST",
                            data: {
                                action: "rw_generate_recipe_pdf",
                                post_id: postId
                            },
                            success: function(response) {
                                if (response.success) {
                                    // Show a countdown message for 5 seconds before showing the download button
                                    var countdownSeconds = 5;
                                    var countdownInterval;
                                    
                                    function updateCountdown() {
                                        if (countdownSeconds > 0) {
                                            resultDiv.html("<p class=\'pdf-success\'><span class=\'dashicons dashicons-yes-alt\' style=\'margin-right:8px; color:#4CAF50;\'></span> Your recipe card is ready! Download link will appear in " + countdownSeconds + " seconds...</p>");
                                            countdownSeconds--;
                                        } else {
                                            clearInterval(countdownInterval);
                                            // Re-enable button
                                            button.prop("disabled", false);
                                            button.css("opacity", "1");
                                            // Show download link
                                            var recipeCountText = response.data.recipe_count > 1 ? " (" + response.data.recipe_count + " recipes)" : "";
                                            resultDiv.html("<p class=\'pdf-success\'><span class=\'dashicons dashicons-yes-alt\' style=\'margin-right:8px; color:#4CAF50;\'></span> Your recipe card is ready!" + recipeCountText + "</p><a href=\"" + response.data.pdf_url + "\" class=\"recipe-pdf-download-link\" target=\"_blank\"><span class=\'dashicons dashicons-download\' style=\'margin-right:8px;\'></span> Open PDF</a>");
                                        }
                                    }
                                    
                                    countdownInterval = setInterval(updateCountdown, 1000);
                                    updateCountdown(); // Call immediately
                                } else {
                                    // Re-enable button
                                    button.prop("disabled", false);
                                    button.css("opacity", "1");
                                    // Show error message
                                    var errorMsg = response.data && response.data.message ? response.data.message : "Error generating PDF. Please try again.";
                                    resultDiv.html("<p class=\'pdf-error\'><span class=\'dashicons dashicons-warning\' style=\'margin-right:8px;\'></span> " + errorMsg + "</p>");
                                }
                            },
                            error: function(jqXHR, textStatus, errorThrown) {
                                // Re-enable button
                                button.prop("disabled", false);
                                button.css("opacity", "1");
                                // Show error message
                                console.error("PDF generation error:", textStatus, errorThrown);
                                resultDiv.html("<p class=\'pdf-error\'><span class=\'dashicons dashicons-warning\' style=\'margin-right:8px;\'></span> Error generating PDF. Please try again.</p>");
                            }
                        });
                    });
                });
            ');
        }
        
        /**
         * Parse ingredients from HTML content
         */
        private function parse_ingredients_from_html($content) {
            $ingredients = array();
            
            // Try multiple patterns to find ingredients section
            $patterns = array(
                // Pattern 1: Common ingredient headings
                '/<h2[^>]*>\s*(ingredients|składniki|ingrédients|zutaten|ingredientes|what you\'?ll need|what\'?s needed|shopping list|ingredient list)\s*<\/h2>(.*?)(?=<h2|$)/is',
                // Pattern 2: With punctuation/colons
                '/<h2[^>]*>[^<]*?(ingredients|składniki|ingrédients|zutaten|ingredientes|what you\'?ll need)[^<]*?<\/h2>(.*?)(?=<h2|$)/is',
                // Pattern 3: Match any H2 with "need" or "ingredient" in it
                '/<h2[^>]*>[^<]*?(need|ingredient)[^<]*?<\/h2>(.*?)(?=<h2|$)/is',
            );
            
            $ingredients_html = '';
            $pattern_matched = false;
            $heading_found = '';
            
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $content, $matches)) {
                    $ingredients_html = $matches[2];
                    $heading_found = $matches[0];
                    $pattern_matched = true;
                    error_log('WPRM: Found ingredients section with pattern');
                    error_log('WPRM: Heading found: ' . $heading_found);
                    error_log('WPRM: Ingredients HTML: ' . substr($ingredients_html, 0, 500));
                    break;
                }
            }
            
            // Fallback: Try to get the 2nd H2 section if no pattern matched
            if (!$pattern_matched) {
                error_log('WPRM: No pattern matched, trying 2nd H2 as fallback');
                if (preg_match_all('/<h2[^>]*>(.*?)<\/h2>(.*?)(?=<h2|$)/is', $content, $all_h2s, PREG_SET_ORDER)) {
                    error_log('WPRM: Found ' . count($all_h2s) . ' H2 sections');
                    if (count($all_h2s) >= 2) {
                        $ingredients_html = $all_h2s[1][2]; // 2nd H2 content (index 1)
                        $heading_found = $all_h2s[1][0];
                        $pattern_matched = true;
                        error_log('WPRM: Using 2nd H2 as ingredients section');
                        error_log('WPRM: Heading: ' . $all_h2s[1][1]);
                    }
                }
            }
            
            if ($pattern_matched) {
                // Extract list items
                if (preg_match_all('/<li[^>]*>(.*?)<\/li>/is', $ingredients_html, $items)) {
                    error_log('WPRM: Found ' . count($items[1]) . ' ingredient list items');
                    
                    // Check if these look like actual ingredients (not tips/mistakes)
                    $first_item = strip_tags($items[1][0]);
                    error_log('WPRM: First item: ' . $first_item);
                    if (stripos($first_item, "don't") !== false || stripos($first_item, 'avoid') !== false || stripos($first_item, 'mistake') !== false) {
                        error_log('WPRM: WARNING - Found list items but they look like tips/mistakes, not ingredients. Skipping.');
                        return array();
                    }
                    
                    $ingredient_group = array(
                        'name' => '',
                        'ingredients' => array()
                    );
                    
                    foreach ($items[1] as $item) {
                        $item_text = strip_tags($item);
                        $item_text = trim($item_text);
                        
                        if (!empty($item_text)) {
                            // Skip if it looks like a tip/mistake
                            if (stripos($item_text, "don't") !== false || stripos($item_text, 'avoid') !== false) {
                                continue;
                            }
                            
                            // Try to parse amount, unit, name
                            // Simple pattern: "2 cups flour"
                            if (preg_match('/^(\d+(?:\/\d+)?(?:\.\d+)?)\s*([a-zA-Ząćęłńóśźż]*)\s+(.+)$/u', $item_text, $parts)) {
                                $ingredient_group['ingredients'][] = array(
                                    'amount' => $parts[1],
                                    'unit' => $parts[2],
                                    'name' => $parts[3],
                                    'notes' => ''
                                );
                            } else {
                                // Can't parse, just use the whole thing as name
                                $ingredient_group['ingredients'][] = array(
                                    'amount' => '',
                                    'unit' => '',
                                    'name' => $item_text,
                                    'notes' => ''
                                );
                            }
                        }
                    }
                    
                    if (!empty($ingredient_group['ingredients'])) {
                        $ingredients[] = $ingredient_group;
                        error_log('WPRM: Successfully parsed ' . count($ingredient_group['ingredients']) . ' ingredients');
                    }
                } else {
                    error_log('WPRM: No list items found in ingredients section');
                }
            } else {
                error_log('WPRM: No ingredients section found in content');
            }
            
            return $ingredients;
        }
        
        /**
         * Parse instructions from HTML content
         */
        private function parse_instructions_from_html($content) {
            $instructions = array();
            
            $instructions_html = '';
            $pattern_matched = false;
            $heading_found = '';
            
            // PRIMARY METHOD: Get all H2 sections and use the 3rd one for instructions
            if (preg_match_all('/<h2[^>]*>(.*?)<\/h2>(.*?)(?=<h2|$)/is', $content, $all_h2s, PREG_SET_ORDER)) {
                error_log('WPRM: Found ' . count($all_h2s) . ' H2 sections total');
                
                // Try 3rd H2 first (typical structure: 1=intro, 2=ingredients, 3=instructions)
                if (count($all_h2s) >= 3) {
                    $third_h2_heading = strip_tags($all_h2s[2][1]);
                    $third_h2_content = $all_h2s[2][2];
                    
                    // Count list items
                    $item_count = preg_match_all('/<li[^>]*>.*?<\/li>/is', $third_h2_content);
                    error_log('WPRM: 3rd H2 "' . $third_h2_heading . '" has ' . $item_count . ' list items');
                    
                    // Use 3rd H2 if it has at least 3 list items and isn't clearly NOT instructions
                    if ($item_count >= 3 && 
                        stripos($third_h2_heading, 'mistake') === false && 
                        stripos($third_h2_heading, 'avoid') === false && 
                        stripos($third_h2_heading, 'benefit') === false &&
                        stripos($third_h2_heading, 'storage') === false &&
                        stripos($third_h2_heading, 'faq') === false) {
                        
                        $instructions_html = $third_h2_content;
                        $heading_found = $third_h2_heading;
                        $pattern_matched = true;
                        error_log('WPRM: Using 3rd H2 as instructions section');
                    } else {
                        error_log('WPRM: 3rd H2 does not look like instructions (too few items or wrong topic)');
                    }
                }
                
                // FALLBACK: Find section with longest list that looks like instructions
                if (!$pattern_matched) {
                    error_log('WPRM: 3rd H2 method failed, searching for section with most list items');
                    
                    $max_items = 0;
                    $best_section = null;
                    $best_heading = '';
                    
                    foreach ($all_h2s as $index => $section) {
                        $heading = strip_tags($section[1]);
                        $section_content = $section[2];
                        
                        // Skip clearly non-instruction sections
                        if (stripos($heading, 'mistake') !== false || 
                            stripos($heading, 'avoid') !== false || 
                            stripos($heading, 'tip') !== false ||
                            stripos($heading, 'benefit') !== false ||
                            stripos($heading, 'alternative') !== false ||
                            stripos($heading, 'variation') !== false ||
                            stripos($heading, 'storage') !== false ||
                            stripos($heading, 'faq') !== false) {
                            continue;
                        }
                        
                        // Count list items
                        $item_count = preg_match_all('/<li[^>]*>.*?<\/li>/is', $section_content);
                        
                        if ($item_count > $max_items) {
                            $max_items = $item_count;
                            $best_section = $section_content;
                            $best_heading = $heading;
                        }
                        
                        error_log('WPRM: H2 #' . $index . ' "' . $heading . '" has ' . $item_count . ' list items');
                    }
                    
                    if ($max_items >= 3 && $best_section) {
                        $instructions_html = $best_section;
                        $heading_found = $best_heading;
                        $pattern_matched = true;
                        error_log('WPRM: Using section with most list items (' . $max_items . ') as instructions');
                        error_log('WPRM: Heading: ' . $best_heading);
                    } else {
                        error_log('WPRM: No section found with enough list items (need 3+)');
                    }
                }
            }
            
            if ($pattern_matched) {
                
                // Extract list items
                if (preg_match_all('/<li[^>]*>(.*?)<\/li>/is', $instructions_html, $items)) {
                    error_log('WPRM: Found ' . count($items[1]) . ' instruction list items');
                    
                    $instruction_group = array(
                        'name' => '',
                        'instructions' => array()
                    );
                    
                    foreach ($items[1] as $item) {
                        $item_text = strip_tags($item);
                        $item_text = trim($item_text);
                        
                        if (!empty($item_text)) {
                            $instruction_group['instructions'][] = array(
                                'text' => $item_text,
                                'image' => 0
                            );
                        }
                    }
                    
                    if (!empty($instruction_group['instructions'])) {
                        $instructions[] = $instruction_group;
                        error_log('WPRM: Successfully parsed ' . count($instruction_group['instructions']) . ' instructions');
                    }
                } else {
                    error_log('WPRM: No list items found in instructions section');
                }
            } else {
                error_log('WPRM: Could not find instructions section in content');
            }
            
            return $instructions;
        }
        
        /**
         * Generate recipe metadata using AI (prep time, cook time, servings)
         */
        private function generate_recipe_metadata($title, $content) {
            $api_token = get_option('ga_replicate_api_token');
            if (empty($api_token)) {
                return array(
                    'prep_time' => 15,
                    'cook_time' => 30,
                    'servings' => 4
                );
            }
            
            // Create a simple prompt for metadata
            $prompt = "Based on this recipe title '$title', provide ONLY three numbers separated by commas: prep time in minutes, cook time in minutes, and number of servings. For example: 15,30,4\n\nJust the three numbers, nothing else.";
            
            $api_url = 'https://api.replicate.com/v1/models/openai/gpt-5/predictions';
            $body = array(
                'input' => array(
                    'prompt' => $prompt,
                    'max_tokens' => 50
                )
            );
            
            $encoded_body = wp_json_encode($body);
            $args = array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $api_token,
                    'Content-Type'  => 'application/json',
                ),
                'body'    => $encoded_body,
                'timeout' => 30,
            );
            
            $response = wp_remote_post($api_url, $args);
            if (is_wp_error($response)) {
                return array('prep_time' => 15, 'cook_time' => 30, 'servings' => 4);
            }
            
            $code = wp_remote_retrieve_response_code($response);
            if ($code !== 200 && $code !== 201 && $code !== 202) {
                return array('prep_time' => 15, 'cook_time' => 30, 'servings' => 4);
            }
            
            $response_body = wp_remote_retrieve_body($response);
            $data = json_decode($response_body, true);
            
            $metadata_text = '';
            if (isset($data['output'])) {
                $metadata_text = is_array($data['output']) ? implode('', $data['output']) : $data['output'];
            } elseif (isset($data['id'])) {
                // Poll for result
                $prediction_id = $data['id'];
                $attempts = 0;
                while ($attempts < 20) { // Increased from 10 to 20 attempts
                    sleep(2);
                    $status_response = wp_remote_get('https://api.replicate.com/v1/predictions/' . $prediction_id, array(
                        'headers' => array('Authorization' => 'Bearer ' . $api_token),
                        'timeout' => 30
                    ));
                    
                    if (!is_wp_error($status_response)) {
                        $status_data = json_decode(wp_remote_retrieve_body($status_response), true);
                        if (isset($status_data['status']) && $status_data['status'] === 'succeeded') {
                            if (isset($status_data['output'])) {
                                $metadata_text = is_array($status_data['output']) ? implode('', $status_data['output']) : $status_data['output'];
                                break;
                            }
                        } elseif (isset($status_data['status']) && ($status_data['status'] === 'failed' || $status_data['status'] === 'canceled')) {
                            break;
                        }
                    }
                    $attempts++;
                }
            }
            
            // Parse the response
            $metadata_text = trim($metadata_text);
            if (preg_match('/(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/', $metadata_text, $matches)) {
                return array(
                    'prep_time' => intval($matches[1]),
                    'cook_time' => intval($matches[2]),
                    'servings' => intval($matches[3])
                );
            }
            
            // Fallback defaults
            return array('prep_time' => 15, 'cook_time' => 30, 'servings' => 4);
        }
        
        /**
         * Create WP Recipe Maker recipe from generated content
         */
        public function create_wprm_recipe($title, $content, $featured_image_id = 0) {
            // Check if WP Recipe Maker is installed
            if (!class_exists('WPRM_Recipe_Saver')) {
                return false;
            }
            
            // Parse ingredients and instructions
            $ingredients = $this->parse_ingredients_from_html($content);
            $instructions = $this->parse_instructions_from_html($content);
            
            error_log('WPRM: Parsed ' . count($ingredients) . ' ingredient groups and ' . count($instructions) . ' instruction groups');
            
            // If we couldn't parse anything, don't create recipe
            if (empty($ingredients) && empty($instructions)) {
                error_log('WPRM: ERROR - No ingredients or instructions found. Cannot create recipe.');
                error_log('WPRM: Content preview: ' . substr($content, 0, 1000));
                return false;
            }
            
            if (empty($ingredients)) {
                error_log('WPRM: WARNING - No ingredients found, but instructions exist. Creating recipe anyway.');
            }
            
            if (empty($instructions)) {
                error_log('WPRM: WARNING - No instructions found, but ingredients exist. Creating recipe anyway.');
            }
            
            // Generate metadata using AI
            $metadata = $this->generate_recipe_metadata($title, $content);
            
            // Get selected template mode
            $template_mode = get_option('rw_wprm_template_mode', 'default');
            
            // Prepare recipe data for WP Recipe Maker
            $recipe_data = array(
                'name' => $title,
                'summary' => '', // Could extract first paragraph if desired
                'image_id' => $featured_image_id,
                'servings' => $metadata['servings'],
                'servings_unit' => 'servings',
                'prep_time' => $metadata['prep_time'],
                'cook_time' => $metadata['cook_time'],
                'total_time' => $metadata['prep_time'] + $metadata['cook_time'],
                'ingredients' => $ingredients,
                'instructions' => $instructions,
                'tags' => array()
            );
            
            // Create the recipe
            $recipe_id = WPRM_Recipe_Saver::create_recipe($recipe_data);
            
            // Set template as post meta if not default
            if ($recipe_id && $template_mode !== 'default') {
                update_post_meta($recipe_id, 'wprm_template', $template_mode);
                error_log('WPRM: Set template to ' . $template_mode . ' for recipe ' . $recipe_id);
            }
            
            return $recipe_id;
        }
        
        /**
         * Insert WP Recipe Maker shortcode into content
         */
        private function insert_wprm_shortcode($content, $recipe_id) {
            // Get template mode
            $template_mode = get_option('rw_wprm_template_mode', 'default');
            
            // Build shortcode with template parameter if not default
            if ($template_mode !== 'default') {
                $shortcode = "\n\n" . '[wprm-recipe id="' . $recipe_id . '" template="' . $template_mode . '"]' . "\n\n";
                error_log('WPRM: Inserting shortcode with template: ' . $template_mode);
            } else {
                $shortcode = "\n\n" . '[wprm-recipe id="' . $recipe_id . '"]' . "\n\n";
            }
            
            // Get placement setting
            $placement = get_option('rw_wprm_placement', 'before_first_h2');
            error_log('WPRM: Placement setting: ' . $placement);
            
            switch ($placement) {
                case 'after_first_h2':
                    // Find first H2 and insert after it
                    if (preg_match('/<h2[^>]*>.*?<\/h2>/is', $content, $matches, PREG_OFFSET_CAPTURE)) {
                        $h2_end_pos = $matches[0][1] + strlen($matches[0][0]);
                        $content = substr_replace($content, $shortcode, $h2_end_pos, 0);
                        error_log('WPRM: Inserted after first H2');
                    } else {
                        // No H2 found, append to end
                        $content .= $shortcode;
                        error_log('WPRM: No H2 found, inserted at end');
                    }
                    break;
                    
                case 'end_of_content':
                    // Append to end
                    $content .= $shortcode;
                    error_log('WPRM: Inserted at end of content');
                    break;
                    
                case 'before_first_h2':
                default:
                    // Find first H2 and insert before it
                    if (preg_match('/<h2[^>]*>/i', $content, $matches, PREG_OFFSET_CAPTURE)) {
                        $h2_pos = $matches[0][1];
                        $content = substr_replace($content, $shortcode, $h2_pos, 0);
                        error_log('WPRM: Inserted before first H2');
                    } else {
                        // No H2 found, append to end
                        $content .= $shortcode;
                        error_log('WPRM: No H2 found, inserted at end');
                    }
                    break;
            }
            
            return $content;
        }
    }

    new RecipeWriterPlugin();
}

// Make sure TCPDF is available
if (!class_exists('TCPDF') && !function_exists('rw_load_tcpdf')) {
    /**
     * Load TCPDF library if not already loaded
     */
    function rw_load_tcpdf() {
        // Check if TCPDF is already loaded by another plugin
        if (!class_exists('TCPDF')) {
            // Define path to TCPDF library
            $tcpdf_path = plugin_dir_path(__FILE__) . 'tcpdf/';
            
            // If TCPDF is not installed, use WordPress HTTP API to download it
            if (!file_exists($tcpdf_path . 'tcpdf.php')) {
                // Create directory if it doesn't exist
                if (!file_exists($tcpdf_path)) {
                    mkdir($tcpdf_path, 0755, true);
                }
                
                // Download TCPDF from GitHub
                $zip_url = 'https://github.com/tecnickcom/TCPDF/archive/refs/heads/main.zip';
                $download_file = download_url($zip_url);
                
                if (!is_wp_error($download_file)) {
                    // Unzip the file
                    $zip = new ZipArchive;
                    if ($zip->open($download_file) === TRUE) {
                        $zip->extractTo($tcpdf_path . '../');
                        $zip->close();
                        
                        // Rename the directory
                        rename($tcpdf_path . '../TCPDF-main', $tcpdf_path);
                    }
                    // Remove the zip file
                    @unlink($download_file);
                }
            }
            
            // If TCPDF is now available, load it
            if (file_exists($tcpdf_path . 'tcpdf.php')) {
                require_once($tcpdf_path . 'tcpdf.php');
            }
        }
    }
}

/*
Optional Activation Hook:
Uncomment to deactivate the plugin immediately if the license is invalid.
*/
/*
register_activation_hook(__FILE__, 'recipe_writer_activation_check');
function recipe_writer_activation_check() {
    $license = get_option('rw_license_key', '');
    $plugin = new RecipeWriterPlugin();
    $valid  = $plugin->verify_license_key($license);
    if ( ! $valid ) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die("Invalid or expired license key. Please enter a valid license in Settings.");
    }
}
*/
?>
