// supabase/functions/generate-queue/index.ts
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

serve(async (req) => {
  if (req.method !== "POST") return json(405, { error: "Method not allowed" });

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_ANON_KEY")!;
  const authHeader = req.headers.get("Authorization") || "";
  const supabase = createClient(supabaseUrl, supabaseKey, {
    global: { headers: { Authorization: authHeader } },
  });

  const { data: auth, error: authErr } = await supabase.auth.getUser();
  if (authErr || !auth?.user) return json(401, { error: "Unauthorized" });

  // Fetch pending + error for current user (RLS enforced)
  const { data: rows, error } = await supabase
    .from("articles")
    .select("id")
    .in("status", ["pending", "error"])
    .order("created_at", { ascending: true });

  if (error) return json(500, { error: error.message });

  const articleIds = (rows ?? []).map((r) => r.id as string);
  const results: Array<{ id: string; status: string; error?: string }> = [];

  for (const id of articleIds) {
    try {
      // call generate-article internally via HTTP
      const base = Deno.env.get("SUPABASE_URL")!;
      const resp = await fetch(`${base}/functions/v1/generate-article`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: authHeader,
        },
        body: JSON.stringify({ articleId: id }),
      });

      const data = await resp.json().catch(() => ({}));
      results.push({ id, status: data?.status ?? (resp.ok ? "completed" : "error"), error: data?.error });

      // tiny pacing
      await sleep(350);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Unknown error";
      results.push({ id, status: "error", error: msg });
    }
  }

  const okCount = results.filter((r) => r.status === "completed").length;
  const errCount = results.length - okCount;

  return json(200, { processed: results.length, completed: okCount, errors: errCount, results });
});
