// supabase/functions/generate-article/index.ts
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

type ArticleType = "classic" | "listicle";

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function countTag(html: string, tag: string) {
  const re = new RegExp(`<${tag}(\\s|>)`, "gi");
  const matches = html.match(re);
  return matches ? matches.length : 0;
}

function startsWithH1(html: string) {
  return /^\s*<h1(\\s|>)/i.test(html || "");
}

function injectVars(promptText: string, title: string, itemCount: number | null) {
  let out = promptText.replaceAll("{title}", title);
  if (itemCount !== null) out = out.replaceAll("{itemCount}", String(itemCount));
  return out;
}

serve(async (req) => {
  if (req.method !== "POST") return json(405, { error: "Method not allowed" });

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const supabaseKey = Deno.env.get("SUPABASE_ANON_KEY")!;
  const openaiKey = Deno.env.get("OPENAI_API_KEY");

  if (!openaiKey) return json(500, { error: "OPENAI_API_KEY not configured" });

  const authHeader = req.headers.get("Authorization") || "";
  const supabase = createClient(supabaseUrl, supabaseKey, {
    global: { headers: { Authorization: authHeader } },
  });

  const { data: auth, error: authErr } = await supabase.auth.getUser();
  if (authErr || !auth?.user) return json(401, { error: "Unauthorized" });

  const body = await req.json().catch(() => null);
  const articleId = body?.articleId as string | undefined;
  if (!articleId) return json(400, { error: "articleId required" });

  // Load article (RLS ensures ownership)
  const { data: article, error: aErr } = await supabase
    .from("articles")
    .select("id,type,niche,title,item_count,status")
    .eq("id", articleId)
    .single();

  if (aErr || !article) return json(404, { error: "Article not found" });

  const type = article.type as ArticleType;
  const niche = article.niche as string;
  const title = article.title as string;
  const itemCount = (article.item_count ?? null) as number | null;

  // Set generating
  await supabase.from("articles").update({ status: "generating", error_message: null }).eq("id", articleId);

  // Load prompt: prefer user override else global default
  const { data: promptRows, error: pErr } = await supabase
    .from("prompts")
    .select("prompt_text,user_id,is_default")
    .eq("type", type)
    .eq("niche", niche)
    .or(`user_id.eq.${auth.user.id},user_id.is.null`);

  if (pErr || !promptRows?.length) {
    await supabase.from("articles").update({ status: "error", error_message: "No prompt found for this type/niche." }).eq("id", articleId);
    return json(500, { error: "No prompt found" });
  }

  const userPrompt = promptRows.find((r) => r.user_id === auth.user.id);
  const globalPrompt = promptRows.find((r) => r.user_id === null && r.is_default === true);
  const chosenPrompt = (userPrompt?.prompt_text ?? globalPrompt?.prompt_text ?? promptRows[0].prompt_text) as string;

  const finalPrompt = injectVars(chosenPrompt, title, itemCount);

  const system = `You are an expert writing assistant. Return ONLY valid HTML. Do not include markdown or code fences.`;
  const user = finalPrompt;

  async function callOpenAI(extraInstruction?: string) {
    const messages = [
      { role: "system", content: system },
      { role: "user", content: extraInstruction ? `${user}\n\nIMPORTANT FIX:\n${extraInstruction}` : user },
    ];

    const resp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        temperature: 0.7,
        messages,
      }),
    });

    if (!resp.ok) {
      const t = await resp.text().catch(() => "");
      throw new Error(`OpenAI error ${resp.status}: ${t.slice(0, 300)}`);
    }

    const data = await resp.json();
    const content = data?.choices?.[0]?.message?.content ?? "";
    return String(content);
  }

  function validate(html: string) {
    const errors: string[] = [];
    if (!startsWithH1(html)) errors.push("Output must start with <h1>.");
    if (type === "listicle") {
      if (typeof itemCount !== "number" || itemCount <= 0) errors.push("Listicle item_count missing/invalid.");
      const h2Count = countTag(html, "h2");
      if (typeof itemCount === "number" && h2Count !== itemCount) {
        errors.push(`Expected exactly ${itemCount} <h2> sections but found ${h2Count}.`);
      }
    }
    return { ok: errors.length === 0, errors };
  }

  try {
    let html = await callOpenAI();
    let v = validate(html);

    if (!v.ok) {
      html = await callOpenAI(
        `Your last output was invalid: ${v.errors.join(" ")} Fix it now. Return ONLY HTML.`
      );
      v = validate(html);
    }

    if (!v.ok) {
      await supabase
        .from("articles")
        .update({ status: "error", error_message: v.errors.join(" ") })
        .eq("id", articleId);

      return json(200, { status: "error", articleId, error: v.errors.join(" ") });
    }

    await supabase
      .from("articles")
      .update({ status: "completed", content_html: html, error_message: null })
      .eq("id", articleId);

    return json(200, { status: "completed", articleId });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Unknown error";
    await supabase.from("articles").update({ status: "error", error_message: msg }).eq("id", articleId);
    return json(500, { status: "error", articleId, error: msg });
  }
});
