-- Create prompts table
CREATE TABLE public.prompts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL CHECK (type IN ('classic', 'listicle')),
  niche TEXT NOT NULL CHECK (niche IN ('general', 'food', 'decor', 'fashion')),
  name TEXT NOT NULL,
  prompt_text TEXT NOT NULL,
  is_default BOOLEAN NOT NULL DEFAULT false,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create articles table
CREATE TABLE public.articles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('classic', 'listicle')),
  niche TEXT NOT NULL,
  title TEXT NOT NULL,
  item_count INTEGER,
  status TEXT NOT NULL CHECK (status IN ('pending', 'generating', 'completed', 'error')) DEFAULT 'pending',
  content_html TEXT,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create image_prompt_templates table
CREATE TABLE public.image_prompt_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  prompt_text TEXT NOT NULL,
  is_default BOOLEAN NOT NULL DEFAULT false,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create article_image_prompts table
CREATE TABLE public.article_image_prompts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  article_id UUID NOT NULL REFERENCES public.articles(id) ON DELETE CASCADE,
  prompt_text TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create wordpress_sites table
CREATE TABLE public.wordpress_sites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  site_name TEXT NOT NULL,
  site_url TEXT NOT NULL,
  auth_type TEXT NOT NULL DEFAULT 'app_password',
  wp_username TEXT NOT NULL,
  wp_app_password TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.prompts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.image_prompt_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.article_image_prompts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wordpress_sites ENABLE ROW LEVEL SECURITY;

-- RLS Policies for prompts
CREATE POLICY "Users can view global and own prompts"
  ON public.prompts FOR SELECT
  USING (user_id IS NULL OR user_id = auth.uid());

CREATE POLICY "Users can insert own prompts"
  ON public.prompts FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own prompts"
  ON public.prompts FOR UPDATE
  USING (user_id = auth.uid());

CREATE POLICY "Users can delete own prompts"
  ON public.prompts FOR DELETE
  USING (user_id = auth.uid());

-- RLS Policies for articles
CREATE POLICY "Users can view own articles"
  ON public.articles FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own articles"
  ON public.articles FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own articles"
  ON public.articles FOR UPDATE
  USING (user_id = auth.uid());

CREATE POLICY "Users can delete own articles"
  ON public.articles FOR DELETE
  USING (user_id = auth.uid());

-- RLS Policies for image_prompt_templates
CREATE POLICY "Users can view global and own templates"
  ON public.image_prompt_templates FOR SELECT
  USING (user_id IS NULL OR user_id = auth.uid());

CREATE POLICY "Users can insert own templates"
  ON public.image_prompt_templates FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own templates"
  ON public.image_prompt_templates FOR UPDATE
  USING (user_id = auth.uid());

CREATE POLICY "Users can delete own templates"
  ON public.image_prompt_templates FOR DELETE
  USING (user_id = auth.uid());

-- RLS Policies for article_image_prompts (user owns via article)
CREATE POLICY "Users can view own article image prompts"
  ON public.article_image_prompts FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.articles
      WHERE articles.id = article_image_prompts.article_id
      AND articles.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own article image prompts"
  ON public.article_image_prompts FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.articles
      WHERE articles.id = article_image_prompts.article_id
      AND articles.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete own article image prompts"
  ON public.article_image_prompts FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.articles
      WHERE articles.id = article_image_prompts.article_id
      AND articles.user_id = auth.uid()
    )
  );

-- RLS Policies for wordpress_sites
CREATE POLICY "Users can view own wordpress sites"
  ON public.wordpress_sites FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own wordpress sites"
  ON public.wordpress_sites FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own wordpress sites"
  ON public.wordpress_sites FOR UPDATE
  USING (user_id = auth.uid());

CREATE POLICY "Users can delete own wordpress sites"
  ON public.wordpress_sites FOR DELETE
  USING (user_id = auth.uid());

-- Triggers for updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_prompts_updated_at
  BEFORE UPDATE ON public.prompts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_articles_updated_at
  BEFORE UPDATE ON public.articles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_image_prompt_templates_updated_at
  BEFORE UPDATE ON public.image_prompt_templates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_wordpress_sites_updated_at
  BEFORE UPDATE ON public.wordpress_sites
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed placeholder prompts (global defaults)
INSERT INTO public.prompts (type, niche, name, prompt_text, is_default, user_id) VALUES
  ('classic', 'general', 'Classic General Default', 'Write a comprehensive article about {title}. Provide detailed information and insights. Return HTML only starting with <h1>{title}</h1>.', true, NULL),
  ('listicle', 'general', 'Listicle General Default', 'Write a listicle article titled {title} with exactly {itemCount} items. Return HTML only. Start with <h1>{title}</h1>. Use <h2> for each of the {itemCount} list items.', true, NULL),
  ('listicle', 'food', 'Listicle Food Default', 'Write a food-focused listicle titled {title} with exactly {itemCount} items. Return HTML only. Start with <h1>{title}</h1>. Use <h2> for each of the {itemCount} list items.', true, NULL),
  ('listicle', 'decor', 'Listicle Decor Default', 'Write a home decor listicle titled {title} with exactly {itemCount} items. Return HTML only. Start with <h1>{title}</h1>. Use <h2> for each of the {itemCount} list items.', true, NULL),
  ('listicle', 'fashion', 'Listicle Fashion Default', 'Write a fashion-focused listicle titled {title} with exactly {itemCount} items. Return HTML only. Start with <h1>{title}</h1>. Use <h2> for each of the {itemCount} list items.', true, NULL);

-- Seed placeholder image prompt template
INSERT INTO public.image_prompt_templates (name, prompt_text, is_default, user_id) VALUES
  ('Default Image Prompt Template', 'Generate an image for an article titled "{title}" with {count} items. Article content: {content}', true, NULL);