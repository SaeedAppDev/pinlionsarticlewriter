-- Add api_key column and migrate existing WordPress site credentials
ALTER TABLE public.wordpress_sites
ADD COLUMN IF NOT EXISTS api_key text;

-- Migrate existing wp_app_password into api_key if present
UPDATE public.wordpress_sites
SET api_key = COALESCE(api_key, wp_app_password)
WHERE api_key IS NULL;

-- Ensure api_key is required for all rows
ALTER TABLE public.wordpress_sites
ALTER COLUMN api_key SET NOT NULL;

-- Drop legacy credential columns no longer used by the macOS-style UI
ALTER TABLE public.wordpress_sites
DROP COLUMN IF EXISTS wp_app_password,
DROP COLUMN IF EXISTS wp_username,
DROP COLUMN IF EXISTS auth_type;