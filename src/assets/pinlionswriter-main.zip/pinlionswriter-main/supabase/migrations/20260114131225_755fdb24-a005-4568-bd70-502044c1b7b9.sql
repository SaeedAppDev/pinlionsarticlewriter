-- Create table to store per-user API settings
CREATE TABLE IF NOT EXISTS public.user_api_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  openai_api_key text,
  replicate_api_token text,
  replicate_model text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT user_api_settings_user_unique UNIQUE (user_id)
);

-- Enable row level security
ALTER TABLE public.user_api_settings ENABLE ROW LEVEL SECURITY;

-- Policies so users can manage only their own settings
CREATE POLICY "Users can view their own api settings" ON public.user_api_settings
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own api settings" ON public.user_api_settings
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own api settings" ON public.user_api_settings
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own api settings" ON public.user_api_settings
  FOR DELETE
  USING (auth.uid() = user_id);

-- Trigger to keep updated_at fresh
CREATE TRIGGER user_api_settings_set_updated_at
BEFORE UPDATE ON public.user_api_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();