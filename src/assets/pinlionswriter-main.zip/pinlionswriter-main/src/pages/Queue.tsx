import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Play, RotateCw, Trash2, Clock, RefreshCw } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface Article {
  id: string;
  title: string;
  type: string;
  niche: string;
  item_count: number | null;
  status: string;
  updated_at: string;
}

export default function Queue() {
  const { toast } = useToast();
  const [articles, setArticles] = useState<Article[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isGeneratingAll, setIsGeneratingAll] = useState(false);
  const [generatingIds, setGeneratingIds] = useState<Set<string>>(new Set());

  const fetchArticles = async () => {
    try {
      const { data, error } = await supabase
        .from("articles")
        .select("*")
        .in("status", ["pending", "generating", "error"])
        .order("created_at", { ascending: true });

      if (error) throw error;
      setArticles(data || []);
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to fetch queue.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchArticles();
  }, []);

  const handleGenerateSingle = async (articleId: string) => {
    setGeneratingIds((prev) => new Set(prev).add(articleId));

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-article`,
        {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${session.access_token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ articleId }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Generation failed");
      }

      toast({
        title: "Success!",
        description: "Article generated successfully.",
      });

      await fetchArticles();
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Generation failed.",
        variant: "destructive",
      });
    } finally {
      setGeneratingIds((prev) => {
        const next = new Set(prev);
        next.delete(articleId);
        return next;
      });
    }
  };

  const handleGenerateAll = async () => {
    setIsGeneratingAll(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/generate-queue`,
        {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${session.access_token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({}),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Generation failed");
      }

      toast({
        title: "Batch Complete!",
        description: result.message || "All articles processed.",
      });

      await fetchArticles();
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Generation failed.",
        variant: "destructive",
      });
    } finally {
      setIsGeneratingAll(false);
    }
  };

  const handleDelete = async (articleId: string) => {
    if (!confirm("Are you sure you want to delete this article?")) return;

    try {
      const { error } = await supabase.from("articles").delete().eq("id", articleId);

      if (error) throw error;

      toast({
        title: "Deleted",
        description: "Article removed from queue.",
      });

      await fetchArticles();
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to delete article.",
        variant: "destructive",
      });
    }
  };

  const pendingCount = articles.filter((a) => a.status === "pending").length;
  const generatingCount = articles.filter((a) => a.status === "generating").length;
  const errorCount = articles.filter((a) => a.status === "error").length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-1 text-slate-900">
          Article Queue
        </h1>
        <p className="text-sm text-muted-foreground">
          {pendingCount} pending  b7 {articles.length - pendingCount - errorCount} completed  b7 {errorCount} errors
        </p>
      </div>

      <div className="flex gap-3 mb-6">
        <Button
          onClick={handleGenerateAll}
          disabled={isGeneratingAll || pendingCount + errorCount === 0}
          size="lg"
          className="rounded-xl px-8 bg-[linear-gradient(90deg,#7C3AED_0%,#9333EA_50%,#EC4899_100%)] text-white shadow-md disabled:opacity-60 hover:brightness-105"
        >
          <Play className="h-4 w-4 mr-2" />
          Generate All Articles ({pendingCount + errorCount})
        </Button>
        <Button onClick={fetchArticles} variant="outline" size="lg" className="rounded-full px-6">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {articles.length === 0 ? (
        <Card className="p-16 bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-100 shadow-sm rounded-2xl mt-2">
          <div className="flex flex-col items-center justify-center text-center gap-2">
            <Clock className="h-12 w-12 text-slate-500 dark:text-slate-200 mb-2" />
            <h3 className="text-base font-semibold">No articles in queue</h3>
            <p className="text-sm max-w-sm">
              Add some article titles from the Add screen to start generating.
            </p>
          </div>
        </Card>
      ) : (
        <Card className="rounded-2xl shadow-sm border border-border/60 bg-card/95">
          <Table>
            <TableHeader>
              <TableRow className="text-xs text-muted-foreground/80">
                <TableHead className="font-medium">Title</TableHead>
                <TableHead className="font-medium">Type</TableHead>
                <TableHead className="font-medium">Niche</TableHead>
                <TableHead className="font-medium">Items</TableHead>
                <TableHead className="font-medium">Status</TableHead>
                <TableHead className="font-medium">Updated</TableHead>
                <TableHead className="text-right font-medium">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {articles.map((article) => (
                <TableRow key={article.id} className="text-sm">
                  <TableCell className="font-medium max-w-xs truncate">
                    {article.title}
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="rounded-full px-3 py-0.5 text-[11px] font-medium">
                      {article.type}
                    </Badge>
                  </TableCell>
                  <TableCell className="capitalize">{article.niche}</TableCell>
                  <TableCell>{article.item_count || "-"}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        article.status === "pending"
                          ? "outline"
                          : article.status === "generating"
                          ? "default"
                          : "destructive"
                      }
                      className="rounded-full px-3 py-0.5 text-[11px] font-medium capitalize"
                    >
                      {article.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(article.updated_at), { addSuffix: true })}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex gap-1 justify-end">
                      {(article.status === "pending" || article.status === "error") && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 rounded-full"
                          onClick={() => handleGenerateSingle(article.id)}
                          disabled={generatingIds.has(article.id)}
                        >
                          {article.status === "error" ? (
                            <RotateCw className="h-3 w-3" />
                          ) : (
                            <Play className="h-3 w-3" />
                          )}
                        </Button>
                      )}
                      {article.status !== "generating" && (
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 rounded-full"
                          onClick={() => handleDelete(article.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
}
