import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Keyboard, ImageIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export default function Settings() {
  const [openaiKey, setOpenaiKey] = useState("");
  const [replicateKey, setReplicateKey] = useState("");
  const [replicateModel, setReplicateModel] = useState("google/nano-banana-pro");
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const hasAnyKey = Boolean(openaiKey || replicateKey);

  // Load existing settings
  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from("user_api_settings")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setOpenaiKey(data.openai_api_key || "");
        setReplicateKey(data.replicate_api_token || "");
        setReplicateModel(data.replicate_model || "google/nano-banana-pro");
      }
    } catch (error) {
      console.error("Error loading settings:", error);
      toast.error("Failed to load API settings");
    } finally {
      setIsLoading(false);
    }
  };

  const saveSettings = async () => {
    setIsSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error("You must be logged in to save settings");
        return;
      }

      if (!openaiKey && !replicateKey) {
        toast.error("Please enter at least one API key");
        return;
      }

      const { error } = await supabase
        .from("user_api_settings")
        .upsert({
          user_id: user.id,
          openai_api_key: openaiKey || null,
          replicate_api_token: replicateKey || null,
          replicate_model: replicateModel,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: "user_id"
        });

      if (error) throw error;

      toast.success("API settings saved successfully!");
    } catch (error) {
      console.error("Error saving settings:", error);
      toast.error("Failed to save API settings");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto">
      {/* Page header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 text-slate-900 dark:text-slate-50">
          Settings
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-300">
          Configure your API keys and generation preferences
        </p>
      </div>

      {/* Currently Active Prompts */}
      <Card className="mb-6 rounded-2xl border border-slate-200/80 bg-white/90 shadow-[0_18px_45px_rgba(15,23,42,0.08)] backdrop-blur-sm">
        <div className="flex items-center justify-between px-6 pt-4 pb-3 border-b border-slate-100/80">
          <div className="flex items-center gap-2 text-sm font-medium text-slate-800">
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
            </span>
            Currently Active Prompts
          </div>
          <p className="text-[11px] text-slate-500">
            Both prompts are shown below. Edit them separately in their own sections.
          </p>
        </div>

        <div className="grid gap-4 px-6 py-4 md:grid-cols-2">
          {/* Classic Articles card */}
          <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-[0_10px_30px_rgba(15,23,42,0.02)]">
            <div className="mb-2 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-[0.16em] text-slate-500">
                <Keyboard className="h-3.5 w-3.5 text-slate-500" />
                Classic Articles
              </div>
            </div>
            <button className="mb-1 text-sm font-semibold text-violet-600 hover:text-violet-700">
              Classic Article Prompt
            </button>
            <p className="text-[11px] text-slate-500">
              Always uses classic article prompt
            </p>
          </div>

          {/* Listicle Articles card */}
          <div className="rounded-2xl border border-fuchsia-200 bg-fuchsia-50/70 px-4 py-3 shadow-[0_10px_30px_rgba(191,90,242,0.18)]">
            <div className="mb-2 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-[0.16em] text-fuchsia-600">
                <ImageIcon className="h-3.5 w-3.5" />
                Listicle Articles
              </div>
            </div>
            <button className="mb-1 text-sm font-semibold text-violet-700 hover:text-violet-800">
              Home Decor Listicle
            </button>
            <p className="text-[11px] text-slate-500">
              Currently selected listicle category
            </p>
          </div>
        </div>
      </Card>

      {/* API Configuration */}
      <Card className="mb-6 rounded-2xl border border-slate-200 bg-white shadow-[0_18px_45px_rgba(15,23,42,0.06)]">
        <div className="flex items-center gap-3 border-b border-slate-100 px-6 py-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-violet-100 text-violet-600">
            <ImageIcon className="h-4 w-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-slate-900">API Configuration</h2>
            <p className="text-xs text-slate-500">
              Article + Image generation providers
            </p>
          </div>
        </div>

        <div className="px-6 pb-5 pt-4 space-y-4">
          <p className="text-xs font-medium text-slate-600">
            {hasAnyKey
              ? "API keys detected. Update them below and click Save Settings to apply changes."
              : "Enter your API keys below. OpenAI will be used for article generation and Replicate for image generation."}
          </p>

          {/* OpenAI API Key */}
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
              OpenAI API Key (Articles)
            </label>
            <Input
              type="password"
              placeholder="Enter your OpenAI API key"
              value={openaiKey}
              onChange={(e) => setOpenaiKey(e.target.value)}
              className="h-11 rounded-xl border-slate-200 bg-slate-50 text-[13px]"
            />
          </div>

          {/* Replicate API Token */}
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
              Replicate API Token (Images)
            </label>
            <Input
              type="password"
              placeholder="Enter your Replicate API token"
              value={replicateKey}
              onChange={(e) => setReplicateKey(e.target.value)}
              className="h-11 rounded-xl border-slate-200 bg-slate-50 text-[13px]"
              disabled={isLoading}
            />
            <p className="text-xs text-slate-500">
              Your Replicate API token for image generation models. Get yours at{" "}
              <a
                href="https://replicate.com"
                target="_blank"
                rel="noreferrer"
                className="font-medium text-sky-600 hover:text-sky-700"
              >
                replicate.com
              </a>
            </p>
          </div>

          {/* Replicate Model Selector */}
          {replicateKey && (
            <div className="space-y-3">
              <label className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                Replicate Image Model
              </label>
              <Select value={replicateModel} onValueChange={setReplicateModel}>
                <SelectTrigger className="h-11 rounded-xl border-slate-200 bg-white text-sm text-slate-800 shadow-[0_6px_18px_rgba(15,23,42,0.04)]">
                  <SelectValue placeholder="Select a model" />
                </SelectTrigger>
                <SelectContent className="z-50 bg-white text-sm text-slate-800 shadow-xl">
                  <SelectItem value="google/nano-banana-pro">
                    Google Nano Banana Pro  b7 Balanced quality & speed (est. $0.02 a0/ image)
                  </SelectItem>
                  <SelectItem value="prunaai/z-image-turbo">
                    Z-Image Turbo (Pruna AI)  b7 Ultra fast drafts (est. $0.01 a0/ image)
                  </SelectItem>
                  <SelectItem value="bytedance/seedream-4.5">
                    Seedream 4.5 (ByteDance)  b7 High detail (est. $0.04 a0/ image)
                  </SelectItem>
                  <SelectItem value="black-forest-labs/flux-schnell">
                    FLUX Schnell  b7 Fast general-purpose (similar to ~$0.02 a0/ image)
                  </SelectItem>
                  <SelectItem value="black-forest-labs/flux-dev">
                    FLUX Dev  b7 Higher quality, slower (est. mid-tier pricing)
                  </SelectItem>
                  <SelectItem value="black-forest-labs/flux-pro">
                    FLUX Pro  b7 Premium quality (higher cost per image)
                  </SelectItem>
                  <SelectItem value="stability-ai/sdxl">
                    Stable Diffusion XL  b7 Versatile, good quality (budget-friendly)
                  </SelectItem>
                  <SelectItem value="stability-ai/stable-diffusion-3">
                    Stable Diffusion 3  b7 Newer SD model (moderate cost)
                  </SelectItem>
                  <SelectItem value="bytedance/sdxl-lightning-4step">
                    SDXL Lightning  b7 Ultra fast, lower cost per image
                  </SelectItem>
                  <SelectItem value="playgroundai/playground-v2.5-1024px-aesthetic">
                    Playground v2.5  b7 Stylized, aesthetic outputs
                  </SelectItem>
                  <SelectItem value="lucataco/realvisxl-v4.0">
                    RealVisXL v4.0  b7 Photorealistic portraits & products
                  </SelectItem>
                  <SelectItem value="prompthero/openjourney">
                    OpenJourney  b7 Artistic / illustration styles
                  </SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500">
                Pricing is approximate and based on public Replicate listings; always confirm in your Replicate
                dashboard.
              </p>

              {/* Model previews */}
              <div className="mt-1 grid gap-3 md:grid-cols-3 animate-enter">
                <a
                  href="https://replicate.com/google/nano-banana-pro"
                  target="_blank"
                  rel="noreferrer"
                  className={cn(
                    "group rounded-xl border bg-slate-50 p-3 transition hover-scale hover:border-violet-300 hover:bg-violet-50",
                    replicateModel === "google/nano-banana-pro" &&
                      "border-violet-400 shadow-[0_0_0_1px_rgba(139,92,246,0.6)] shadow-violet-300/60"
                  )}
                >
                  <div className="mb-2 flex items-center gap-2">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 via-amber-400 to-emerald-400 text-[10px] font-semibold text-white shadow-sm">
                      NB
                    </div>
                    <p className="text-[11px] font-medium text-slate-900">Nano Banana Pro</p>
                  </div>
                  <div className="mb-2 h-16 w-full overflow-hidden rounded-lg bg-gradient-to-br from-violet-300 via-amber-200 to-emerald-200" />
                  <p className="text-[10px] text-slate-500">
                    Balanced general-purpose image model. Click to see real samples.
                  </p>
                </a>
                <a
                  href="https://replicate.com/prunaai/z-image-turbo"
                  target="_blank"
                  rel="noreferrer"
                  className={cn(
                    "group rounded-xl border bg-slate-50 p-3 transition hover-scale hover:border-violet-300 hover:bg-violet-50",
                    replicateModel === "prunaai/z-image-turbo" &&
                      "border-sky-400 shadow-[0_0_0_1px_rgba(56,189,248,0.6)] shadow-sky-300/60"
                  )}
                >
                  <div className="mb-2 flex items-center gap-2">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-sky-500 via-cyan-400 to-emerald-400 text-[10px] font-semibold text-white shadow-sm">
                      ZT
                    </div>
                    <p className="text-[11px] font-medium text-slate-900">Z-Image Turbo</p>
                  </div>
                  <div className="mb-2 h-16 w-full overflow-hidden rounded-lg bg-gradient-to-br from-sky-300 via-cyan-200 to-emerald-200" />
                  <p className="text-[10px] text-slate-500">
                    Optimized for speed and low cost. Click to view examples on Replicate.
                  </p>
                </a>
                <a
                  href="https://replicate.com/bytedance/seedream-4.5"
                  target="_blank"
                  rel="noreferrer"
                  className={cn(
                    "group rounded-xl border bg-slate-50 p-3 transition hover-scale hover:border-violet-300 hover:bg-violet-50",
                    replicateModel === "bytedance/seedream-4.5" &&
                      "border-rose-400 shadow-[0_0_0_1px_rgba(244,63,94,0.6)] shadow-rose-300/60"
                  )}
                >
                  <div className="mb-2 flex items-center gap-2">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-rose-500 via-fuchsia-400 to-indigo-400 text-[10px] font-semibold text-white shadow-sm">
                      SD
                    </div>
                    <p className="text-[11px] font-medium text-slate-900">Seedream 4.5</p>
                  </div>
                  <div className="mb-2 h-16 w-full overflow-hidden rounded-lg bg-gradient-to-br from-rose-300 via-fuchsia-200 to-indigo-200" />
                  <p className="text-[10px] text-slate-500">
                    High-detail, higher-cost model. Click to inspect quality samples.
                  </p>
                </a>
              </div>
            </div>
          )}


          <div className="flex items-center justify-end pt-1">
            <Button 
              onClick={saveSettings}
              disabled={isSaving || isLoading}
              className="rounded-full px-6 h-10 bg-[linear-gradient(90deg,#7C3AED_0%,#9333EA_50%,#EC4899_100%)] text-white shadow-md hover:brightness-105 disabled:opacity-60"
            >
              {isSaving ? "Saving..." : "Save API Settings"}
            </Button>
          </div>
        </div>
      </Card>

      {/* Image Settings */}
      <Card className="mb-10 rounded-2xl border border-slate-200 bg-white shadow-[0_18px_45px_rgba(15,23,42,0.06)]">
        <div className="flex items-center gap-3 border-b border-slate-100 px-6 py-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-rose-100 text-rose-500">
            <ImageIcon className="h-4 w-4" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-slate-900">Image Settings</h2>
          </div>
        </div>

        <div className="px-6 pb-6 pt-4 space-y-5">
          {/* Image Generation Model */}
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
              Image Generation Model
            </label>
            <Select value={replicateModel} onValueChange={setReplicateModel}>
              <SelectTrigger className="h-11 rounded-xl border-slate-200 bg-white text-sm text-slate-800 shadow-[0_6px_18px_rgba(15,23,42,0.04)]">
                <SelectValue placeholder="Select a model" />
              </SelectTrigger>
              <SelectContent className="z-50 bg-white text-sm text-slate-800 shadow-xl">
                <SelectItem value="prunaai/z-image-turbo">
                  Z-Image Turbo (Pruna AI) – $0.01 per image (cheap & very fast)
                </SelectItem>
                <SelectItem value="bytedance/seedream-4.5">
                  Seedream 4.5 (ByteDance) – $0.04 per image (high quality)
                </SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              Choose the AI model for generating featured and in-text images (pricing shown per image)
            </p>
          </div>

          {/* Generate in-text images */}
          <div className="space-y-3">
            <div className="flex items-start gap-2">
              <Checkbox id="generate-intxt" defaultChecked className="mt-0.5" />
              <div>
                <label
                  htmlFor="generate-intxt"
                  className="text-sm font-medium text-slate-800 cursor-pointer"
                >
                  Generate in-text images
                </label>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                  Number of In-Text Images
                </label>
                <Select defaultValue="4">
                  <SelectTrigger className="h-11 rounded-xl border-slate-200 bg-white text-sm text-slate-800 shadow-[0_6px_18px_rgba(15,23,42,0.04)]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="z-50 bg-white text-sm text-slate-800 shadow-xl">
                    <SelectItem value="0">No In-Text Images</SelectItem>
                    <SelectItem value="1">1 Image</SelectItem>
                    <SelectItem value="2">2 Images</SelectItem>
                    <SelectItem value="3">3 Images</SelectItem>
                    <SelectItem value="4">4 Images</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500">
                  Images will be placed throughout the article at strategic H2 positions
                </p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                  In-Text Image Aspect Ratio
                </label>
                <Select defaultValue="9-16">
                  <SelectTrigger className="h-11 rounded-xl border-slate-200 bg-white text-sm text-slate-800 shadow-[0_6px_18px_rgba(15,23,42,0.04)]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="z-50 bg-white text-sm text-slate-800 shadow-xl">
                    <SelectItem value="9-16">9:16 – Vertical (Portrait)</SelectItem>
                    <SelectItem value="16-9">16:9 – Horizontal (Landscape)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500">
                  Choose vertical (9:16) for portrait-style images or horizontal (16:9) for landscape-style
                  images
                </p>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
