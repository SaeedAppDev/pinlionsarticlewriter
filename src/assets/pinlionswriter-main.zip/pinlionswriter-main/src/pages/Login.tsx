import { Auth } from "@supabase/auth-ui-react";
import { ThemeSupa } from "@supabase/auth-ui-shared";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Check if user is already logged in
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        navigate("/mode");
      }
    });

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_IN" && session) {
        toast({
          title: "Welcome!",
          description: "Successfully signed in.",
        });
        navigate("/mode");
      }
      if (event === "SIGNED_OUT") {
        navigate("/login");
      }
      if (event === "PASSWORD_RECOVERY") {
        toast({
          title: "Check your email",
          description: "Password reset link has been sent.",
        });
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate, toast]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold bg-[linear-gradient(90deg,#7C3AED_0%,#9333EA_50%,#EC4899_100%)] bg-clip-text text-transparent mb-2">
            Pin Lions
          </h1>
          <p className="text-sm text-slate-300">Article Writer</p>
        </div>

        <div className="bg-slate-900/80 rounded-2xl shadow-[0_18px_45px_rgba(0,0,0,0.55)] border border-slate-800 p-8 backdrop-blur-sm">
          <Auth
            supabaseClient={supabase}
            appearance={{
              theme: ThemeSupa,
              variables: {
                default: {
                  colors: {
                    brand: "#7C3AED",
                    brandAccent: "#9333EA",
                    inputBackground: "#020617",
                    inputText: "#F9FAFB",
                    inputBorder: "#1F2937",
                    inputBorderHover: "#4B5563",
                    messageText: "#9CA3AF",
                    anchorTextColor: "#9CA3AF",
                  },
                  radii: {
                    buttonBorderRadius: "12px",
                    inputBorderRadius: "10px",
                  },
                },
              },
            }}
            providers={[]}
            redirectTo={window.location.origin}
          />
        </div>
      </div>
    </div>
  );
}
