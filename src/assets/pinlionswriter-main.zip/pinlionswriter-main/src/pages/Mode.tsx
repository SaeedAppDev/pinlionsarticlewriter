import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { FileText, List, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Mode() {
  const navigate = useNavigate();
  const currentMode = localStorage.getItem("articleMode") || "classic";

  const handleModeSelect = (mode: "classic" | "listicle") => {
    localStorage.setItem("articleMode", mode);
    navigate("/add");
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 text-slate-900 dark:text-slate-50">Choose Your Content Type</h1>
        <p className="text-sm text-slate-500 dark:text-slate-300">Select the type of article you want to create</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card
          className={`p-8 cursor-pointer transition-all hover:shadow-lg hover:scale-[1.02] ${
            currentMode === "classic"
              ? "border-primary border-2 shadow-md"
              : "border-border hover:border-primary/50"
          }`}
          onClick={() => handleModeSelect("classic")}
        >
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="p-4 rounded-full bg-gradient-to-br from-primary to-purple-600">
              <FileText className="h-8 w-8 text-white" />
            </div>
            {currentMode === "classic" && (
              <div className="px-3 py-1 bg-primary/10 text-primary text-xs font-semibold rounded-full">
                Active
              </div>
            )}
            <div>
              <h3 className="text-xl font-bold mb-2 text-slate-900 dark:text-slate-50">Classic Article Writer</h3>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                Create in-depth, comprehensive articles with detailed content and insights
              </p>
            </div>
            <Button variant={currentMode === "classic" ? "default" : "outline"} className="w-full">
              Select Classic
            </Button>
          </div>
        </Card>

        <Card
          className={`p-8 cursor-pointer transition-all hover:shadow-lg hover:scale-[1.02] ${
            currentMode === "listicle"
              ? "border-primary border-2 shadow-md"
              : "border-border hover:border-primary/50"
          }`}
          onClick={() => handleModeSelect("listicle")}
        >
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="p-4 rounded-full bg-gradient-to-br from-green-500 to-emerald-600">
              <List className="h-8 w-8 text-white" />
            </div>
            {currentMode === "listicle" && (
              <div className="px-3 py-1 bg-primary/10 text-primary text-xs font-semibold rounded-full">
                Active
              </div>
            )}
            <div>
              <h3 className="text-xl font-bold mb-2 text-slate-900 dark:text-slate-50">Listicle Writer</h3>
              <p className="text-sm text-slate-600 dark:text-slate-300">
                Generate engaging list-based articles with numbered or bulleted items
              </p>
            </div>
            <Button variant={currentMode === "listicle" ? "default" : "outline"} className="w-full">
              Select Listicle
            </Button>
          </div>
        </Card>
      </div>

      <Card className="mt-8 p-6 bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-100">
        <div className="flex items-start gap-3">
          <Sparkles className="h-5 w-5 text-slate-500 dark:text-slate-200 mt-0.5" />
          <div>
            <h4 className="font-semibold mb-1">Quick Tip</h4>
            <p className="text-sm">
              You can switch between modes anytime. Your selection will be remembered for your next
              session.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
