import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { FileText, Copy, Image, Upload } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface Article {
  id: string;
  title: string;
  type: string;
  niche: string;
  item_count: number | null;
  content_html: string;
  created_at: string;
}

interface ArticleImagePrompt {
  id: string;
  prompt_text: string;
  created_at: string;
}

export default function Completed() {
  const { toast } = useToast();
  const [articles, setArticles] = useState<Article[]>([]);
  const [filteredArticles, setFilteredArticles] = useState<Article[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<"all" | "local" | "published">("all");
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [generatedPrompt, setGeneratedPrompt] = useState<string>("");
  const [articlePrompts, setArticlePrompts] = useState<ArticleImagePrompt[]>([]);
  const fetchArticles = async () => {
    try {
      const { data, error } = await supabase
        .from("articles")
        .select("*")
        .eq("status", "completed")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setArticles(data || []);
      setFilteredArticles(data || []);
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to fetch completed articles.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchArticles();
  }, []);

  useEffect(() => {
    let filtered = articles;

    if (searchTerm) {
      filtered = filtered.filter((article) =>
        article.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterType === "local") {
      filtered = filtered;
    } else if (filterType === "published") {
      filtered = [];
    }

    setFilteredArticles(filtered);
  }, [searchTerm, filterType, articles]);

  useEffect(() => {
    const loadPrompts = async () => {
      if (!selectedArticle) {
        setArticlePrompts([]);
        setGeneratedPrompt("");
        return;
      }

      try {
        const { data, error } = await supabase
          .from("article_image_prompts")
          .select("id,prompt_text,created_at")
          .eq("article_id", selectedArticle.id)
          .order("created_at", { ascending: false });

        if (error) throw error;
        setArticlePrompts(data || []);
      } catch (error) {
        console.error(error);
        toast({
          title: "Error",
          description: "Failed to load image prompts.",
          variant: "destructive",
        });
      }
    };

    loadPrompts();
  }, [selectedArticle]);

  const handleCopyHTML = () => {
    if (!selectedArticle) return;
    navigator.clipboard.writeText(selectedArticle.content_html);
    toast({
      title: "Copied!",
      description: "HTML copied to clipboard.",
    });
  };

  const handleCopyPlainText = () => {
    if (!selectedArticle) return;
    const text = selectedArticle.content_html.replace(/<[^>]*>/g, "");
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: "Plain text copied to clipboard.",
    });
  };

  const handleGenerateImagePrompts = async () => {
    if (!selectedArticle) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Prefer user-specific template, else global default
      const { data: userTemplate } = await supabase
        .from("image_prompt_templates")
        .select("prompt_text")
        .eq("user_id", user.id)
        .limit(1)
        .maybeSingle();

      let templateText = userTemplate?.prompt_text as string | undefined;

      if (!templateText) {
        const { data: globalTemplate } = await supabase
          .from("image_prompt_templates")
          .select("prompt_text")
          .is("user_id", null)
          .eq("is_default", true)
          .limit(1)
          .maybeSingle();

        templateText = (globalTemplate?.prompt_text as string | undefined) ??
          "Based on this article about \"{title}\", create {count} image prompts. Article excerpt: {content}";
      }

      const filledPrompt = templateText
        .replace(/{title}/g, selectedArticle.title)
        .replace(/{count}/g, (selectedArticle.item_count ?? 0).toString())
        .replace(/{content}/g, selectedArticle.content_html.substring(0, 500));

      const { error } = await supabase.from("article_image_prompts").insert({
        article_id: selectedArticle.id,
        prompt_text: filledPrompt,
      });

      if (error) throw error;

      setGeneratedPrompt(filledPrompt);
      // Refresh prompts list
      const { data } = await supabase
        .from("article_image_prompts")
        .select("id,prompt_text,created_at")
        .eq("article_id", selectedArticle.id)
        .order("created_at", { ascending: false });

      setArticlePrompts(data || []);

      toast({
        title: "Success!",
        description: "Image prompt generated.",
      });
    } catch (error) {
      console.error(error);
      toast({
        title: "Error",
        description: "Failed to generate image prompt.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-1 text-slate-900">
          Completed Articles
        </h1>
        <p className="text-sm text-muted-foreground">
          {articles.length} total  b7 {articles.length} local only  b7 0 in WordPress
        </p>
      </div>

      <div className="flex gap-3 mb-6">
        <Input
          placeholder="Search articles..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-xs"
        />
        <Select value={filterType} onValueChange={(v) => setFilterType(v as typeof filterType)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Articles</SelectItem>
            <SelectItem value="local">Local only</SelectItem>
            <SelectItem value="published" disabled>
              Published (0)
            </SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filteredArticles.length === 0 ? (
        <Card className="p-16 bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-100 shadow-sm">
          <div className="flex flex-col items-center justify-center text-center">
            <FileText className="h-16 w-16 text-slate-500 dark:text-slate-200 mb-4" />
            <h3 className="text-xl font-semibold mb-1">No articles yet</h3>
            <p className="text-sm">Generate your first article to get started</p>
          </div>
        </Card>
      ) : (
        <div className="grid gap-4">
          {filteredArticles.map((article) => (
            <Card
              key={article.id}
              className="p-6 cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => setSelectedArticle(article)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold mb-2">{article.title}</h3>
                  <div className="flex gap-2 mb-2">
                    <Badge variant="secondary">{article.type}</Badge>
                    <Badge variant="outline" className="capitalize">
                      {article.niche}
                    </Badge>
                    {article.item_count && (
                      <Badge variant="outline">{article.item_count} items</Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Created {formatDistanceToNow(new Date(article.created_at), { addSuffix: true })}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Sheet open={!!selectedArticle} onOpenChange={() => setSelectedArticle(null)}>
        <SheetContent className="sm:max-w-2xl overflow-y-auto border-l border-border/60 bg-background/95">
          {selectedArticle && (
            <>
              <SheetHeader className="pb-2 border-b border-border/60">
                <SheetTitle className="text-base font-semibold leading-tight">
                  {selectedArticle.title}
                </SheetTitle>
                <SheetDescription className="mt-2">
                  <div className="flex flex-wrap gap-2">
                    <Badge
                      variant="secondary"
                      className="rounded-full px-3 py-0.5 text-[11px] font-medium"
                    >
                      {selectedArticle.type}
                    </Badge>
                    <Badge
                      variant="outline"
                      className="capitalize rounded-full px-3 py-0.5 text-[11px] font-medium"
                    >
                      {selectedArticle.niche}
                    </Badge>
                    {selectedArticle.item_count && (
                      <Badge
                        variant="outline"
                        className="rounded-full px-3 py-0.5 text-[11px] font-medium"
                      >
                        {selectedArticle.item_count} items
                      </Badge>
                    )}
                  </div>
                </SheetDescription>
              </SheetHeader>

              <div className="mt-4 space-y-6 pb-6">
                <div className="prose prose-sm max-w-none dark:prose-invert">
                  <div dangerouslySetInnerHTML={{ __html: selectedArticle.content_html }} />
                </div>

                <div className="flex flex-wrap gap-2 pt-3 border-t">
                  <Button onClick={handleCopyHTML} variant="outline" size="sm" className="rounded-full h-8 px-3 text-xs">
                    <Copy className="h-3 w-3 mr-2" />
                    Copy HTML
                  </Button>
                  <Button
                    onClick={handleCopyPlainText}
                    variant="outline"
                    size="sm"
                    className="rounded-full h-8 px-3 text-xs"
                  >
                    <Copy className="h-3 w-3 mr-2" />
                    Copy Plain Text
                  </Button>
                  <Button
                    onClick={handleGenerateImagePrompts}
                    variant="outline"
                    size="sm"
                    className="rounded-full h-8 px-3 text-xs"
                  >
                    <Image className="h-3 w-3 mr-2" />
                    Generate Image Prompts
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled
                    title="Publishing coming soon"
                    className="rounded-full h-8 px-3 text-xs"
                  >
                    <Upload className="h-3 w-3 mr-2" />
                    Publish to WordPress
                  </Button>
                </div>

                {generatedPrompt && (
                  <Card className="p-4 bg-muted/40 rounded-2xl border border-border/60">
                    <h4 className="font-semibold mb-2 text-sm">Latest Generated Image Prompt</h4>
                    <p className="text-xs text-muted-foreground mb-3 whitespace-pre-wrap">
                      {generatedPrompt}
                    </p>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 px-3 text-xs rounded-full"
                      onClick={() => {
                        navigator.clipboard.writeText(generatedPrompt);
                        toast({ title: "Copied!", description: "Image prompt copied." });
                      }}
                    >
                      <Copy className="h-3 w-3 mr-2" />
                      Copy Prompt
                    </Button>
                  </Card>
                )}

                {articlePrompts.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-semibold text-xs uppercase tracking-[0.16em] text-muted-foreground">
                      All Image Prompts
                    </h4>
                    {articlePrompts.map((prompt) => (
                      <Card
                        key={prompt.id}
                        className="p-3 bg-muted/30 rounded-2xl border border-border/60"
                      >
                        <p className="text-xs mb-2 whitespace-pre-wrap">{prompt.prompt_text}</p>
                        <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                          <span>
                            {formatDistanceToNow(new Date(prompt.created_at), { addSuffix: true })}
                          </span>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-7 w-7 rounded-full"
                            onClick={() => {
                              navigator.clipboard.writeText(prompt.prompt_text);
                              toast({ title: "Copied!", description: "Prompt copied." });
                            }}
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
