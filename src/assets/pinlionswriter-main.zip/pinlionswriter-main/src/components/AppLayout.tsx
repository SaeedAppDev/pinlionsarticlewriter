import { useEffect, useState } from "react";
import { Outlet, useNavigate, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { FileText, Plus, Clock, CheckCircle, Settings, Moon, Sun, LogOut } from "lucide-react";
import { useTheme } from "next-themes";

export default function AppLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const { theme, setTheme } = useTheme();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => setUser(user));
  }, []);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/login");
  };

  const navItems = [
    { path: "/mode", icon: FileText, label: "Mode" },
    { path: "/add", icon: Plus, label: "Add" },
    { path: "/queue", icon: Clock, label: "Queue" },
    { path: "/completed", icon: CheckCircle, label: "Completed" },
    { path: "/settings", icon: Settings, label: "Settings" },
  ];

  return (
    <div className="min-h-screen flex bg-[#F8FAFC]">
      <aside className="w-[260px] border-r bg-gradient-to-b from-[#0B1220] to-[#111827] flex flex-col shadow-lg">
        <div className="p-6 border-b flex items-center gap-3 text-white/90">
          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#7C3AED] via-[#9333EA] to-[#EC4899] flex items-center justify-center text-white font-semibold shadow-md">
            PL
          </div>
          <div>
            <h1 className="text-lg font-bold leading-tight">Pin Lions</h1>
            <p className="text-xs text-slate-300/80">Article Writer</p>
          </div>
        </div>

        <div className="px-4 py-3 border-b">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="w-full justify-between rounded-full bg-white/10 hover:bg-white/15 text-xs text-slate-100"
          >
            <span className="font-medium flex items-center gap-2">
              {theme === "dark" ? (
                <>
                  <Moon className="h-3 w-3" />
                  Dark
                </>
              ) : (
                <>
                  <Sun className="h-3 w-3" />
                  Light
                </>
              )}
            </span>
          </Button>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1 text-slate-300">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Button
                key={item.path}
                variant="ghost"
                className={`w-full justify-start rounded-full px-4 py-2 text-sm transition-colors ${
                  isActive
                    ? "bg-[linear-gradient(90deg,#7C3AED_0%,#9333EA_50%,#EC4899_100%)] text-white shadow-md"
                    : "bg-transparent hover:bg-white/5 text-slate-300 hover:text-white"
                }`}
                onClick={() => navigate(item.path)}
              >
                <Icon className="h-4 w-4 mr-3" />
                {item.label}
              </Button>
            );
          })}
        </nav>

        <div className="p-4 border-t text-xs text-slate-300/80">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleSignOut}
            className="w-full justify-start rounded-full text-slate-100 hover:bg-white/5"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Sign Out
          </Button>
          <p className="mt-3 text-[11px] opacity-70">Version 1.0.0 · © 2026 Pin Lions</p>
        </div>
      </aside>

      <main className="flex-1 overflow-y-auto">
        <div className="max-w-6xl mx-auto px-10 py-10">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
